import MainLayout from "../Component/Layouts/MainLayout/MainLayout";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import PrescriptionList from "../Pages/Prescription/PrescriptionList";
import PrescriptionForm from "../Pages/Prescription/PrescriptionForm";
import Login from "../Pages/Login/Login";
import ResetPassword from "../Pages/Login/ResetPassword";
import { AuthRoute } from "./AuthRoute";
import { NoAuthRoute } from "./NoAuthRoute";
export const AppRouter = () => {
  const router = createBrowserRouter([
    {
      element: <AuthRoute children={<MainLayout />} />,
      children: [
        {
          path: "/",
          element: <PrescriptionList />,
        },
        {
          path: "/PrescriptionList",
          element: <PrescriptionList />,
        },
        {
          path: "/prescriptionForm",
          element: <PrescriptionForm />,
        },
        {
          path: "/prescriptionForm/:id",
          element: <PrescriptionForm />,
        },
        {
          path: "/resetPassword",
          element: <ResetPassword />,
        },
      ],
    },
    {
      path: "/login",
      element: <NoAuthRoute children={<Login />} />,
    },
    // {
    //   path: "/forgotPassword",
    //   element: <NoAuthRoute children={<ForgotPassword />} />,
    // },
  ]);

  return <RouterProvider router={router} />;
};
