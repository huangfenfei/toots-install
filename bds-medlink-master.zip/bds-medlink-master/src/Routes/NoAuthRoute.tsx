import React from "react";
import { Navigate, useLocation } from "react-router";
import { isAuthen } from "../Services/Auth.service";

export const NoAuthRoute = ({ children }: { children: JSX.Element }) => {
  const auth = isAuthen();
  return auth ? <Navigate to="/" /> : children;
};
