import { Navigate } from "react-router";
import { isAuthen } from "../Services/Auth.service"

export const AuthRoute =  ({children}:{children : JSX.Element}) => {
  const auth =  isAuthen();
  return auth ? children : <Navigate to='/login'/>
}
