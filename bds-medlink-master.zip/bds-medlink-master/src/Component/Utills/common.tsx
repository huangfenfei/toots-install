export const isNumeric = {
  rules: [
    {
      required: true,
      validator: (_: any, value: string) => {
        const validPattern = /^[0-9]+$/;
        if (value === "" || value === undefined) {
          return Promise.reject(new Error("กรุณากรอก ${label}"));
        } else if (validPattern.test(value)) {
          return Promise.resolve();
        } else {
          return Promise.reject("กรุณากรอกเฉพาะตัวเลข");
        }
      },
    },
  ],
};

export const onKeyDown = {};

export const validateEmail = {
  rules: [
    {
      validator: (_: any, value: string) => {
        const validPattern = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
        if (value.trim() === "" || value === undefined) {
          return Promise.resolve();
          // return Promise.reject(new Error("กรุณากรอก ${label}"));
        } else if (validPattern.test(value)) {
          return Promise.resolve();
        } else {
          return Promise.reject("รูปแบบอีเมล์ไม่ถูกต้อง");
        }
      },
    },
  ],
};

export const validateCitizenID = {
  rules: [
    {
      validator: (_: any, id: string) => {
        if (!id) {
          // return Promise.reject(new Error("กรุณากรอก ${label} 13 หลัก"));
          return Promise.resolve();
        }
        const validPattern = /^[0-9]+$/;
        if (!validPattern.test(id)) {
          return Promise.reject(new Error("กรุณากรอกเฉพาะตัวเลข"));
        }
        const idArr = String(id).split("");
        let rsOfIdx = 0, numOfInx = 13;
        for (let i = 0; i <= 11; i++) {
          rsOfIdx += Number(idArr[i]) * numOfInx;
          numOfInx--;
        }
        const lastDigit = Number(idArr[12]);
        const digitChecker = (11 - (rsOfIdx % 11)) % 10;

        if (lastDigit !== digitChecker) {
          return Promise.reject(new Error("รูปแบบเลขบัตรประชาชนไม่ถูกต้อง"));
        }

        return Promise.resolve();
      },
    },
  ],
};
