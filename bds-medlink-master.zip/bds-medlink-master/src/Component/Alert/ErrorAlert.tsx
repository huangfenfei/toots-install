import { Alert, message } from "antd";

const error = () => {
    setTimeout(() => {
        message.error({
            content: "การเข้าสู่ระบบล้มเหลว",
        }); 
    }, 100 );
};

export const ErrorAlert = ({ ...props }: any) => {
    return (
        <div {...props}>
            <Alert message="Error Text" type="error" />
        </div>
    );
};

export default ErrorAlert;

