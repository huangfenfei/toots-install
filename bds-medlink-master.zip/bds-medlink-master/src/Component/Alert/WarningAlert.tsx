import { Alert } from "antd";

export const WarningAlert = ({ ...props }: any) => {
    return (
        <div {...props}>
            <Alert message="Warning Text" type="warning" />
        </div>
    );
};

export default WarningAlert; 