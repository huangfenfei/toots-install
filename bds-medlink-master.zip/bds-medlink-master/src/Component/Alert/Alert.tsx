import React from 'react';
    import './index.css';
    import { Alert, Space } from 'antd';

const AlertMessage: React.FC = () => (

  <Space direction="vertical" style={{ width: '100%' }}>
    <Alert
        message="Success"
        description="This is a success."
        type="success"
        showIcon
    />
    <Alert 
        message="Fail" 
        description="Not found User." 
        type="error" showIcon />
    <Alert
        message="Fail"
        description="Password incorrect."
        type="warning"
        showIcon
    />
    <Alert
        message="Fail"
        description="Duplicate Login."
        type="warning"
        showIcon
    />
  </Space>
);

export default AlertMessage;
