import { Alert, message } from "antd";

export const SuccessAlert = ({ ...props }: any) => {
    const success = () => {
        setTimeout(() => {
            message.success({
                content: "เข้าสู่ระบบเรียบร้อย",
            }); 
        }, 100 );
    };
    return (
        <div {...props}>
            <Alert message="Success Text" type="success" />
        </div>
    );
};

export default SuccessAlert; 