import { Alert, message } from "antd";

export const InfoAlert = ({ ...props }: any) => {
    const info = () => {
        setTimeout(() => {
            message.info({
                content: " ",
            }); 
        }, 100 );
    }; 
    
    return (
        <div {...props}>
            <Alert message="Info Text" type="info" />
        </div>
    );
};

export default InfoAlert;