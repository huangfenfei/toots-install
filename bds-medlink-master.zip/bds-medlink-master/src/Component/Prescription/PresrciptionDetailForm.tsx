import {
  DeleteFilled,
  EditFilled,
  PlusOutlined,
} from "@ant-design/icons";
import {
  DatePicker,
  Form,
  Button,
  Input,
  message,
  Row,
  Col,
  Select,
  Table,
  Upload,
  Modal,
  FormInstance,
  Popconfirm,
} from "antd";
import type { RcFile, UploadProps } from "antd/es/upload";
import type { UploadFile } from "antd/es/upload/interface";
import TextArea from "antd/es/input/TextArea";
import type { ColumnsType } from "antd/es/table";
import { useContext, useEffect, useState } from "react";
import * as input from "../../Component/Layouts/FormInput.Style";
import { DoctorsType, ItemType } from "../../Pages/Prescription/InterfaceType";
import EditProductModal from "../Modal/EditProductModal";
import SearchProductModal from "../Modal/SearchProductModal";
import { DataContext } from "../../Pages/Prescription/PrescriptionForm";
import { useParams } from "react-router";
import dayjs from "dayjs";

const PresrciptionDetailForm = ({
  form,
  onFinish,
  deliveryType,
}: {
  form: FormInstance;
  onFinish: any;
  deliveryType: any;
}) => {
  const paramId = useParams();
  const formatDate = "YYYY-MM-DD";
  const { prescriptData, initialData } = useContext(DataContext);
  const [isOpenSearchProduct, setIsOpenSearchProduct] = useState(false);
  const [isOpenEditProduct, setIsOpenEditProduct] = useState(false);
  const [itemList, setItemList] = useState<ItemType[]>([]);
  const [item, setItem] = useState<ItemType>();
  const [totalPrice, setTotalPrice] = useState(0);
  const [paid, setPaid] = useState(0);
  const [extraPayment, setExtraPayment] = useState(0);
  const [deliveryTypeTmp, setDeliveryTypeTmp] = useState("");
  const [deliveryPrice, setDeliveryPrice] = useState(0);
  const [doctors, setDoctors] = useState<DoctorsType[]>([]);
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [previewTitle, setPreviewTitle] = useState("");
  const [disableForm, setDisableForm] = useState(false);
  const [attachmentList, setAttachmentList] = useState([]);
  const { Option } = Select;

  const getConfig = () => {
    if (initialData === undefined) {
      return;
    }
    setDoctors(initialData.doctors);
    // setDeliveryPrice(initialData.delivery_price);
  };

  // const itemData = paramId.id !== "create" ? productList : itemList;
  const attachmentData = paramId.id !== "create" ? attachmentList : fileList;

  useEffect(() => {
    getConfig();
    if (prescriptData === undefined) {
      return;
    }

    if (prescriptData.prescript_info.display_type === "VIEW") {
      setDisableForm(true);
    } else if (prescriptData.prescript_info.display_type === "EDIT") {
      setDisableForm(false);
    }

    setItemList(prescriptData.prescript_info.detail);
    setAttachmentList(prescriptData.prescript_info.attachment);
    setDeliveryTypeTmp(prescriptData.delivery_info.type);

    form.setFieldsValue({
      doctor_id: prescriptData.prescript_info.doctor_id,
      prescript_date: dayjs(prescriptData.prescript_info.date, formatDate),
      diagnosis: prescriptData.prescript_info.diagnosis,
      prescript_no: prescriptData.prescript_info.no,
      symptom: prescriptData.prescript_info.symptom,
      total_price: prescriptData.prescript_info.total_price,
      // delivery_price: prescriptData.prescript_info.delivery_price,
      sub_total_price: prescriptData.prescript_info.sub_total_price,
    });
  }, [initialData, prescriptData]);

  useEffect(() => {
    if (deliveryType) {
      setDeliveryTypeTmp(deliveryType);
    }
  }, [deliveryType]);

  useEffect(() => {
    let totalPrice = 0;
    if (itemList) {
      form.setFieldsValue({
        detail: itemList
      });

      if (itemList.length > 0) {
        itemList.map((obj) => {
          totalPrice += obj.item_total_price;
        });
      } else {
        totalPrice = 0;
      }
    }
    setTotalPrice(totalPrice);
  }, [itemList]);

  useEffect(() => {
    let price = 0;
    if (deliveryTypeTmp) {
      if (deliveryTypeTmp === "" || deliveryTypeTmp === "1") {
        price = 0;
      } else {
        if (initialData) {
          price = initialData.delivery_price;
        } else {
          price = prescriptData.prescript_info.delivery_price;
        }
      }
      setDeliveryPrice(price);
    }
  }, [deliveryTypeTmp]);

  useEffect(() => {
    handleItemPricing();
  }, [deliveryPrice]);

  useEffect(() => {
    handleItemPricing();
  }, [totalPrice]);

  const handleItemPricing = () => {
    form.setFieldsValue({
      delivery_price: deliveryPrice,
      total_price: totalPrice,
      sub_total_price: totalPrice + deliveryPrice,
    });
  }
  
  const handleItemDetail = () => {
    let totalPrice = 0;
    if (itemList) {
      if (itemList.length > 0) {
        itemList.map((obj) => {
          totalPrice += obj.item_total_price;
        });
      } else {
        totalPrice = 0;
      }
    }
    setTotalPrice(totalPrice);
  }

  const handlePaidChange = (value: string) => {
    let extraPayments = 0;
    if (value.trim() !== "") {
      extraPayments = totalPrice - Number(value);
    } else {
      extraPayments = 0;
    }
    form.setFieldsValue({
      extra_payment: extraPayments,
    });
  };

  const callbackProductModal = async (data: ItemType) => {
    const itemFind = await itemList.find((obj) => {
      return obj.item_code === data.item_code;
    });

    if (!itemFind) {
      setItemList([...itemList, data]);
      message.open({
        type: "success",
        content: "เพิ่มและแก้ไขสินค้าในใบสั่งแพทย์สำเร็จแล้ว",
      });
    } else {
      message.open({
        type: "error",
        content: "รายการสินค้าซ้ำ!",
      });
    }
  };

  const openEditItemMocdal = (data: ItemType) => {
    setIsOpenEditProduct(true);
    setItem(data);
  };

  const callbackUpdateItem = (data: ItemType) => {
    const updateItem = itemList.map((obj) => {
      if (obj.item_code === data.item_code) {
        return {
          ...obj,
          item_qty: data.item_qty,
          item_price: data.item_price,
          item_total_price: data.item_total_price,
          item_method: data.item_method,
          item_recommend: data.item_recommend,
          remark: data.remark,
        };
      } else {
        return obj;
      }
    });
    setItemList(updateItem);
  };

  const deleteProduct = (data: ItemType) => {
    const itemFilter = itemList.filter((obj) => {
      return obj.item_code !== data.item_code;
    });
    if (itemFilter) {
      setItemList(itemFilter);
    }
  };

  const formFile = (e: any) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e?.fileList;
  };

  const getBase64 = (file: RcFile): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });

  const handleCancel = () => setPreviewOpen(false);
  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as RcFile);
    }

    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
    setPreviewTitle(
      file.name || file.url!.substring(file.url!.lastIndexOf("/") + 1)
    );
  };

  const handleChange: UploadProps["onChange"] = ({ fileList: newFileList }) =>
    setFileList(newFileList);

  const handleBeforeUpload = (file: any) => {
    setFileList([...fileList, file]);
    return false;
  };

  useEffect(() => {
    if (fileList) {
      form.setFieldsValue({
        attachment: fileList,
      });
    }
  }, [fileList]);

  const handleRemove = async (file: any) => {
    const index = await fileList.indexOf(file);
    const newFileList = await fileList.slice();
    await newFileList.splice(index, 1);
    await setFileList(newFileList);

    form.setFieldsValue({
      attachment: fileList,
    });
  };

  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 5 }}>เพิ่มแนบไพล์</div>
    </div>
  );

  const listItemColumn: ColumnsType<ItemType> = [
    {
      title: "ชื่อยา",
      dataIndex: "item_name",
      width: "300px",
      align: "center",
    },
    {
      title: "ขนาด",
      dataIndex: "item_size",
      width: "130px",
      align: "center",
    },
    {
      title: "ราคา (บาท)",
      dataIndex: "item_price",
      width: "100px",
      align: "center",
    },
    {
      title: "จำนวน",
      dataIndex: "item_qty",
      width: "100px",
      align: "center",
    },
    {
      title: "ราคารวม",
      dataIndex: "item_total_price",
      width: "100px",
      align: "center",
    },
    {
      title: "วิธีใช้/คำแนะนำ",
      // dataIndex: ["item_method"],
      align: "center",
      width: "360px",
      render: (text, item: ItemType) => (
        <div>
          <div hidden={item.item_method.trim() === ""}>- {item.item_method}</div>
          <div hidden={item.item_recommend.trim() === ""}>- {item.item_recommend}</div>
        </div>
      )
    },
    {
      title: "หมายเหตุ",
      dataIndex: "remark",
      align: "center",
    },
    {
      title: "",
      dataIndex: "",
      width: "210px",
      align: "center",
      render: (item: ItemType) => {
        if (!disableForm) {
          return (
            <div>
          <Row>
            <Col span={12}>
              <Button
                type="primary"
                style={{
                  backgroundColor: "#ffc107",
                  justifyContent: "center",
                  color: "white",
                }}
                icon={<EditFilled />}
                onClick={() => openEditItemMocdal(item)}
              >
                แก้ไข
              </Button>
            </Col>
            <Col span={12}>
              <Popconfirm
                placement="left"
                title={"ยืนยันการลบรายการ?"}
                onConfirm={() => deleteProduct(item)}
                okText="ยืนยัน"
                cancelText="ยกเลิก"
              >
                <Button
                  style={{
                    backgroundColor: "#F25F0A",
                    justifyContent: "center",
                    color: "white",
                  }}
                  icon={<DeleteFilled />}
                >
                  ลบ
                </Button>
              </Popconfirm>
            </Col>
          </Row>
        </div>
          );
        }
      },
    },
  ];

  return (
    <div>
      <Row>
        <input.tittle style={{ fontSize: 20, marginBottom: 20 }}>
          ข้อมูลใบสั่งแพทย์
        </input.tittle>
      </Row>
      <Form
        layout="vertical"
        form={form}
        onFinish={onFinish}
        disabled={disableForm}
      >
        <Row gutter={24}>
          <Col span={8}>
            <Form.Item 
              label={"เลขที่ใบสั่งแพทย์"} 
              name={"prescript_no"}
              rules={[{required: true}]}
            >
              <Input 
                maxLength={100}
              />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              label={"วันที่"}
              name={"prescript_date"}
              rules={[{ required: true }]}
            >
              <DatePicker style={{ display: "flex" }} />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item 
              label={"แพทย์ผู้วินิจฉัย"} 
              name={"doctor_id"}
              rules={[{ required: true }]}

            >
              <Select placeholder="เลือก">
                {doctors.map((e) => (
                  <Option key={e.first_name} value={e.id}>
                    {e.title} {e.first_name}
                    {e.last_name}
                  </Option>
                ))}
              </Select>
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={24}>
          <Col span={24}>
            <Form.Item 
              label={"อาการ"} 
              name={"symptom"}
            >
              <TextArea 
                showCount
                style={{ resize: "none" }} 
                rows={5}
                maxLength={250}
              />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={24}>
          <Col span={24}>
            <Form.Item 
              label={"รายละเอียดการวินิจฉัย"} 
              name={"diagnosis"}
            >
              <TextArea 
                showCount
                style={{ resize: "none" }} 
                rows={5} 
                maxLength={250}
              />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={24}>
          <Col span={1}>
            <Form.Item>
              <Button
                type="primary"
                style={{ color: "#fff", backgroundColor: "#50B0E9" }}
                onClick={() => setIsOpenSearchProduct(true)}
              >
                ค้นหาสินค้า
              </Button>
              <SearchProductModal
                open={isOpenSearchProduct}
                onCancel={() => setIsOpenSearchProduct(false)}
                onOk={() => setIsOpenSearchProduct(false)}
                onCallback={callbackProductModal}
                validItemList={itemList}
              />
              <EditProductModal
                item={item}
                onOpen={isOpenEditProduct}
                onCancel={() => setIsOpenEditProduct(false)}
                onCallback={callbackUpdateItem}
              ></EditProductModal>
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={24}>
          <Col span={24}>
            <Form.Item
              name={"detail"}
              style={{
                display: "inline-block",
                width: "calc(100% - 8px)",
              }}
            >
              <Table
                bordered
                rowKey={(record: ItemType) => record.key}
                columns={listItemColumn}
                dataSource={itemList}
                pagination={false}
              />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={24}>
          <Col span={12}></Col>
          <Col span={4}>
            <Form.Item name={"total_price"}>
              <Input
                disabled={true}
                addonBefore="ราคารวม"
                addonAfter="บาท"
                style={{ textAlign: "end" }}
              />
            </Form.Item>
          </Col>
          <Col span={4}>
            <Form.Item name={"delivery_price"}>
              <Input
                disabled={true}
                addonBefore="ค่าจัดส่ง"
                addonAfter="บาท"
                style={{ textAlign: "end" }}
              />
            </Form.Item>
          </Col>
          <Col span={4}>
            <Form.Item
              name={"sub_total_price"}
            >
              <Input
                disabled={true}
                addonBefore="ราคาสุทธิ"
                addonAfter="บาท"
                style={{ textAlign: "end" }}
              />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={24}>
          <Col span={24} style={{ textAlign: "start" }}>
            <Form.Item label="Upload ข้อมูล" name={"attachment"}>
              <Upload
                listType="picture-card"
                fileList={attachmentData}
                onPreview={handlePreview}
                onChange={handleChange}
                onRemove={handleRemove}
                beforeUpload={handleBeforeUpload}
              >
                {fileList.length >= 5 ? null : uploadButton}
              </Upload>

              <Modal
                open={previewOpen}
                title={previewTitle}
                footer={null}
                onCancel={handleCancel}
              >
                <img
                  alt="example"
                  style={{ width: "100%" }}
                  src={previewImage}
                />
              </Modal>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </div>
  );
};

export default PresrciptionDetailForm
