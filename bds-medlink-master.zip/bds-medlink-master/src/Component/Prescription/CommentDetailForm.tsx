import { Card, Col, Form, FormInstance, Row, Select } from "antd";
import { useContext, useEffect, useState } from "react";
import * as input from "../Layouts/FormInput.Style";
import { DataContext } from "../../Pages/Prescription/PrescriptionForm";
import TextArea from "antd/es/input/TextArea";
import Meta from "antd/es/card/Meta";
import { CommentType } from "../../Pages/Prescription/InterfaceType";
import dayjs from "dayjs";

const DeliveryDetailForm = ({
  form,
  onFinish,
}: {
  form: FormInstance;
  onFinish: any;
}) => {
  const { prescriptData, initialData } = useContext(DataContext);
  const language = "th";
  const [disableForm, setDisableForm] = useState(false);
  const [commentList, setCommentList] = useState<CommentType[]>([]);
  const { Option } = Select;

  const getConfig = () => {
    if (initialData === undefined) {
      return;
    }
  };

  useEffect(() => {
    getConfig();
    if (prescriptData === undefined) {
      return;
    }
    [...prescriptData.comments].map(element => {
      return element.iat = dayjs(element.created_date);
    });
    const sss = [...prescriptData.comments].sort((a, b) => b.iat - a.iat);
    setCommentList(sss);
  }, [prescriptData, initialData]);

  return (
    <div>
      <Form
        layout="vertical"
        form={form}
        onFinish={onFinish}
        disabled={disableForm}
      >
        <Row>
          <input.tittle style={{ fontSize: 20, width: 200 }}>
            ความคิดเห็นทั้งหมด
          </input.tittle>
        </Row>
        <Row gutter={24}>
          <Col span={24}>
            <Card bordered={true} style={{ backgroundColor: "#d9d9d9" }}>
              {commentList.map((e) => (
                <Card style={{ textAlign: "left", marginTop: 15 }} loading={false}>
                  <Meta
                    title={"วันที่: " + dayjs(e.created_date).format("YYYY-MM-DD HH:mm") + ", ความเห็นโดย: " + e.created_by}
                    description={e.comment}
                  />
                </Card>
              ))}
            </Card>
          </Col>
        </Row>
      </Form>
    </div>
  );
};

export default DeliveryDetailForm;
