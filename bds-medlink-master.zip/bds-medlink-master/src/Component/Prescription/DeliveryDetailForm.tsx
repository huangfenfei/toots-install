import { Alert, Checkbox, Col, Form, FormInstance, Input, Row, Select, message } from "antd";
import {
  getDistrict,
  getProvince,
  getSubDistrict,
  getValidateAddressDeliveryType,
} from "../../Services/Prescription.service";
import { useContext, useEffect, useState } from "react";
import * as input from "../Layouts/FormInput.Style";
import { CheckboxChangeEvent } from "antd/es/checkbox/Checkbox";
import { DataContext } from "../../Pages/Prescription/PrescriptionForm";
import {
  CountryType,
  SiteType,
  ValueType,
} from "../../Pages/Prescription/InterfaceType";
import TextArea from "antd/es/input/TextArea";
import { isNumeric, validateCitizenID, validateEmail } from "../Utills/common";
import { LockFilled } from "@ant-design/icons";

const DeliveryDetailForm = ({
  form,
  onFinish,
  onChangeDeliveryType,
}: {
  form: FormInstance;
  onFinish: any;
  onChangeDeliveryType: any;
}) => {
  const { prescriptData, initialData } = useContext(DataContext);
  const [deliveriesType, setDeliveriesType] = useState("");
  const [provinceCode, setProvinceCode] = useState("");
  const [provinceList, setProvinceList] = useState<CountryType[]>([]);
  const [districtCode, setDistrictCode] = useState("");
  const [districtList, setDistrictList] = useState<CountryType[]>([]);
  const [subDistrictCode, setSubDistrictCode] = useState("");
  const [subDistrictList, setSubDistrictList] = useState<CountryType[]>([]);
  const [deliveries, setDeliveries] = useState<ValueType[]>([]);
  const language = "th";
  const [disableForm, setDisableForm] = useState(false);
  const [dupAddress, setDupAddress] = useState(false);
  const [site, setSite] = useState<SiteType[]>([]);
  const [isChecked, setIsChecked] = useState("N");
  const { Option } = Select;

  const getConfig = () => {
    if (initialData === undefined) {
      return;
    }
    setProvinceList(initialData.provinces);
    setDeliveries(initialData.deliveries);
    setSite(initialData.sites);
  };

  useEffect(() => {
    getConfig();
    if (prescriptData === undefined) {
      return;
    }

    if (prescriptData.prescript_info.display_type === "VIEW") {
      setDisableForm(true);
    } else if (prescriptData.prescript_info.display_type === "EDIT") {
      setDisableForm(false);
    }

    if (prescriptData.delivery_info.duplicate_address === "Y") {
      setDupAddress(true);
    } else if (prescriptData.delivery_info.duplicate_address === "N") {
      setDupAddress(false);
    }

    setIsChecked(prescriptData.delivery_info.duplicate_address);
    setDeliveriesType(prescriptData.delivery_info.type);

    form.setFieldsValue({
      delivery_address: prescriptData.delivery_info.address,
      delivery_zip_code: prescriptData.delivery_info.zip_code,
      delivery_fullname: prescriptData.delivery_info.fullname,
      delivery_phone_number: prescriptData.delivery_info.phone_number,
      delivery_latitude: prescriptData.delivery_info.latitude,
      delivery_longitude: prescriptData.delivery_info.longitude,
      delivery_type: prescriptData.delivery_info.type,
      delivery_site: prescriptData.delivery_info.site_id,
      remark: prescriptData.remark,
    });

    setProvinceCode(prescriptData.delivery_info.province_code);
    setDistrictCode(prescriptData.delivery_info.district_code);
    onChangeProvince(prescriptData.delivery_info.province_code, 'SET');
    setSubDistrictCode(prescriptData.delivery_info.sub_district_code);
    onChangeDistrict(prescriptData.delivery_info.district_code, 'SET');
  }, [prescriptData, initialData]);

  useEffect(() => {
    if (provinceList) {
      form.setFieldsValue({
        delivery_province_code: provinceCode,
      });
    }
  }, [provinceList]);

  const onChangeProvince = async (provinceCode: string, even: string) => {
    const res = await getDistrict(deliveriesType, provinceCode, language);
    setDistrictList(res.datas);
    setSubDistrictList([]);

    setProvinceCode(provinceCode);
    if (even === 'SELECT') {
      setDistrictCode("");
      setSubDistrictCode("");
    }
  };

  useEffect(() => {
    if (districtList) {
      form.setFieldsValue({
        delivery_district_code: districtCode,
      });
    }
  }, [districtList]);

  const onChangeDistrict = async (districtCode: string, even: string) => {
    const res = await getSubDistrict(deliveriesType, districtCode, language);
    setSubDistrictList(res.datas);
    setDistrictCode(districtCode)

    if (even === 'SELECT') {
      setSubDistrictCode("");
    }
  };

  const onChangeSubDistrict = async (subDistrictCode: string) => {
    setSubDistrictCode(subDistrictCode)
  };

  useEffect(() => {
    if (subDistrictList) {
      form.setFieldsValue({
        delivery_sub_district_code: subDistrictCode,
      });
    }
  }, [subDistrictList]);

  const isDuplicateAddress = async (e: CheckboxChangeEvent) => {
    const checked = e.target.checked;
    const profileProvinceCode = form.getFieldValue("profile_province_code");
    const profileDistrictCode = form.getFieldValue("profile_district_code");
    const profileSubDistrictCode = form.getFieldValue("profile_sub_district_code") === '' ? '0' : form.getFieldValue("profile_sub_district_code");
    
    const res = await getValidateAddressDeliveryType(deliveriesType, profileSubDistrictCode);
    if (res.res_code === '000') {
      setDupAddress(checked);
      if (checked === true) {
        const fullName = form.getFieldValue("first_name") && form.getFieldValue("last_name") 
            ? form.getFieldValue("first_name") + " " + form.getFieldValue("last_name")
            : "";
        form.setFieldsValue({
          delivery_province_code: profileProvinceCode,
          delivery_address: form.getFieldValue("profile_address"),
          delivery_zip_code: form.getFieldValue("profile_zip_code"),
          delivery_fullname: fullName,
          delivery_phone_number: form.getFieldValue("phone_number"),
        });
        
        setDistrictCode(profileDistrictCode);
        setSubDistrictCode(profileSubDistrictCode);

        if (profileProvinceCode !== "") {
          onChangeProvince(profileProvinceCode, 'SET');
        }
        if (profileDistrictCode !== "") {
          onChangeDistrict(profileDistrictCode, 'SET');
        }

        setIsChecked("Y");
      } else {
        setIsChecked("N");
      }
    } else {
      message.error("ไม่สามารถใช้ที่อยู่เหมือนกับสมาชิก เนื่องจากอยู่นอกพื้นที่ให้บริการ", 10);
    }
  };

  useEffect(() => {
    if (isChecked) {
      form.setFieldsValue({
        delivery_duplicate_address: isChecked,
      });
    }
  }, [isChecked]);

  const handleKeyPressNumberic = (
    event: React.KeyboardEvent<HTMLInputElement>
  ) => {
    const charCode = event.key;
    if (isNaN(parseInt(charCode))) {
      event.preventDefault();
    }
  };

  const handleKeyPressNumbericDot = (
    event: React.KeyboardEvent<HTMLInputElement>
  ) => {
    const charCode = event.key;
    const validPattern = /[.0-9]/g;
    if (!validPattern.test(charCode)) {
      event.preventDefault();
    }
  };

  const handleOnChangeDeliveryType = async (value: any) => {
    onChangeDeliveryType(value);
    setDeliveriesType(value);

    const rsProvince = await getProvince(value, language);
    setProvinceList(rsProvince.datas);

    if (provinceCode) {
      const rsDistrict = await getDistrict(value, provinceCode, language);
      setDistrictList(rsDistrict.datas);
    }
   
    if (dupAddress) {
      const code = subDistrictCode === '' ? '0' : subDistrictCode;
      const rsDelivery = await getValidateAddressDeliveryType(value, code);
      if (rsDelivery.res_code !== '000') {
        form.setFieldsValue({
          delivery_fullname: "",
          delivery_phone_number: "",
          delivery_address: "",
          delivery_province_code: "",
          delivery_district_code: "",
          delivery_sub_district_code: "",
          delivery_zip_code: "",
        });
        setDistrictList([]);
        setSubDistrictList([]);
        setProvinceCode("");
        setDistrictCode("");
        setSubDistrictCode("");
        setDupAddress(false);
        message.error("ไม่สามารถใช้ที่อยู่เหมือนกับสมาชิก เนื่องจากอยู่นอกพื้นที่ให้บริการ", 10);
      }
    }
  }

  const handleKeyPress = (event: React.KeyboardEvent<HTMLInputElement>) => {
    const charCode = event.key;
    if (isNaN(parseInt(charCode))) {
      event.preventDefault();
    }
  };

  return (
    <div>
      <Form
        layout="vertical"
        form={form}
        onFinish={onFinish}
        disabled={disableForm}
      >
        <Row>
          <input.tittle style={{ fontSize: 20, width: 200 }}>
            ข้อมูลการจัดส่ง
          </input.tittle>
        </Row>
        <Row gutter={24}>
          <Col span={8}>
            <Form.Item
              label={"รูปแบบการจัดส่ง"}
              name={"delivery_type"}
              rules={[{ required: true }]}
            >
              <Select
                placeholder="เลือก"
                onChange={(val) => handleOnChangeDeliveryType(val)}
              >
                {deliveries.map((e) => (
                  <Option key={e.value} value={e.key}>
                    {e.value}
                  </Option>
                ))}
              </Select>
            </Form.Item>
          </Col>
          {deliveriesType === "1" ? (
            <Col span={8}>
              <Form.Item
                label={"สาขา"}
                name={"delivery_site"}
                rules={[{ required: true }]}
              >
                <Select placeholder="เลือก สาขา">
                  {site.map((e) => (
                    <Option key={e.site_desc} value={e.site_id}>
                      {e.site_desc}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
          ) : null}
          {deliveriesType === "2" || deliveriesType === "3" ? (
            <Col span={8}>
              <Form.Item label={" "} name={"delivery_duplicate_address"}>
                <Checkbox onChange={isDuplicateAddress} checked={dupAddress}>
                  ใช้ที่อยู่เหมือนกับสมาชิก
                </Checkbox>
              </Form.Item>
            </Col>
          ) : null}
        </Row>
        <Row gutter={24}>
          <Col span={8}>
            {deliveriesType === "2" || deliveriesType === "3" ? (
              <Form.Item
                label={"ชื่อ-นามสกุล ผู้รับ"}
                name={"delivery_fullname"}
                rules={[{ required: true }]}
              >
                <Input maxLength={250} />
              </Form.Item>
            ) : null}
          </Col>
          <Col span={8}>
            {deliveriesType === "2" || deliveriesType === "3" ? (
              <Form.Item
                {...isNumeric}
                label={"เบอร์โทรศัพท์"}
                name={"delivery_phone_number"}
              >
                <Input
                  onKeyPress={handleKeyPress}
                  maxLength={10}
                />
              </Form.Item>
            ) : null}
          </Col>
          <Col span={8}>
            {deliveriesType === "2" || deliveriesType === "3" ? (
              <Form.Item
                label={"ที่อยู่"}
                name={"delivery_address"}
                rules={[{ required: true }]}
              >
                <Input maxLength={250} />
              </Form.Item>
            ) : null}
          </Col>
        </Row>
        <Row gutter={24}>
          <Col span={8}>
            {deliveriesType === "2" || deliveriesType === "3" ? (
              <Form.Item
                label={"จังหวัด"}
                name={"delivery_province_code"}
                rules={[{ required: true }]}
              >
                <Select
                  showSearch
                  allowClear
                  filterOption={(input, option: any) =>
                    option.key.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  placeholder="เลือก จังหวัด"
                  onChange={e => onChangeProvince(e, 'SELECT')}
                >
                  {provinceList.map((e) => (
                    <Option key={e.province_name} value={e.province_code}>
                      {e.province_name}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            ) : null}
          </Col>
          <Col span={8}>
            {deliveriesType === "2" || deliveriesType === "3" ? (
              <Form.Item
                label={"เขต/อำเภอ"}
                name={"delivery_district_code"}
                rules={[{ required: true }]}
              >
                <Select
                  allowClear
                  showSearch
                  filterOption={(input, option: any) =>
                    option.key.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  placeholder="เลือก เขต/อำเภอ"
                  onChange={e => onChangeDistrict(e, 'SELECT')}
                >
                  {districtList.map((e) => (
                    <Option key={e.district_name} value={e.district_code}>
                      {e.district_name}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            ) : null}
          </Col>
          <Col span={8}>
            {deliveriesType === "2" || deliveriesType === "3" ? (
              <Form.Item
                label={"แขวง/ตำบล"}
                name={"delivery_sub_district_code"}
                rules={[{ required: true }]}
              >
                <Select
                  showSearch
                  allowClear
                  filterOption={(input, option: any) =>
                    option.key.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  placeholder="เลือก แขวง/ตำบล"
                  onChange={onChangeSubDistrict}
                >
                  {subDistrictList.map((e) => (
                    <Option
                      key={e.sub_district_name}
                      value={e.sub_district_code}
                    >
                      {e.sub_district_name}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            ) : null}
          </Col>
        </Row>
        <Row gutter={24}>
          <Col span={8}>
            {deliveriesType === "2" || deliveriesType === "3" ? (
              <Form.Item
                label={"รหัสไปรษณีย์"}
                name={"delivery_zip_code"}
                rules={[{ required: true }]}
              >
                <Input maxLength={5} onKeyPress={handleKeyPressNumberic} />
              </Form.Item>
            ) : null}
          </Col>
          <Col span={8}>
            {deliveriesType === "3" ? (
              <Form.Item
                label={"Latitude"}
                name={"delivery_latitude"}
                rules={[{ required: true }]}
              >
                <Input maxLength={15} onKeyPress={handleKeyPressNumbericDot} />
              </Form.Item>
            ) : null}
          </Col>
          <Col span={8}>
            {deliveriesType === "3" ? (
              <Form.Item
                label={"Longitude"}
                name={"delivery_longitude"}
                rules={[{ required: true }]}
              >
                <Input maxLength={15} onKeyPress={handleKeyPressNumbericDot} />
              </Form.Item>
            ) : null}
          </Col>
        </Row>
        <Row gutter={24}>
          <Col span={24}>
            <Form.Item label={"ความคิดเห็น"} name={"remark"}>
              <TextArea
                showCount
                style={{ resize: "none" }}
                rows={5}
                maxLength={500}
              />
            </Form.Item>
          </Col>
        </Row>
        
      </Form>
    </div>
  );
};

export default DeliveryDetailForm;
