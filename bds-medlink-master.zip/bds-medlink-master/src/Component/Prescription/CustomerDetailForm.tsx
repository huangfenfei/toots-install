import {
  DatePicker,
  Form,
  Button,
  Input,
  message,
  Row,
  Col,
  Select,
  FormInstance,
  Spin,
  Tooltip,
  Alert,
} from "antd";

import * as input from "../Layouts/FormInput.Style";
import { useContext, useEffect, useState } from "react";
import {
  getDistrict,
  getProvince,
  getSubDistrict,
  validateProfile,
} from "../../Services/Prescription.service";
import { CountryType, ValueType } from "../../Pages/Prescription/InterfaceType";
import { DataContext } from "../../Pages/Prescription/PrescriptionForm";
import dayjs from "dayjs";
import { useParams } from "react-router";
import { isNumeric, validateCitizenID, validateEmail } from "../Utills/common";

const CustomerDetailForm = ({
  form,
  onFinish,
}: {
  form: FormInstance;
  onFinish: any;
}) => {
  const language = "th";
  const formatDate = "YYYY-MM-DD";
  const { Option } = Select;
  const [provinceList, setProvinceList] = useState<CountryType[]>([]);
  const [districtList, setDistrictList] = useState<CountryType[]>([]);
  const [subDistrictList, setSubDistrictList] = useState<CountryType[]>([]);
  const [provinceCode, setProvinceCode] = useState("");
  const [districtCode, setDistrictCode] = useState("");
  const [subDistrictCode, setSubDistrictCode] = useState("");
  const [genders, setGenders] = useState<ValueType[]>([]);
  const [nations, setNations] = useState<ValueType[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isDisplayForm, setIsDisplayForm] = useState(true);
  const [isDisplayFindForm, setIsDisplayFindForm] = useState(false);
  const [isRequireForm, setIsRequireForm] = useState(true);
  const [btnValidType, setBtnValidType] = useState("VALID");
  const [isDisplayBtn, setIsDisplayBtn] = useState(false);
  const { initialData, prescriptData } = useContext(DataContext);
  const [isBtnHidden, setIsBtnHidden] = useState(false);

  const [action, setAction] = useState("EXISTING");
  const paramId = useParams();

  const getConfig = () => {
    if (initialData === undefined) {
      return;
    }
    setProvinceList(initialData.provinces);
    setGenders(initialData.genders);
    setNations(initialData.nations);
  };

  useEffect(() => {
    getConfig();
    if (prescriptData === undefined) {
      return;
    } else {
      if (
        prescriptData.status === "DRAFT" ||
        prescriptData.status === "REJECT"
      ) {
        setIsDisplayBtn(false);
        setIsBtnHidden(false);
      } else {
        setIsDisplayBtn(false);
        setIsBtnHidden(true);
      }
      if (prescriptData.personal_info.display_type === "VIEW") {
        setIsDisplayForm(true);
        setIsDisplayFindForm(true);
        setIsRequireForm(false);
      } else if (prescriptData.personal_info.display_type === "EDIT") {
        setIsDisplayForm(false);
        setIsDisplayFindForm(false);
        setIsRequireForm(true);
      }
    }

    form.setFieldsValue({
      phone_number: prescriptData.personal_info.phone_number,
      date_of_birth: dayjs(
        prescriptData.personal_info.date_of_birth,
        formatDate
      ),
      citizen_id: prescriptData.personal_info.citizen_id || "-",
      passport_id: prescriptData.personal_info.passport_id || "-",
      first_name: prescriptData.personal_info.first_name,
      last_name: prescriptData.personal_info.last_name,
      gender: prescriptData.personal_info.gender,
      congenital_disease: prescriptData.personal_info.congenital_disease,
      drug_allergy: prescriptData.personal_info.drug_allergy,
      nation: prescriptData.personal_info.nation,
      weight: prescriptData.personal_info.weight,
      height: prescriptData.personal_info.height,
      email: prescriptData.personal_info.email,
      profile_address: prescriptData.personal_info.address,
      profile_zip_code: prescriptData.personal_info.zip_code,
      button_action: prescriptData.personal_info.action,
    });

    setProvinceCode(prescriptData.personal_info.province_code);
    onChangeForDistrict(prescriptData.personal_info.province_code);
    setDistrictCode(prescriptData.personal_info.district_code);
    onChangeForSubDistrict(prescriptData.personal_info.district_code);
    setSubDistrictCode(prescriptData.personal_info.sub_district_code);
  }, [prescriptData, initialData]);

  useEffect(() => {
    form.setFieldsValue({
      button_action: action,
    });
  }, [action]);

  useEffect(() => {
    if (provinceList) {
      form.setFieldsValue({
        profile_province_code: provinceCode,
      });
    }
  }, [provinceList]);

  const onChangeForDistrict = async (provinceCode: string) => {
    const res = await getDistrict('0', provinceCode, language);
    setDistrictList(res.datas);
    setSubDistrictList([]);
  };

  useEffect(() => {
    if (districtList) {
      form.setFieldsValue({
        profile_district_code: districtCode,
      });
    }
  }, [districtList]);

  const onChangeForSubDistrict = async (districtCode: string) => {
    const res = await getSubDistrict('0', districtCode, language);
    setSubDistrictList(res.datas);
  };

  useEffect(() => {
    if (subDistrictList) {
      form.setFieldsValue({
        profile_sub_district_code: subDistrictCode,
      });
    }
  }, [subDistrictList]);

  const getValidateProfile = async () => {
    setIsLoading(true);
    if (btnValidType === "VALID") {
      let phone_number = "";
      let date_of_birth = "";
      try {
        phone_number = form.getFieldValue("phone_number");
        date_of_birth = form.getFieldValue("date_of_birth").format(formatDate);
      } catch (error) {}

      if (phone_number === "" || date_of_birth === "") {
        message.error("ไม่พบสมาชิก กรุณากรอกข้อมูลใหม่");
        setIsLoading(false);
        return;
      }

      const res = await validateProfile(phone_number, date_of_birth);
      setIsLoading(false);

      if (res.res_code === "000") {
        const data = res.datas;
        form.setFieldsValue({
          citizen_id: data.citizen_id,
          passport_id: data.passport_id || "-",
          first_name: data.first_name,
          last_name: data.last_name,
          gender: data.gender,
          congenital_disease: data.congenital_disease,
          drug_allergy: data.drug_allergy,
          nation: data.nation,
          weight: data.weight,
          height: data.height,
          email: data.email,
          profile_province_code: data.province_code,
          profile_address: data.address,
          profile_zip_code: data.zip_code,
        });

        onChangeForDistrict(data.province_code);
        setDistrictCode(data.district_code);

        onChangeForSubDistrict(data.district_code);
        setSubDistrictCode(data.sub_district_code);

        setAction("EXISTING");
        setBtnValidType("CLEAR");
        setIsRequireForm(false);
        setIsDisplayFindForm(true);
      } else if (res.res_code === "E101") {
        message.error("ไม่มีข้อมูลในระบบ กรุณากรอกข้อมูลใหม่", 10);
      } else if (res.res_code === "E102") {
        message.error(
          "ตรวจสอบข้อมูลไม่สำเร็จ ข้อมูลไม่ถูกต้อง กรุณาตรวจสอบข้อมูลอีกครั้ง หรือ ติดต่อ Call Center: 02-538-2229",
          10
        );
      }
    } else if (btnValidType === "CLEAR") {
      setIsLoading(false);
      form.resetFields();
      setBtnValidType("VALID");
      setIsRequireForm(true);
      setIsDisplayFindForm(false);
    }
    setIsDisplayForm(true);
  };

  const onInputNewValue = () => {
    setAction("NEW");
    setIsRequireForm(true);
    setBtnValidType("VALID");
    setIsDisplayForm(false);
    setIsDisplayFindForm(false);

    form.setFieldsValue({
      phone_number: "",
      date_of_birth: "",
      citizen_id: "",
      passport_id: "",
      first_name: "",
      last_name: "",
      gender: "",
      congenital_disease: "",
      drug_allergy: "",
      nation: "" || "TH",
      weight: "",
      height: "",
      email: "",
      profile_province_code: "",
      profile_district_code: "",
      profile_sub_district_code: "",
      profile_address: "",
      profile_zip_code: "",
      button_action: "NEW",
    });
  };

  const handleKeyPress = (event: React.KeyboardEvent<HTMLInputElement>) => {
    const charCode = event.key;
    if (isNaN(parseInt(charCode))) {
      event.preventDefault();
    }
  };

  return (
    <div>
      <Spin spinning={isLoading}>
        {/* <AlertModal></AlertModal> */}
        <Row>
          <input.tittle style={{ fontSize: 20, marginBottom: 20 }}>
            ข้อมูลลูกค้า
          </input.tittle>
        </Row>
        <Form
          layout="vertical"
          form={form}
          onFinish={onFinish}
          disabled={isDisplayForm}
        >
          <Row gutter={24}>
            <Col span={8}>
              <Form.Item
                {...isNumeric}
                label={"เบอร์โทรศัพท์"}
                name={"phone_number"}
              >
                <Input
                  onKeyPress={handleKeyPress}
                  maxLength={10}
                  disabled={isDisplayFindForm}
                />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                label={"วัน เดือน ปี เกิด"}
                name="date_of_birth"
                rules={[{ required: isRequireForm }]}
              >
                <DatePicker
                  style={{ display: "flex" }}
                  format={formatDate}
                  disabled={isDisplayFindForm}
                />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label={" "} name={"button_action"}>
                <Row>
                  {!isBtnHidden ? (
                    <Button
                      type="primary"
                      onClick={getValidateProfile}
                      style={{
                        backgroundColor:
                          btnValidType === "CLEAR" ? "#6B6B6B" : "#50B0E9",
                        width: 130,
                        color: "white",
                        margin: "0 10px",
                      }}
                      disabled={false}
                      hidden={isDisplayBtn}
                    >
                      {btnValidType === "CLEAR"
                        ? "ล้างข้อมูล"
                        : "ตรวจสอบข้อมูล"}
                    </Button>
                  ) : null}
                  {!isBtnHidden ? (
                    <Button
                      type="primary"
                      style={{
                        backgroundColor: "#78A500",
                        justifyContent: "center",
                        color: "white",
                        margin: "0 10px",
                      }}
                      onClick={onInputNewValue}
                      disabled={false}
                      hidden={isDisplayBtn}
                    >
                      กรอกข้อมูลใหม่
                    </Button>
                  ) : null}
                </Row>
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col span={8}>
              <Form.Item
                // {...validateCitizenID}
                label={"เลขบัตรประชาชน"}
                name={"citizen_id"}
                rules={[{ required: isRequireForm }]}
              >
                <Input maxLength={13} onKeyPress={handleKeyPress} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label={"เลขที่หนังสือเดินทาง"} name={"passport_id"}>
                <Input maxLength={15} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Alert
                message="หากตรวจสอบข้อมูล แล้วพบว่า ชื่อ-นามสกุล หรือข้อมูลอื่นๆ ไม่ถูกต้อง กรุณาติดต่อ Call Center: 02-538-2229"
                type="warning"
              />
            </Col>
          </Row>
          <Row gutter={24}>
            <Col span={8}>
              <Form.Item
                label={"ชื่อ"}
                name={"first_name"}
                rules={[{ required: isRequireForm }]}
              >
                <Input maxLength={100} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                label={"นามสกุล"}
                name={"last_name"}
                rules={[{ required: isRequireForm }]}
              >
                <Input maxLength={100} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                label={"เพศ"}
                name={"gender"}
                rules={[{ required: isRequireForm }]}
              >
                <Select placeholder="เลือก">
                  {genders.map((gender) => (
                    <Option key={gender.value} value={gender.key}>
                      {gender.value}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col span={8}>
              <Form.Item
                label={"โรคประจำตัว"}
                name={"congenital_disease"}
                rules={[{ required: isRequireForm }]}
              >
                <Input maxLength={100} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                label={"แพ้ยา"}
                name={"drug_allergy"}
                rules={[{ required: isRequireForm }]}
              >
                <Input maxLength={100} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label={"สัญชาติ"} name={"nation"}>
                <Select showSearch placeholder="เลือก">
                  {nations.map((e) => (
                    <Option key={e.value} value={e.key}>
                      {e.value}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col span={8}>
              <Form.Item label={"น้ำหนัก (กิโลกรัม)"} name={"weight"}>
                <Input maxLength={3} placeholder="0" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label={"ส่วนสูง (เซนติเมตร)"} name={"height"}>
                <Input maxLength={3} placeholder="0" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item {...validateEmail} label={"อีเมล"} name={"email"}>
                <Input maxLength={250} />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col span={8}>
              <Form.Item
                label={"จังหวัด"}
                name={"profile_province_code"}
                rules={[{ required: isRequireForm }]}
              >
                <Select
                  showSearch
                  allowClear
                  filterOption={(input, option: any) =>
                    option.key.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  placeholder="เลือก"
                  onChange={onChangeForDistrict}
                >
                  {provinceList.map((e) => (
                    <Option key={e.province_name} value={e.province_code}>
                      {e.province_name}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                label={"เขต/อำเภอ"}
                name={"profile_district_code"}
                rules={[{ required: isRequireForm }]}
              >
                <Select
                  allowClear
                  showSearch
                  filterOption={(input, option: any) =>
                    option.key.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  placeholder="เลือก"
                  onChange={onChangeForSubDistrict}
                >
                  {districtList.map((e) => (
                    <Option key={e.district_name} value={e.district_code}>
                      {e.district_name}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                label={"แขวง/ตำบล"}
                name={"profile_sub_district_code"}
                rules={[{ required: isRequireForm }]}
              >
                <Select
                  showSearch
                  allowClear
                  filterOption={(input, option: any) =>
                    option.key.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  placeholder="เลือก"
                >
                  {subDistrictList.map((e) => (
                    <Option
                      key={e.sub_district_name}
                      value={e.sub_district_code}
                    >
                      {e.sub_district_name}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col span={16}>
              <Form.Item label={"ที่อยู่"} name={"profile_address"}>
                <Input maxLength={250} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label={"รหัสไปรษณีย์"} name={"profile_zip_code"}>
                <Input maxLength={5} />
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </Spin>
    </div>
  );
};

export default CustomerDetailForm;
