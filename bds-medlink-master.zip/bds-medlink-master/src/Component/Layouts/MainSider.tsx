import { OrderedListOutlined } from "@ant-design/icons";
import { Menu, MenuProps } from "antd";
import Sider from "antd/es/layout/Sider";
import { useNavigate } from "react-router-dom";

const menuList: MenuProps["items"] = [
  {
    label: "ใบสั่งแพทย์", 
    key: "/",
    // icon: <OrderedListOutlined />,
  },
  // {
  //   label: "คำสั่งซื้อ",
  //   key: "orderList",
  //   // icon: <OrderedListOutlined />,
  // },
];

const MainSider = () => {
  const Navigate = useNavigate();
  return (
    <Sider style={{ backgroundColor: "white", }} width={200} > 
      <Menu mode="inline" items={menuList} 
      onClick={({key})=> {
        Navigate(key)
      }}
      ></Menu>
    </Sider>
  );
};

export default MainSider;
