import styled from "styled-components";
import { Input } from 'antd';

export const inputForm = styled(Input) `

`

export const tittle = styled.div`
    color:#50B0E9;
    padding:5px;
    display:flex;
    
`