import { Layout, Breadcrumb } from "antd";
import { useLocation } from "react-router";
import { Link } from "react-router-dom";

const MainContent = ({ children }: { children: JSX.Element }) => {
  const listPath: Record<string, string> = {
    '/PrescriptionForm/create': "บันทึกใบสั่งแพทย์",
    '/PrescriptionForm/:id': "ข้อมูลใบสั่งแพทย์",
  };

  const router = useLocation();
  const pathSnippets = router.pathname.split("./").filter((i) => i);

  const extraBreadcrumbItem = pathSnippets.map((path, index) => {
    const url = `${pathSnippets.slice(0, index + 1).join("/")}`;
    return (
      <Breadcrumb.Item key={url}>
        <Link to={url}>{listPath[url]}</Link>
      </Breadcrumb.Item>
    );
  });
  const breadcrumbItem = [
    <Breadcrumb.Item key={"home"}>
      <Link to="/">รายการใบสั่งแพทย์</Link>
    </Breadcrumb.Item>,
  ].concat(extraBreadcrumbItem);

  return (
    <Layout>
        <Breadcrumb style={{margin:'10px'}}>
        {breadcrumbItem}
        </Breadcrumb>
      <Layout.Content
        style={{
          padding: 24,
          margin: 0,
          // minHeight: 280,
          background: "white",
          overflow: 'auto'
        }}
      >
        {children}
      </Layout.Content>
    </Layout>
  );
};

export default MainContent;
