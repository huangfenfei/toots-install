import { Footer } from "antd/es/layout/layout";

const MainFooter = () => {
  return (
    <div>
      <Footer
        style={{
          backgroundColor: "#50B0E9",
          color: "white",
          textAlign: "left",
        }}
      >
        Powered© by Bangkok Drug Store Co., Ltd.  
        <label> [Version: 1.2.4]</label>
      </Footer>
    </div>
  );
};

export default MainFooter;
