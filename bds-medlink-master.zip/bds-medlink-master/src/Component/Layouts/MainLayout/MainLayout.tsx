import { Layout } from "antd";
import { Outlet } from "react-router-dom";
import MainFooter from "../MainFooter";
import MainHeader from "../MainHeader";
import MainSider from "../MainSider";
import MainContent from "../MainContent";

const MainLayout = () => {
  return (
    <Layout style={{ height: "100vh" }}>
      <MainHeader />
      <Layout>
        <MainSider />
        <Layout style={{ padding: "0 24px 24px" }}>
          <MainContent children={<Outlet />} />
        </Layout>
      </Layout>
      <MainFooter />
    </Layout>
  );
};

export default MainLayout;
