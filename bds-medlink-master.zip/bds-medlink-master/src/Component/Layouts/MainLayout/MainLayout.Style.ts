import { Header } from "antd/es/layout/layout";
import styled from "styled-components";
import { Image } from "antd";

export const MainHeader = styled(Header)`
  background-color: red;
`;

export const Logo = styled(Image)`
  width: 120px;
  height: 50px;
  /* margin: 16px 24px 16px 0; */
  /* background: rgba(255, 255, 255, 0.3); */
`;
