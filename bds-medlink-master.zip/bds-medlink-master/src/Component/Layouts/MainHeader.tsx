import { UserOutlined } from "@ant-design/icons";
import * as header from "./MainLayout/MainLayout.Style";
import { Avatar, Image } from "antd";
import Profile from "./Profile";
const MainHeader = () => {
  return (
    <header.MainHeader style={{ backgroundColor: "#50B0E9", display: "flex",justifyContent:'space-between' }}>
        <header.Logo
          src={require("../../Assets/Images/logo@2x.png")}
          style={{ width: 100 }}
          preview={false}
        />
      <Profile/>
         
    </header.MainHeader>
  );
};
export default MainHeader;
