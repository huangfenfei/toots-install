import { UserOutlined } from "@ant-design/icons";
import { Avatar, Button, Popover, message } from "antd";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { logout } from "../../Services/Auth.service";

const Profile = () => {
  const navigate = useNavigate();
  const fristName = localStorage.getItem('first_name')
  const lastName = localStorage.getItem('last_name')

  const onLogout = async () => {
    const id = window.sessionStorage.getItem("user_id") ?? "";
    const res = await logout(id);
    if (res.res_code === "000") {
      navigate("/Login");
      window.sessionStorage.clear();
    } else {
      message.error("ออกจากระบบไม่สำเร็จ");
    }
  };

  const content = (
    <div>
      <Button
        type="text"
        style={{
          display: "flex",
          color: "#000",
          width: '150px'
        }}
      >
        ข้อมูลส่วนบุคคล
      </Button>
      <Link 
        to={"/ResetPassword"}
      >
        <Button
          type="text"
          style={{
            display: "flex",
            marginTop: "10px",
            color: "#000",
            width: '150px'
          }}
        >
          เปลี่ยนรหัสผ่าน
        </Button>
      </Link>
      <Button
        type="text"
        style={{
          display: "flex",
          marginTop: "10px",
          color: "#000",
          width: '150px'
        }}
        onClick={onLogout}
      >
        ออกจากระบบ
      </Button>
    </div>
  );

  // const title = (
  //   <div>
  //     <span>
  //       {fristName} {lastName}
  //     </span>
  //   </div>
  // );

  return (
    <div>
      <Popover
        // overlayStyle={{
        //   width: "12vw",
        // }}
        content={content}
      >
        <Avatar
          size={35}
          icon={<UserOutlined />}
          style={{
            justifyContent: "flex-end",
            color: "#50B0E9",
            alignSelf: "center",
            backgroundColor: "#fff",
          }}
        />
        <span style={{ margin: "10px", color: "#fff" }}>{fristName} {lastName}</span>
      </Popover>
    </div>
  );
};

export default Profile;
