import { Button, Col, Input, message, Modal, Row, Table } from "antd";
import { ColumnsType, TableProps } from "antd/es/table";
import React, { useEffect, useState } from "react";
import axios from "axios";
import * as input from "../Layouts/FormInput.Style";
import ProductDetailModal from "./ProductDetailModal";
import EditProductModal from "./EditProductModal";
import { ItemType } from "../../Pages/Prescription/InterfaceType";

type TablePaginationPosition = "bottomCenter";

export interface ChildProps {
  onData: (data: string) => void;
  onCloseModal: (data: any) => void;
}

const SearchProductModal = ({ 
  onOK, 
  onCancel, 
  open, 
  props, 
  validItemList, 
  onCallback 
}: any) => {
  const [bottom] = useState<TablePaginationPosition>("bottomCenter");
  const [entities, setEntities] = useState<ItemType[]>([]);
  const [validItems, setValidItems] = useState<ItemType[]>(validItemList);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPage, setTotalPage] = useState(100);
  const [isLoading, setIsLoading] = useState(false);
  const [itemId, setItemId] = useState<string>();
  const [item, setItem] = useState<ItemType>();
  const [openProductDetail, setOpenProductDetail] = useState(false);
  const [isOpenEditProduct, setIsOpenEditProduct] = useState(false);
  const [itemName, setItemName] = useState("");
  const [itemComponent, setItemComponent] = useState("");
  const [itemMemo, setItemMemo] = useState("");

  const showProductDetalModal = (value: ItemType) => {
    setItemId(value.item_code);
    setOpenProductDetail(true);
  };

  const showEditProductModal = (value: ItemType) => {
    value.item_qty = 1;
    setItem(value);
    setIsOpenEditProduct(true); 
  }

  const onCallbackEditProduct = (value: ItemType) => {
    onCallback(value);
  }

  const handleAddButton = () => {
    const mapEntites = entities.map(obj1 => {
      const findValidItem = validItems.find((obj2) => {
        return obj1.item_code === obj2.item_code;
      });
      if (obj1.item_code === findValidItem?.item_code) {
        return {
          ...obj1,
          is_btn_add: true
        };
      } else {
        return {
          ...obj1,
          is_btn_add: false
        };
      }
    });
    setEntities(mapEntites);
  }

  const handleOnSearchName = (evt: any) => {
    const value = evt.target.value;
    setItemName(value);
    if (value.length >= 3) {
      onSearch(value, itemComponent, itemMemo);
    }
  }

  const handleOnSearchComponent = (evt: any) => {
    const value = evt.target.value;
    setItemComponent(value);
    if (value.length >= 3) {
      onSearch(itemName, value, itemMemo);
    }
  }

  const handleOnSearchMemo = (evt: any) => {
    const value = evt.target.value;
    setItemMemo(value);
    if (value.length >= 3) {
      onSearch(itemName, itemComponent, value);
    }
  }

  const onSearch = async (name: any, component: any, memo: any) => {
    const filter = {
      item_name: name,
      item_component: component,
      item_memo: memo,
      page: currentPage,
      limit: totalPage,
    };
    setIsLoading(true);

    await axios
      .post(`/api/v2/med-link/common/getProductByCondition`, filter)
      .then((res) => {
        const data = res.data.datas.entities;
        setEntities(data);

        if (res.data.res_code === "000") {
          setIsLoading(false);
          setTotalPage(res.data.datas.page_info.limit);
        } else if (res.data.res_code === "E101") {
          message.error("ไม่พบข้อมูลสินค้า")
        } else {
          message.error("กรุณาลองใหม่อีกครั้ง")
        }
      })
      .catch((error) => console.log(error));
  };

  const columnsProduct: ColumnsType<any> = [
    {
      title: "ชื่อยา",
      dataIndex: "item_name",
      width: "300px",
      align: "center"
    },
    {
      title: "ขนาด",
      dataIndex: "item_size",
      width: "120px",
      align: "center"
    },
    {
      title: "ราคา",
      dataIndex: "item_price",
      width: "70px",
      align: "center"
    },
    {
      title: "ส่วนประกอบ",
      dataIndex: "item_component",
      width: "500px",
      align: "center"
    },
    {
      title: "",
      width: "250px",
      align: "center",
      render: (item: ItemType) => (
        <div>
          <Row >
            <Col span={12}>
              <Button
                type="primary"
                disabled={!item.item_is_sale}
                onClick={() => showEditProductModal(item)}
              >
                เพิ่มรายการ
              </Button>
            </Col>
            <Col span={12}>
              <Button
                id="modal"
                onClick={() => showProductDetalModal(item)}
                type="default"
              >
                รายละเอียด
              </Button>
            </Col>
          </Row>
        </div>
      )
    },
  ];

  return (
    <div {...props} >
      <Modal
        title="ค้นหาสินค้า"
        centered
        open={open}
        onCancel={onCancel}
        footer={[
          <Button key="back" onClick={onCancel} type="default">
            ปิด
          </Button>,
        ]}
        width={1400}
      >
        <ProductDetailModal
          itemId={itemId}
          open={openProductDetail}
          onCancel={() => (setOpenProductDetail(false))}
        >
        </ProductDetailModal>
        <EditProductModal
          item={item}
          onOpen ={isOpenEditProduct}
          onCancel={() => (setIsOpenEditProduct(false))}
          onCallback={onCallbackEditProduct}
        >
        </EditProductModal>

        <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }} >
          <Col span={8}>
            <input.tittle>ชื่อยา</input.tittle>
            <Input onChange={handleOnSearchName} />
          </Col>
          <Col span={8}>
            <input.tittle>ส่วนประกอบ</input.tittle>
            <Input onChange={handleOnSearchComponent} />
          </Col>
          <Col span={8}>
            <input.tittle>ข้อบ่งใช้</input.tittle>
            <Input onChange={handleOnSearchMemo} />
          </Col>
        </Row>
        <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }} >
          <Col span={24}>
            <input.tittle>ค้นหารายการยา</input.tittle>
            <Table
              bordered
              rowKey={(record) => record.item_code}
              loading={isLoading}
              columns={columnsProduct}
              pagination={{ position: [bottom] }}
              dataSource={entities}
              scroll={{ y: 340 }}
            />
          </Col>
        </Row>
      </Modal>
    </div>
  );
};

export default SearchProductModal;