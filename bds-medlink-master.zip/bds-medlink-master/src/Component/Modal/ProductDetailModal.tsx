import {
  Form,
  Input,
  Modal,
  Image,
  Row,
  Col,
  Card,
  message,
  Divider,
  Spin,
  Button,
} from "antd";
import { useEffect, useState } from "react";
import { getProductById } from "../../Services/Product.service";

const ProductDetailModal = ({ onCancel, open, itemId, ...props }: any) => {
  const { TextArea } = Input;
  const [form] = Form.useForm();
  const [disableForm, setDisableForm] = useState(false);
  const [productDetail, setProductDetail] = useState<any>();
  const [images, setImages] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isDisplaySale, setIsDisplaySale] = useState(false);

  useEffect(() => {
    if (open) {
      getProductDetail();
    }
  }, [itemId]);

  useEffect(() => {
    if (productDetail === undefined) {
      return;
    }
    form.setFieldsValue({
      item_name: productDetail.item_name,
      item_size: productDetail.item_size,
      item_price: productDetail.item_price + " " + "บาท",
      item_acc: productDetail.item_acc,
      item_age: productDetail.item_age + " " + "เดือน",
      item_barcode: productDetail.item_barcode,
      item_component: productDetail.item_component,
      item_memo: productDetail.item_memo,
      item_method: productDetail.item_method1 + productDetail.item_method2,
      item_recommend: productDetail.item_recommend,
      item_warning: productDetail.item_warning,
      item_image: productDetail.item_image,
      item_is_sale_desc: productDetail.item_is_sale ? "" : "สินค้างดจำหน่าย"
    });

    setIsDisplaySale(productDetail.item_is_sale);
  }, [productDetail]);

  const getProductDetail = async () => {
    setIsLoading(true);
    const res = await getProductById(itemId);
    if (res.res_code === "000") {
      setIsLoading(false);
    } else if (res.res_code === "E101") {
      message.error("ไม่พบข้อมูลสินค้า");
    } else {
      message.error("ไม่พบข้อมูลสินค้า");
    }

    setProductDetail(res.datas);
    setImages(res.datas.item_image[0]);
    setDisableForm(true);
  };
  const layout = {
    labelCol: { span: 4 },
    wrapperCol: { span: 20 },
  };
  const formItemLayout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 16 },
  };
  return (
    <div {...props}>
      <Modal
        title="รายละเอียด"
        centered
        open={open}
        onCancel={onCancel}
        footer={[
          <Button key="back" onClick={onCancel} type="default">
            ปิด
          </Button>,
        ]}
        width={1000}
      >
        <Divider />
        <Spin spinning={isLoading}>
          <Form
            form={form}
            labelCol={{ span: 4 }}
            wrapperCol={{ span: 16 }}
            layout="horizontal"
            disabled={disableForm}
          >
            <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }}>
              <Col span={8}>
                <Form.Item
                  {...formItemLayout}
                  style={{
                    width: "calc(100% )",
                  }}
                  label="ชื่อยา"
                  name="item_name"
                >
                  <Input />
                </Form.Item>
              </Col>
              <Col span={8}>
                <Form.Item {...formItemLayout} label="ขนาด" name="item_size">
                  <Input />
                </Form.Item>
              </Col>
              <Col span={8} >
                <Form.Item name="item_is_sale_desc" hidden={isDisplaySale}>
                  <Input style={{
                    textAlign: "center",
                    }}/>
                </Form.Item>
              </Col>
            </Row>

            <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }}>
              <Col span={8}>
                <Form.Item {...formItemLayout} label="บัญชียา" name="item_acc">
                  <Input />
                </Form.Item>
              </Col>
              <Col span={8}>
                <Form.Item
                  {...formItemLayout}
                  label="อายุสินค้า"
                  name="item_age"
                >
                  <Input />
                </Form.Item>
              </Col>
              <Col span={8}>
                <Card style={{ height: 10, borderColor: "#fff" }}>
                  <Image src={images} />
                </Card>
              </Col>
            </Row>

            <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }}>
              <Col span={8}>
                <Form.Item {...formItemLayout} label="ราคา" name="item_price">
                  <Input />
                </Form.Item>
              </Col>
              <Col span={8}>
                <Form.Item
                  {...formItemLayout}
                  label="รหัส Barcode"
                  name="item_barcode"
                >
                  <Input />
                </Form.Item>
              </Col>
            </Row>

            <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }}>
              <Col span={16}>
                <Form.Item {...layout} label="ส่วนประกอบ" name="item_component">
                  <TextArea rows={2} />
                </Form.Item>
              </Col>
            </Row>
            <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }}>
              <Col span={16}>
                <Form.Item {...layout} label="ข้อบ่งใช้" name="item_memo">
                  <TextArea rows={2} />
                </Form.Item>
              </Col>
            </Row>
            <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }}>
              <Col span={16}>
                <Form.Item {...layout} label="วิธีใช้" name="item_method">
                  <TextArea rows={2} />
                </Form.Item>
              </Col>
            </Row>
            <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }}>
              <Col span={16}>
                <Form.Item {...layout} label="คำแนะนำ" name="item_recommend">
                  <TextArea rows={2} />
                </Form.Item>
              </Col>
            </Row>
            <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }}>
              <Col span={16}>
                <Form.Item {...layout} label="คำเตือน" name="item_warning">
                  <TextArea rows={2} />
                </Form.Item>
              </Col>
            </Row>
          </Form>
        </Spin>
      </Modal>
    </div>
  );
};

export default ProductDetailModal;
