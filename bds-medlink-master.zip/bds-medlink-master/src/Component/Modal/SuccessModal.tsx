import { Button, message, Modal, Space } from "antd";

const success = () => {
    setTimeout(() => {
        Modal.success({
            content: "การเข้าสู่ระบบเรียบร้อย",
        }); 
    }, 100 );
};

export const SuccessModal = ({ success, ...props }: any) => {

    return (
        <div {...props}>
            <Space wrap>
                <Button onClick={success}>Success</Button>
            </Space>
        </div>
    );
};

export default SuccessModal;