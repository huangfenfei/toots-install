import { Button, Modal, Space } from "antd";

const warning = () => {
    Modal.warning({
        title: 'This is a warning message',
        content: 'some messages...some messages...',
    });
};

export const warningModal = ({ warning, ...props }: any) => {
    return (
        <div {...props}>
            <Space wrap>
                <Button onClick={warning}>Warning</Button>
            </Space>
        </div>
    );
};

export default warningModal;