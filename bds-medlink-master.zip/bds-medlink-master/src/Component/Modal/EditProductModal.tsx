import { Button, Col, Form, Input, Modal, Row } from "antd";
import TextArea from "antd/es/input/TextArea";
import { useEffect } from "react";

const EditProductModal = ({
  onOpen,
  onCancel,
  item,
  onCallback,
  onFinish,
}: any) => {
  const [form] = Form.useForm();

  useEffect(() => {
    if (onOpen) {
      const detail =
        "- [1 ชิ้น = " + item.item_price + " บาท]" +
        (1 === item.item_sale_pack ? "" : ", [" + item.item_sale_pack + " ชิ้น = " +  item.item_sale_pack_price + " บาท]") +
        (1 === item.item_pack ? "" : ", [" + item.item_pack + " ชิ้น = " +  item.item_pack_price + " บาท]") +
        (item.item_pack === item.item_big_pack && item.item_pack_price === item.item_big_pack_price ? "" : ", [" + item.item_big_pack + " ชิ้น = " + item.item_big_pack_price + " บาท]") +
        "\n" +
        (item.item_max === 0 ? "- ไม่จำกัดจำนวนการซื้อ" : "- จำกัดการขาย " + item.item_max + " ชิ้น ต่อ 1 ใบเสร็จ");
      calculateTotalPrice();

      form.setFieldsValue({
        item_code: item.item_code,
        item_name: item.item_name,
        item_size: item.item_size,
        detail: detail,
        item_qty: item.item_qty,
        item_method: item.item_method,
        item_recommend: item.item_recommend,
        item_total_price: item.item_qty * item.item_price,
        remark: item.remark,
      });
    }
  }, [item]);

  const calculateTotalPrice = () => {
    let qty = form.getFieldValue("item_qty");
    let itemTotalPrice = 0;
    while (qty > 0) {
      if (qty >= item.item_sale_pack) {
        qty = qty - item.item_sale_pack;
        itemTotalPrice += item.item_sale_pack_price;
      } else if (qty >= item.item_big_pack) {
        qty = qty - item.item_big_pack;
        itemTotalPrice += item.item_big_pack_price;
      } else if (qty >= item.item_pack) {
        qty = qty - item.item_pack;
        itemTotalPrice += item.item_pack_price;
      } else {
        qty = qty - 1;
        itemTotalPrice += item.item_price;
      }
    }
    form.setFieldsValue({
      item_total_price: itemTotalPrice,
    });
  };

  const handleSubmit = () => {
    const data = {
      key: item.item_code,
      item_code: item.item_code,
      item_name: item.item_name,
      item_size: item.item_size,
      item_price: item.item_price,
      item_pack: item.item_pack,
      item_pack_price: item.item_pack_price,
      item_big_pack: item.item_big_pack,
      item_big_pack_price: item.item_big_pack_price,
      item_max: item.item_max,
      item_qty: Number(form.getFieldValue("item_qty")),
      item_method: form.getFieldValue("item_method"),
      item_recommend: form.getFieldValue("item_recommend"),
      item_total_price: Number(form.getFieldValue("item_total_price")),
      item_image: item.item_image,
      item_cat_id: item.item_cat_id,
      item_cat_type: item.item_cat_type,
      remark: form.getFieldValue("remark"),
    };
    onCancel(false);
    onCallback(data);
  };

  return (
    <div>
      <Modal
        title="แก้ไขรายละเอียดการเพิ่มสินค้า"
        centered
        open={onOpen}
        onCancel={onCancel}
        footer={[
          <Button type="primary" onClick={handleSubmit}>
            บันทึก
          </Button>,
          <Button key="back" type="default" onClick={onCancel}>
            ปิด
          </Button>,
        ]}
        width={800}
      >
        <Form layout="vertical" form={form} onFinish={onFinish}>
          <Row gutter={24}>
            <Col span={12}>
              <Form.Item label={"ชื่อยา"} name={"item_name"}>
                <Input disabled />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item label={"ขนาด"} name={"item_size"}>
                <Input disabled />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col span={24}>
              <Form.Item label="รายละเอียดการขาย" name={"detail"}>
                <TextArea style={{ resize: "none" }} disabled rows={3} />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col span={12}>
              <Form.Item label="จำนวน" name={"item_qty"}>
                <Input
                  style={{ textAlign: "end" }}
                  addonAfter="ชิ้น"
                  onChange={calculateTotalPrice}
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item label="ราคารวม" name={"item_total_price"}>
                <Input style={{ textAlign: "end" }} disabled addonAfter="บาท" />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col span={24}>
              <Form.Item label={"วิธีใช้"} name={"item_method"}>
                <TextArea style={{ resize: "none" }} rows={3} />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col span={24}>
              <Form.Item label={"คำแนะนำ"} name={"item_recommend"}>
                <TextArea style={{ resize: "none" }} rows={3} />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col span={24}>
              <Form.Item label={"หมายเหตุ"} name={"remark"}>
                <TextArea style={{ resize: "none" }} rows={3} />
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </Modal>
    </div>
  );
};

export default EditProductModal;
