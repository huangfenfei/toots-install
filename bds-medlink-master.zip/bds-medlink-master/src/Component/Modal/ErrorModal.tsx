import { Button, Modal, Space } from "antd";

const error = () => {
    setTimeout(() => { 
        Modal.error({
        title: 'This is an error message',
        content: 'some messages...some messages...',
        });
    }, 100 );
};

export const ErrorModal = ({ error, ...props }: any) => {

    return (
        <div {...props}>
            <Space wrap>
                <Button onClick={error}>Success</Button>
            </Space>
        </div>
    );
};

export default ErrorModal;