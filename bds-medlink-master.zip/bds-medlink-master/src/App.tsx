import "./App.css";
import { ConfigProvider, message, theme } from "antd";
import { AppRouter } from "./Routes/AppRouter";
import ReactDOM from "react-dom/client";
import axios from "axios";
import { createContext, useState } from "react";
import { isAuthen, logout } from "./Services/Auth.service";
import thTH from 'antd/locale/th_TH';
export const UserContext = createContext({} as userLogin)

interface userLogin {
  partner_code: string;
  id: string;
  username: string;
}
const App: React.FC = () => {
  const userLogin = {
    partner_code: sessionStorage.getItem('partner_code') ?? '',
    id: sessionStorage.getItem('user_id') ?? '',
    username: sessionStorage.getItem('username') ?? '',
  }
  
  const istAuth = isAuthen();
  const [] = useState(() => {
    axios.interceptors.request.use(
      (request) => {
        if ( istAuth) {
          request.headers.Authorization = istAuth
        }
        return request;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    const handleBeforeUnload = () => {
        logout(window.sessionStorage.getItem("user_id") ?? "");
      };
     axios.interceptors.response.use(
      (response) => {
        return response;
      },
      (error) => {
        const { status } = error.response;
        if (status === 403) {
          handleBeforeUnload()
        } else if (status === 404) {
          //message.error("Please contact support!");
        } else if (status === 400) {
          //message.error("Please contact support!");
        }
        console.log(error);
      }
    );
    window.addEventListener('beforeunload', handleBeforeUnload);
  });
  return (
    <div className="App">
      <ConfigProvider locale={thTH}
        theme={{
          components: {
            Form: {
              colorTextHeading: "#50B0E9",
            },
          },
          token: {
            colorPrimary: "#50B0E9",
            colorText: "#000",
            colorSuccess: "#78a500",
            colorWarning: "#ffb100",
            colorError: "#f25f0a",
            colorPrimaryBgHover: "#ffffff",
          },
        }}
      >
        <UserContext.Provider value={userLogin}>
        <AppRouter />
        </UserContext.Provider>
      </ConfigProvider>
    </div>
  );
};
export default App;
