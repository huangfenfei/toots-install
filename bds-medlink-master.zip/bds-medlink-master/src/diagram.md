```mermaid
sequenceDiagram
  actor User
  participant Line
  participant 1Moby
  participant Database
  participant Salesforce

  User ->>+ Line : User send message to Line.
  Line ->>+ 1Moby: Forward webhook'
  Line ->>- User: ""
  1Moby ->> Salesforce: Forward data from webhook
  1Moby ->> 1Moby: check is bot keyword.







```
