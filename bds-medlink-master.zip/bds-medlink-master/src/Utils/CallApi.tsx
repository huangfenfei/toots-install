import axios from 'axios';

export const getHost = () => {
    const host = "http://localhost:4000";
    return host;
}

export const getMethod = (url: string, config?: any) => axios
    .get(url, config)
    .then((res) => res.data)
    .catch((err) => err);

export const postMethod = (url: string, data?: any, config?: any) => axios
    .post(url, data, config)
    .then((res) => res.data)
    .catch((err) => err);

export const putMethod = (url: string, data?: any, config?: any) => axios
    .put(url, data, config)
    .then((res) => res.data)
    .catch((err) => err);

export const deleteMethod = (url: string, data?: any, config?: any) => axios
    .delete(url, config)
    .then((res) => res.data)
    .catch((err) => err);