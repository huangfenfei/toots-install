import { Space, Form, Input, Button, message } from "antd";
import { useNavigate } from "react-router-dom";
import { resetPassword } from "../../Services/Auth.service";

const ResetPassword = () => {

    const [form] = Form.useForm();
    const navigate = useNavigate();

    const handleConfirmPass = async () => {
        const userID = window.sessionStorage.getItem("user_id");
        const data = {
            current_password: form.getFieldValue("current_password"),
            new_password: form.getFieldValue("new_password")
        };
        const res = await resetPassword(userID, data);
        if (res?.data.res_code === "000") {
            message.success("เปลี่ยนรหัสผ่านเรียบร้อยแล้ว") 
            navigate("/");
        } else if (res?.data === "E101") {
            message.error("Token & user partner object id don't match")
        } else if (res?.data.res_code === "E102") {
            message.error("รหัสปัจจุบันและรหัสใหม่ซ้ำกัน โปรดลองอีกครั้ง")
        } else if (res?.data.res_code === "E103") {
            message.error("ไม่พบผู้ใช้งาน")
        } else if (res?.data.res_code === "E104") {
            message.error("รหัสปัจจุบันไม่ถูกต้อง")
        } else if (res?.data.res_code === "E105") {
            message.error("ไม่สามารถเปลี่ยนรหัสได้ โปรดลองอีกครั้ง") 
        } else {
            message.error("ไม่สามารถเปลี่ยนรหัสได้ โปรดลองอีกครั้ง")
        }
    };

    return (
        <Space 
            style={{
                justifyContent: "center",
                width: "100%",
                display: "center"
            }}
        >
            <Form 
                form={form}
                autoComplete="off"
                onFinish={handleConfirmPass}
                layout="vertical"
                style={{ width: 400}}
            >
                <Form.Item
                    label="รหัสปัจจุบัน"
                    name="current_password"
                    rules={[{ required: true, message: "กรุณากรอกรหัสปัจจุบัน" }]}
                >
                    <Input.Password  />
                </Form.Item>

                <Form.Item
                    label="รหัสใหม่"
                    name="new_password"
                    rules={[{ required: true, message: "กรุณากรอกรหัสใหม่" }]}
                    hasFeedback
                >
                    <Input.Password />
                </Form.Item>

                <Form.Item
                    label="ยืนยันรหัสใหม่"
                    name="confirmPassword"
                    dependencies={["new_password"]}
                    rules={[{ required: true, message: "กรุณายืนยันรหัสใหม่" },
                    ({ getFieldValue }) => ({
                        validator(_, value) {
                            if (!value || getFieldValue("new_password") === value) {
                                return Promise.resolve();
                            }
                            return Promise.reject(new Error("กรุณาป้อนรหัสผ่านที่ถูกต้อง"));
                        },
                    }),
                    ]}
                    hasFeedback
                >
                    <Input.Password />
                </Form.Item>

                <Form.Item>
                    <Button 
                        block
                        htmlType="submit" 
                        type="primary"
                        style={{ marginBottom: "1rem" }}
                    >
                        ยืนยันรหัสผ่าน
                    </Button>
                   
                    <Button  
                        block   
                        onClick={() => navigate("/")}
                    >
                        ยกเลิก
                    </Button>
                </Form.Item>

            </Form>
        </Space>
    );
}

export default ResetPassword;