import { Button, Form, Input, Card, Image, Space, message } from "antd";
import "../Login/Login.css";
import {login } from "../../Services/Auth.service";
import { useNavigate } from "react-router";

const Login = () => {
  const [form] = Form.useForm();
  const navigate = useNavigate();
  const submitLogin = async (value: string) => {
    const res = await login(value);
    if (res.res_code === "000") {
      window.sessionStorage.setItem("token", res.datas.token);
      window.sessionStorage.setItem("username", res.datas.username);
      window.sessionStorage.setItem("partner_code", res.datas.partner_code);
      window.sessionStorage.setItem("user_id", res.datas.id);
      window.sessionStorage.setItem("first_name", res.datas.first_name);
      window.sessionStorage.setItem("last_name", res.datas.last_name);
      window.sessionStorage.setItem(
        "screen_config",
        JSON.stringify(res.datas.screen_config)
      );
      // localStorage.setItem("tokens", res.datas.token);
      // localStorage.setItem("username", res.datas.username);
      // localStorage.setItem("partner_code", res.datas.partner_code);
      // localStorage.setItem("user_id", res.datas.id);
      // localStorage.setItem("first_name", res.datas.first_name);
      // localStorage.setItem("last_name", res.datas.last_name);
      // localStorage.setItem(
      //   "screen_config",
      //   JSON.stringify(res.datas.screen_config)
      // );
      
      message.open({
        type: "success",
        content: "Login sucess",
        duration: 2,
      });

      navigate("/PrescriptionList");
      window.location.reload();
    } else if (res.res_code === "E103") {
      message.open({
        type: "error",
        content: "ไม่สามารถเข้าใช้งานได้ เนื่องจากมีการเข้าใช้งานอยู่ !",
      });
    } else if (res.res_code === "E101" || res.res_code === "E102") {
      message.open({
        type: "error",
        content: "ไม่สามารถเข้าสู่ระบบได้ โปรดตรวจสอบข้อมูล !",
      });
    } else {
      message.error("ไม่สามารถเข้าสู่ระบบได้ โปรดลองอีกครั้ง");
    }
  };
  
  const onLoginFailed = (errorInfo: any) => {
    setTimeout(() => {
      message.error("การเข้าสู่ระบบล้มเหลว");
    }, 100);
  };

  return (
    <Space
      style={{
        alignItems: "center",
        display: "center",
        justifyContent: "center",
        height: "100vh",
        width: "100%",
      }}
    >
      <Card className="card_body">
        <Image
          className="login-logo"
          preview={false}
          style={{ width: "190px", marginBottom: "1.5rem", display: "grid" }}
          src={require("../../Assets/Images/logo@2x.png")}
        />

        <Form
          name="normal_login"
          form={form}
          className="login-form"
          onFinish={submitLogin}
          initialValues={{ remember: true }}
          onFinishFailed={onLoginFailed}
          autoComplete="off"
        >
          <Form.Item
            name="partner_code"
            className="parthner-form"
            rules={[{ required: true, message: "กรุณากรอกรหัส Parthner" }]}
          >
            <Input placeholder="รหัส Parthner" />
          </Form.Item>

          <Form.Item
            name="username"
            className="username-form"
            rules={[{ required: true, message: "กรุณากรอกชื่อผู้ใช้" }]}
          >
            <Input placeholder="ชื่อผู้ใช้งาน" />
          </Form.Item>

          <Form.Item
            name="password"
            className="password-form"
            rules={[{ required: true, message: "กรุณากรอกรหัสผ่าน" }]}
          >
            <Input.Password type="password" placeholder="รหัสผ่าน" />
          </Form.Item>

          <Form.Item>
            <Button htmlType="submit" className="login-form-button">
              เข้าสู่ระบบ
            </Button>
          </Form.Item>
            <label>Version: 1.2.3</label>
        </Form>
      </Card>
    </Space>
  );
};

export default Login;
