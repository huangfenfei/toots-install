export interface ValueType {
    key: string;
    value: string;
  }
  export interface DoctorsType {
    title: string;
    first_name: string;
    last_name: string;
    id: string;
  }
  export interface CountryType {
    key: React.Key;
    province_code: string;
    province_name: string;
    district_name: string;
    district_code: string;
    sub_district_code: string;
    sub_district_name: string;
  }
  export interface  SiteType {
    site_desc:string
    site_id:string
  }
  export interface ItemType {
    key: React.Key;
    item_code : string;
    item_name: string;
    item_qty: number;
    item_size: string;
    item_price: number;
    item_pack: number;
    item_pack_price: number;
    item_big_pack: number;
    item_big_pack_price: number;
    item_total_price: number;
    item_max: number;
    item_method: string;
    item_recommend: string;
    item_component: string;
    item_image: string;
    remark: string;
    item_is_sale: boolean;
    is_btn_add: boolean;
  }
  export interface ItemModalType {
    id : React.Key;
    item_name: string;
    item_size: number;
    item_price: number;
    item_qty: number;
    item_method: string;
    remark: string;
  }

  export interface DataListType {
    _id: React.Key;
    prescript_no: string;
    prescript_date: string;
    phone_number: string;
    profile_name: string;
    status: any;
    action: string;
    personal_info: any;
  }
  export interface StatusType {
    value: string;
    label: string;
  }

  export interface CommentType {
    comment: string;
    created_by: string;
    created_date: string;
    type: string;
  }