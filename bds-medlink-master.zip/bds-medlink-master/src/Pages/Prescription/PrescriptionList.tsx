import { Button, Col, Row, DatePicker, Table, Select, Popconfirm, message, Input } from "antd";
import type { ColumnsType } from "antd/es/table";
import * as input from "../../Component/Layouts/FormInput.Style";
import { useState, useEffect } from "react";
import dayjs from "dayjs";
import { Link } from "react-router-dom";
import { cancelPrescription, getPrescriptionBySearch } from "../../Services/Prescription.service";
import { DataListType, StatusType } from "./InterfaceType";
const { Option } = Select;

type TablePaginationPosition = "bottomCenter";
const PrescriptionList = () => {
  const [entities, setEntites] = useState<DataListType[]>([]);
  const [bottom] = useState<TablePaginationPosition>("bottomCenter");
  const [isLoading, setIsLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [startDate, setStartDate] = useState(dayjs().add(-1, "day").format('YYYY-MM-DD'));
  const [endDate, setEnddate] = useState<string>(dayjs().format('YYYY-MM-DD'));
  const [search, setSearch] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("ALL");
  const formatTabelDate = "YYYY-MM-DD";
  const [totalPages, setTotalPages] = useState()
  const Search = Input.Search;

  const prescriptList: ColumnsType<any> = [
    {
      title: "เลขที่ใบสั่งแพทย์",
      dataIndex: "prescript_no",
    },
    {
      title: "วันที่",
      dataIndex: "prescript_date",
    },
    {
      title: "สมาชิก",
      dataIndex: "full_name",
    },
    {
      title: "เบอร์โทรศัพท์",
      dataIndex: "phone_number",
    },
    {
      title: "แพทย์ผู้วินิจฉัย",
      dataIndex: "doctor_name",
    },
    {
      title: "สถานะ",
      dataIndex: "status_name",
    },
    {
      title: "สถานะการสั่งซื้อ",
      dataIndex: "order_status",
    },
    {
      title: "",
      dataIndex: "",
   
      render: (item: DataListType) => (
        <div>
          {item.status === "DRAFT" || item.status === "REJECT" ? (
            <>
            <Link
              style={{ margin: "3px" }}
              to={{
                pathname: `/PrescriptionForm/${item._id}`,
              }}
            >
              <Button type="primary"
                style={{
                  margin: "3px",
                  backgroundColor: "#FFB100",
                  width: "80px",
                }}
              >
                แก้ไข
              </Button>
            </Link>
              <Popconfirm
                placement="left"
                title={"ยืนยันการยกเลิกรายการนี้ใช่หรือไม่?"}
                onConfirm={() => onCancel(item._id)}
                okText="Yes"
                cancelText="No"
              >
                <Button
                  type="primary"
                  style={{
                    margin: "3px",
                    backgroundColor: "#F25F0A",
                    width: "80px",
                  }}
                >
                  ยกเลิก
                </Button>
              </Popconfirm>
            </>
          ) : (
            <Link
              style={{ margin: "3px" }}
              to={{
                pathname: `/PrescriptionForm/${item._id}`,
              }}
            >
              <Button type="primary" style={{
                width: "80px"
              }}>
                ดูข้อมูล
              </Button>
            </Link>
          )}
        </div>
      ),
    },
  ];

  const onCancel = async (id: any) => {
    const update_by = window.sessionStorage.getItem("username") ?? "";
    const res = await cancelPrescription(id, update_by);
    if (res?.data.res_code === "000") {
      message.success("ยกเลิกสำเร็จ");
    }
    fetchData();
  };

  const statusOptions: StatusType[] = [
    { value: "ALL", label: "ทั้งหมด" },
    { value: "INPROGRESS", label: "กำลังดำเนินการ" },
    { value: "WAITING", label: "รอดำเนินการ" },
    { value: "DRAFT", label: "แบบร่าง" },
    { value: "CANCEL", label: "ยกเลิก" },
    { value: "REJECT", label: "ปฏิเสธ" },
  ];

  const itemList =
    selectedStatus === "ALL"
      ? entities
      : entities.filter((item: any) => item.status === selectedStatus);

  const onSearch = (value: any) => {
    setSearch(value);
  };

  useEffect(() => {
    fetchData();
  }, [search, startDate, endDate,currentPage]);

  const fetchData = async () => {
    const body = {
      page: currentPage,
      limit: 20,
      partner_code: window.sessionStorage.getItem("partner_code"),
      start_prescript_date: startDate,
      end_prescript_date: endDate,
      search: search,
    };
    setIsLoading(true);
    const res = await getPrescriptionBySearch(body);
    const listItem = res.datas.entities;
    listItem.forEach((item: any) => {
      item.prescript_date = dayjs(item.prescript_date).format("YYYY-MM-DD");
      item.full_name = item.first_name + " " + item.last_name;
    });
    setEntites(listItem);
    setIsLoading(false);
    setTotalPages(res.datas.page_info.number_of_entities);
  };

  const onChangeStartDate = (date: any, dateString: string) => {
    setStartDate(dateString);
  };

  return (
    <>
      <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }}>
        <Col className="gutter-row" span={5}>
          <input.tittle>ค้นหา</input.tittle>
          <Search
          enterButton
          onSearch={onSearch} />
        </Col>
        <Col className="gutter-row" span={5}>
          <input.tittle>สถานะ</input.tittle>
          <Select
            value={selectedStatus}
            onChange={(key) => setSelectedStatus(key)}
            style={{
              border: 1,
              borderColor: "#0000",
              display: "flex",
              width: 200,
            }}
          >
            {statusOptions.map((status) => (
              <Option key={status.value} value={status.value}>
                {status.label}
              </Option>
            ))}
          </Select>
        </Col>
        <Col className="gutter-row" span={5}>
          <input.tittle>เลือกวันที่เริ่มต้น</input.tittle>
          <DatePicker
            format={formatTabelDate}
            defaultValue={dayjs().add(-1, "day")}
            style={{ display: "flex", width: 180 }}
            onChange={(date, dateString) => onChangeStartDate(date, dateString)}
          />
        </Col>
        <Col className="gutter-row" span={5}>
          <input.tittle>เลือกวันที่สิ้นสุด</input.tittle>
          <DatePicker
            format={formatTabelDate}
            defaultValue={dayjs()}
            style={{ display: "flex", width: 180 }}
            onChange={(date, dateString) => setEnddate(dateString)}
          />
        </Col>
        <Col className="gutter-row" span={4}>
          <input.tittle style={{ color: "white" }}>div</input.tittle>
          <a href="/PrescriptionForm/create">
            <Button
              type="primary"
              style={{
                backgroundColor: "#78A500",
                justifyContent: "center",
              }}
            >
              สร้างใบสั่งแพทย์
            </Button>
          </a>
        </Col>
      </Row>
      <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }}>
        <Col className="gutter-row" span={24} style={{ marginTop: 15 }}>
          <Table
            rowKey={(record:any) => record._id}
            bordered
            loading={isLoading}
            columns={prescriptList}
            dataSource={itemList}
            pagination={{
              total:totalPages,
              position: [bottom],
              pageSize: 20,
              onChange: (page:any) => {
                setCurrentPage(page);
              },
            }}
            scroll={{ y: 550,x:550 }}
          ></Table>
        </Col>
      </Row>
    </>
  );
};

export default PrescriptionList;
