import { Button, Form, Row, Space, Spin, message, Popconfirm } from "antd";
import { useNavigate, useParams } from "react-router";
import { createContext, useEffect, useState } from "react";
import { RcFile } from "antd/es/upload/interface";

import {
  cancelPrescription,
  getInitialConfig,
  getPrescriptionById,
  savePrescription,
} from "../../Services/Prescription.service";
import CustomerDetailForm from "../../Component/Prescription/CustomerDetailForm";
import PresrciptionDetailForm from "../../Component/Prescription/PresrciptionDetailForm";
import DeliveryDetailForm from "../../Component/Prescription/DeliveryDetailForm";
import CommentDetailForm from "../../Component/Prescription/CommentDetailForm";

import dayjs from "dayjs";

export const DataContext = createContext<any>({});

const PrescriptionForm = () => {
  const navigate = useNavigate();
  const username = window.sessionStorage.getItem("username");
  const partnerCode = window.sessionStorage.getItem("partner_code");
  const language = "th";
  const paramId = useParams();
  const [isLoading, setIsLoading] = useState(false);
  const [prescriptId, setPrescriptId] = useState("");
  const [prescriptData, setPrescriptData] = useState();
  const [action, setAction] = useState("");
  const [initialData, setInitialData] = useState();
  const [isDraftBtnHidden, setIsDraftBtnHidden] = useState(false);
  const [isSubmitBtnHidden, setIsSubmitBtnHidden] = useState(false);
  const [isCancelBtnHidden, setIsCancelBtnHidden] = useState(false);
  const [deliveryType, setDeliveryType] = useState("");

  const [form] = Form.useForm();

  useEffect(() => {
    getInitial();
    if (paramId.id !== "create") {
      fetchData();
      setPrescriptId(String(paramId.id));
    } else {
      setPrescriptId("000000000000000000000000");
      setIsCancelBtnHidden(true);
    }
  }, []);

  const fetchData = async () => {
    const res = await getPrescriptionById(paramId.id || "");
    setPrescriptData(res.datas);
    if (res.datas.status === "DRAFT" || res.datas.status === "REJECT") {
      setIsDraftBtnHidden(false);
      setIsSubmitBtnHidden(false);
      setIsCancelBtnHidden(false);
    } else {
      setIsDraftBtnHidden(true);
      setIsSubmitBtnHidden(true);
      setIsCancelBtnHidden(true);
    }
  };

  const getInitial = async () => {
    const data = {
      partner_code: partnerCode,
      username: username,
      language: language,
    };
    const res = await getInitialConfig(data);
    setInitialData(res.datas);
  };

  const onSavePrescription = async (datas: any) => {
    setIsLoading(true);
    const data = {
      id: prescriptId,
      action: action,
      update_by: username,
      partner_code: partnerCode,
      remark: datas.remark,
      personal_info: {
        action: datas.button_action,
        phone_number: datas.phone_number,
        date_of_birth: dayjs(datas.date_of_birth).format("YYYY-MM-DD"),
        citizen_id: datas.citizen_id,
        passport_id: datas.passport_id,
        first_name: datas.first_name,
        last_name: datas.last_name,
        gender: datas.gender,
        congenital_disease: datas.congenital_disease,
        drug_allergy: datas.drug_allergy,
        nation: datas.nation,
        weight: datas.weight,
        height: datas.height,
        email: datas.email,
        moi_code: datas.profile_sub_district_code,
        province_code: datas.profile_province_code,
        address: datas.profile_address,
        zip_code: datas.profile_zip_code,
      },
      prescript_info: {
        no: datas.prescript_no,
        date: dayjs(datas.prescript_date).format("YYYY-MM-DD"),
        doctor_id: datas.doctor_id,
        descritpion: "",
        symptom: datas.symptom,
        diagnosis: datas.diagnosis,
        attachment: [],
        detail: datas.detail,
        total_price: datas.total_price || 0,
        delivery_price: datas.delivery_price || 0,
        paid: datas.paid || 0,
        extra_payment: datas.extra_payment || 0,
      },
      delivery_info: {
        duplicate_address: datas.delivery_duplicate_address,
        type: datas.delivery_type,
        by: "2",
        moi_code: datas.delivery_sub_district_code,
        address: datas.delivery_address,
        phone_number: datas.delivery_phone_number,
        zip_code: datas.delivery_zip_code,
        fullname: datas.delivery_fullname,
        latitude: datas.delivery_latitude,
        longitude: datas.delivery_longitude,
        site_id: datas.delivery_site,
      },
    };
    const formData = new FormData();
    formData.append("data", JSON.stringify(data));
    if (datas.attachment) {
      datas.attachment.forEach((file: any) => {
        formData.append("files[]", file as RcFile);
      });
    }

    const res = await savePrescription(formData);
    setIsLoading(false);
    if (res?.data.res_code === "000") {
      message.success("บันทึกข้อมูลเสร็จสิ้น");
      navigate("/");
    } else if (res?.data.res_code === "E101") {
      message.error("ตรวจสอบข้อมูลไม่สำเร็จ ข้อมูลไม่ถูกต้อง กรุณาตรวจสอบข้อมูลอีกครั้ง หรือ ติดต่อ Call Center: 02-538-2229", 10);
    } else if (res?.data.res_code === "E104") {
      message.error("สินค้าไม่เพียงพอ", 10);
    }
  };

  const handleSubmit = (value: any) => {
    setAction(value);
    form.submit();
  };

  const handleCancel = async (value: any) => {
    const update_by = window.sessionStorage.getItem("username") ?? "";
    const res = await cancelPrescription(value, update_by);
    if (res?.data.res_code === "000") {
      message.success("ยกเลิกสำเร็จ");
      navigate("/");
    }
  };

  const handleOnChangeDeliveryType = (value: any) => {
    setDeliveryType(value);
  }

  const datas = { initialData, prescriptData };

  return (
    <div>
      <DataContext.Provider value={datas}>
        <Spin spinning={isLoading}>
          <CustomerDetailForm form={form} onFinish={onSavePrescription} />
          <PresrciptionDetailForm form={form} onFinish={onSavePrescription} deliveryType={deliveryType} />
          <DeliveryDetailForm form={form} onFinish={onSavePrescription} onChangeDeliveryType={handleOnChangeDeliveryType} />
          <Space style={{ marginBottom: 20, marginTop: 30 }}>
            <Row gutter={24} style={{ gap: 15, justifyContent: "flex-end" }}>
              {!isDraftBtnHidden ? (
                <Button
                  disabled={isDraftBtnHidden}
                  onClick={() => handleSubmit("DRAFT")}
                >
                  บันทึกแบบร่าง
                </Button>
              ) : (
                ""
              )}
              {!isSubmitBtnHidden ? (
                <Button
                  type="primary"
                  htmlType="submit"
                  style={{
                    display: "flex",
                    color: "white",
                    width: "120px",
                    justifyContent: "center",
                    backgroundColor: "#50B0E9",
                  }}
                  disabled={isSubmitBtnHidden}
                  onClick={() => handleSubmit("SUBMIT")}
                >
                  ส่งข้อมูล
                </Button>
              ) : (
                ""
              )}
              {!isCancelBtnHidden ? (
                <Popconfirm
                  placement="top"
                  title={"ยืนยันการยกเลิกรายการนี้ใช่หรือไม่?"}
                  onConfirm={() => handleCancel(prescriptId)}
                  okText="Yes"
                  cancelText="No"
                >
                  <Button
                    type="primary"
                    style={{
                      backgroundColor: "#F25F0A",
                      display: "flex",
                      color: "white",
                      width: "120px",
                      justifyContent: "center",
                    }}
                  >
                    ยกเลิกรายการ
                  </Button>
                </Popconfirm>
              ) : (
                ""
              )}
              <Button
                type="primary"
                style={{
                  display: "flex",
                  backgroundColor: "#6B6B6B",
                  color: "white",
                  width: "120px",
                  justifyContent: "center",
                }}
                onClick={() => navigate("/")}
              >
                ปิด
              </Button>
            </Row>
          </Space>
          <CommentDetailForm form={form} onFinish={onSavePrescription}/>
        </Spin>
      </DataContext.Provider>
    </div>
  );
};
export default PrescriptionForm;
