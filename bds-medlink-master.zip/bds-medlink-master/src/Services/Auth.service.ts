import axios from "axios";

export async function login(data: any) {
  try {
    const res = await axios.post(`/api/v2/med-link/auth/login`, data);
    return Promise.resolve(res.data);
  } catch (error) {
    console.log(error);

  }
}

export const isAuthen = () => {
  if (typeof window == "undefined") {
    return false;
  }
  // if (localStorage.getItem("tokens")) {
  //   return localStorage.getItem("tokens");
  // } else {
  //   return false;
  // }
  if (window.sessionStorage.getItem("token")) {
    return window.sessionStorage.getItem("token");
  } else {
    return false;
  }
};

export async function logout(id: string) {
  try {
    const res = await axios.get(
      `/api/v2/med-link/auth/logout/${id}`
    );
    return Promise.resolve(res.data);
  } catch (error) {
    console.log(error);
  }
}

export async function resetPassword(id: any, data: any) {
  try {
    const res = await axios.put(
      `/api/v2/med-link/setting/resetPassword/${id}`,  
      data
    );
    return Promise.resolve(res);
  } catch (error) {
    console.log(error);
  }
}
