import axios from "axios";

export async function searchProduct(data: any) {
    try {
        const res = await axios.post(
            `/api/v2/med-link/common/getProductByCondition`,data 
        );
        return Promise.resolve(res.data);
    } catch (error) {
        console.log(error);
    }
}

export async function getProductById(item_id: string) {
    try {
        const res = await axios.get(
            `/api/v2/med-link/common/getProductById/${item_id}`
        );
        return Promise.resolve(res.data);
    } catch (error) {
        console.log(error);
    }
}

