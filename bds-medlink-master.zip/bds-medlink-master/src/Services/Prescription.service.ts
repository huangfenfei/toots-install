import { message } from "antd";
import axios from "axios";

export async function getPrescriptionById(id: string) {
  try {
    const res = await axios.get(
      `/api/v2/med-link/prescription/getPrescriptionById/${id}`
    );
    return Promise.resolve(res.data);
  } catch (err) {
    console.log(err);
  }
}

export async function getPrescriptionBySearch(data: any) {
  try {
    const res = await axios.post(
      `/api/v2/med-link/prescription/getPrescriptionBySearch`,
      data
    );
    return Promise.resolve(res.data);
  } catch (err) {
    console.log(err);
  }
}

export async function validateProfile(phone_number: any, date_of_birth: any) {
  try {
    const res = await axios.get(
      `/api/v2/med-link/prescription/getValidateProfile/${phone_number}/${date_of_birth}`
    );
    return Promise.resolve(res.data);
  } catch (err) {
    console.log(err);
    message.error("ไม่สามารถค้นหาข้อมูลได้ โปรดตรวจสอบ !");
  }
}

export async function getInitialConfig(data: any) {
  try {
    const res = await axios.post(
      `/api/v2/med-link/prescription/getInitialConfig`,
      data
    );
    return Promise.resolve(res.data);
  } catch (err) {}
}

export async function prescriptionFile(data: any) {
  try {
    const res = await axios.post(
      `/api/v2/med-link/common/upload/prescriptionFile`,
      data
    );
    return Promise.resolve(res.data);
  } catch (error) {
    console.log(error);
  }
}

export async function getProvince(deliveryType: string, language: string) {
  try {
    const res = await axios.get(
      `/api/v2/med-link/common/getProvince/${deliveryType}/${language}`
    );
    return Promise.resolve(res.data);
  } catch (error) {}
}

export async function getDistrict(deliveryType: string, province_code: string, language: string) {
  try {
    const res = await axios.get(
      `/api/v2/med-link/common/getDistrict/${deliveryType}/${province_code}/${language}`
    );
    return Promise.resolve(res.data);
  } catch (error) {}
}

export async function getSubDistrict(deliveryType: string, district_code: string, language: string) {
  try {
    const res = await axios.get(
      `/api/v2/med-link/common/getSubDistrict/${deliveryType}/${district_code}/${language}`
    );
    return Promise.resolve(res.data);
  } catch (error) {}
}

export async function getValidateAddressDeliveryType(deliveryType: string, district_code: string) {
  try {
    const res = await axios.get(
      `/api/v2/med-link/common/getValidateAddressDeliveryType/${deliveryType}/${district_code}`
    );
    return Promise.resolve(res.data);
  } catch (error) {
    
  }
}

export async function getSite(data: any) {
  try {
    const res = await axios.get(`/api/v2/med-link/common/getSite`, data);
    return Promise.resolve(res.data);
  } catch (error) {}
}
export async function savePrescription(data: any) {
  try {
    const res = await axios.post(
      `/api/v2/med-link/prescription/savePrescriptionForm`,
      data
    );
    return Promise.resolve(res);
  } catch (err) {
    console.log(err);
  }
}
export async function cancelPrescription(id: string, update_by: string) {
  try {
    const res = await axios.delete(
      `/api/v2/med-link/prescription/cancelPrescription/${id}/${update_by}`
    );
    return Promise.resolve(res);
  } catch (error) {
    console.log(error);
  }
}
