const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function (app) {
  app.use(
    '/api',
    createProxyMiddleware({
      // target: 'http://localhost:4000',
      // target: 'https://dev-mobile.bangkokdrugstore.tech',
      // target: 'https://uat-mobile.bangkokdrugstore.tech',
      target: 'https://mobile.bangkokdrugstore.co.th',
      changeOrigin: true,
    })
  );
};