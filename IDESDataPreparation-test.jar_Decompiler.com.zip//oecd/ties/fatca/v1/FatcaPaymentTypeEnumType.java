package oecd.ties.fatca.v1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

@XmlType(
   name = "FatcaPaymentType_EnumType"
)
@XmlEnum
public enum FatcaPaymentTypeEnumType {
   @XmlEnumValue("FATCA501")
   FATCA_501("FATCA501"),
   @XmlEnumValue("FATCA502")
   FATCA_502("FATCA502"),
   @XmlEnumValue("FATCA503")
   FATCA_503("FATCA503"),
   @XmlEnumValue("FATCA504")
   FATCA_504("FATCA504");

   private final String value;

   private FatcaPaymentTypeEnumType(String v) {
      this.value = v;
   }

   public String value() {
      return this.value;
   }

   public static FatcaPaymentTypeEnumType fromValue(String v) {
      FatcaPaymentTypeEnumType[] var4;
      int var3 = (var4 = values()).length;

      for(int var2 = 0; var2 < var3; ++var2) {
         FatcaPaymentTypeEnumType c = var4[var2];
         if (c.value.equals(v)) {
            return c;
         }
      }

      throw new IllegalArgumentException(v);
   }
}
