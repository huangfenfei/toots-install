package oecd.ties.fatca.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import oecd.ties.stffatcatypes.v1.MonAmntType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "Payment_Type",
   propOrder = {"type", "paymentAmnt"}
)
public class PaymentType {
   @XmlElement(
      name = "Type",
      required = true
   )
   protected FatcaPaymentTypeEnumType type;
   @XmlElement(
      name = "PaymentAmnt",
      required = true
   )
   protected MonAmntType paymentAmnt;

   public FatcaPaymentTypeEnumType getType() {
      return this.type;
   }

   public void setType(FatcaPaymentTypeEnumType value) {
      this.type = value;
   }

   public MonAmntType getPaymentAmnt() {
      return this.paymentAmnt;
   }

   public void setPaymentAmnt(MonAmntType value) {
      this.paymentAmnt = value;
   }
}
