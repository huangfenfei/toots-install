package oecd.ties.fatca.v1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "Fatca_Type",
   propOrder = {"reportingFI", "reportingGroup"}
)
public class FatcaType {
   @XmlElement(
      name = "ReportingFI",
      required = true
   )
   protected CorrectableOrganisationPartyType reportingFI;
   @XmlElement(
      name = "ReportingGroup",
      required = true
   )
   protected List<FatcaType.ReportingGroup> reportingGroup;

   public CorrectableOrganisationPartyType getReportingFI() {
      return this.reportingFI;
   }

   public void setReportingFI(CorrectableOrganisationPartyType value) {
      this.reportingFI = value;
   }

   public List<FatcaType.ReportingGroup> getReportingGroup() {
      if (this.reportingGroup == null) {
         this.reportingGroup = new ArrayList();
      }

      return this.reportingGroup;
   }

   @XmlAccessorType(XmlAccessType.FIELD)
   @XmlType(
      name = "",
      propOrder = {"sponsor", "intermediary", "accountReport", "poolReport"}
   )
   public static class ReportingGroup {
      @XmlElement(
         name = "Sponsor"
      )
      protected CorrectableOrganisationPartyType sponsor;
      @XmlElement(
         name = "Intermediary"
      )
      protected CorrectableOrganisationPartyType intermediary;
      @XmlElement(
         name = "AccountReport"
      )
      protected List<CorrectableAccountReportType> accountReport;
      @XmlElement(
         name = "PoolReport"
      )
      protected List<CorrectablePoolReportType> poolReport;

      public CorrectableOrganisationPartyType getSponsor() {
         return this.sponsor;
      }

      public void setSponsor(CorrectableOrganisationPartyType value) {
         this.sponsor = value;
      }

      public CorrectableOrganisationPartyType getIntermediary() {
         return this.intermediary;
      }

      public void setIntermediary(CorrectableOrganisationPartyType value) {
         this.intermediary = value;
      }

      public List<CorrectableAccountReportType> getAccountReport() {
         if (this.accountReport == null) {
            this.accountReport = new ArrayList();
         }

         return this.accountReport;
      }

      public List<CorrectablePoolReportType> getPoolReport() {
         if (this.poolReport == null) {
            this.poolReport = new ArrayList();
         }

         return this.poolReport;
      }
   }
}
