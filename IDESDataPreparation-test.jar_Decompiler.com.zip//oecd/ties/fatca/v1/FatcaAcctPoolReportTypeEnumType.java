package oecd.ties.fatca.v1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

@XmlType(
   name = "FatcaAcctPoolReportType_EnumType"
)
@XmlEnum
public enum FatcaAcctPoolReportTypeEnumType {
   @XmlEnumValue("FATCA201")
   FATCA_201("FATCA201"),
   @XmlEnumValue("FATCA202")
   FATCA_202("FATCA202"),
   @XmlEnumValue("FATCA203")
   FATCA_203("FATCA203"),
   @XmlEnumValue("FATCA204")
   FATCA_204("FATCA204"),
   @XmlEnumValue("FATCA205")
   FATCA_205("FATCA205"),
   @XmlEnumValue("FATCA206")
   FATCA_206("FATCA206");

   private final String value;

   private FatcaAcctPoolReportTypeEnumType(String v) {
      this.value = v;
   }

   public String value() {
      return this.value;
   }

   public static FatcaAcctPoolReportTypeEnumType fromValue(String v) {
      FatcaAcctPoolReportTypeEnumType[] var4;
      int var3 = (var4 = values()).length;

      for(int var2 = 0; var2 < var3; ++var2) {
         FatcaAcctPoolReportTypeEnumType c = var4[var2];
         if (c.value.equals(v)) {
            return c;
         }
      }

      throw new IllegalArgumentException(v);
   }
}
