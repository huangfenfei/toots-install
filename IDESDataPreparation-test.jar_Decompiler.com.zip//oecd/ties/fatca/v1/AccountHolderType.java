package oecd.ties.fatca.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import oecd.ties.stffatcatypes.v1.OrganisationPartyType;
import oecd.ties.stffatcatypes.v1.PersonPartyType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "AccountHolder_Type",
   propOrder = {"individual", "organisation", "acctHolderType"}
)
public class AccountHolderType {
   @XmlElement(
      name = "Individual"
   )
   protected PersonPartyType individual;
   @XmlElement(
      name = "Organisation"
   )
   protected OrganisationPartyType organisation;
   @XmlElement(
      name = "AcctHolderType"
   )
   protected FatcaAcctHolderTypeEnumType acctHolderType;

   public PersonPartyType getIndividual() {
      return this.individual;
   }

   public void setIndividual(PersonPartyType value) {
      this.individual = value;
   }

   public OrganisationPartyType getOrganisation() {
      return this.organisation;
   }

   public void setOrganisation(OrganisationPartyType value) {
      this.organisation = value;
   }

   public FatcaAcctHolderTypeEnumType getAcctHolderType() {
      return this.acctHolderType;
   }

   public void setAcctHolderType(FatcaAcctHolderTypeEnumType value) {
      this.acctHolderType = value;
   }
}
