package oecd.ties.fatca.v1;

import javax.xml.bind.annotation.XmlRegistry;

@XmlRegistry
public class ObjectFactory {
   public PaymentType createPaymentType() {
      return new PaymentType();
   }

   public FATCAOECD createFATCAOECD() {
      return new FATCAOECD();
   }

   public CorrectablePoolReportType createCorrectablePoolReportType() {
      return new CorrectablePoolReportType();
   }

   public FatcaType.ReportingGroup createFatcaTypeReportingGroup() {
      return new FatcaType.ReportingGroup();
   }

   public CorrectableAccountReportType createCorrectableAccountReportType() {
      return new CorrectableAccountReportType();
   }

   public AccountHolderType createAccountHolderType() {
      return new AccountHolderType();
   }

   public DocSpecType createDocSpecType() {
      return new DocSpecType();
   }

   public CorrectableOrganisationPartyType createCorrectableOrganisationPartyType() {
      return new CorrectableOrganisationPartyType();
   }

   public FatcaType createFatcaType() {
      return new FatcaType();
   }
}
