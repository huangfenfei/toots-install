package oecd.ties.fatca.v1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import oecd.ties.stffatcatypes.v1.MonAmntType;
import oecd.ties.stffatcatypes.v1.PersonPartyType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "CorrectableAccountReport_Type",
   propOrder = {"docSpec", "accountNumber", "accountHolder", "substantialOwner", "accountBalance", "payment"}
)
public class CorrectableAccountReportType {
   @XmlElement(
      name = "DocSpec",
      required = true
   )
   protected DocSpecType docSpec;
   @XmlElement(
      name = "AccountNumber",
      required = true
   )
   protected String accountNumber;
   @XmlElement(
      name = "AccountHolder",
      required = true
   )
   protected AccountHolderType accountHolder;
   @XmlElement(
      name = "SubstantialOwner"
   )
   protected List<PersonPartyType> substantialOwner;
   @XmlElement(
      name = "AccountBalance",
      required = true
   )
   protected MonAmntType accountBalance;
   @XmlElement(
      name = "Payment"
   )
   protected List<PaymentType> payment;

   public DocSpecType getDocSpec() {
      return this.docSpec;
   }

   public void setDocSpec(DocSpecType value) {
      this.docSpec = value;
   }

   public String getAccountNumber() {
      return this.accountNumber;
   }

   public void setAccountNumber(String value) {
      this.accountNumber = value;
   }

   public AccountHolderType getAccountHolder() {
      return this.accountHolder;
   }

   public void setAccountHolder(AccountHolderType value) {
      this.accountHolder = value;
   }

   public List<PersonPartyType> getSubstantialOwner() {
      if (this.substantialOwner == null) {
         this.substantialOwner = new ArrayList();
      }

      return this.substantialOwner;
   }

   public MonAmntType getAccountBalance() {
      return this.accountBalance;
   }

   public void setAccountBalance(MonAmntType value) {
      this.accountBalance = value;
   }

   public List<PaymentType> getPayment() {
      if (this.payment == null) {
         this.payment = new ArrayList();
      }

      return this.payment;
   }
}
