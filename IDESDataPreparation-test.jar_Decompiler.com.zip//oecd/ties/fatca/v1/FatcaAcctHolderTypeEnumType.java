package oecd.ties.fatca.v1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

@XmlType(
   name = "FatcaAcctHolderType_EnumType"
)
@XmlEnum
public enum FatcaAcctHolderTypeEnumType {
   @XmlEnumValue("FATCA101")
   FATCA_101("FATCA101"),
   @XmlEnumValue("FATCA102")
   FATCA_102("FATCA102"),
   @XmlEnumValue("FATCA103")
   FATCA_103("FATCA103"),
   @XmlEnumValue("FATCA104")
   FATCA_104("FATCA104"),
   @XmlEnumValue("FATCA105")
   FATCA_105("FATCA105");

   private final String value;

   private FatcaAcctHolderTypeEnumType(String v) {
      this.value = v;
   }

   public String value() {
      return this.value;
   }

   public static FatcaAcctHolderTypeEnumType fromValue(String v) {
      FatcaAcctHolderTypeEnumType[] var4;
      int var3 = (var4 = values()).length;

      for(int var2 = 0; var2 < var3; ++var2) {
         FatcaAcctHolderTypeEnumType c = var4[var2];
         if (c.value.equals(v)) {
            return c;
         }
      }

      throw new IllegalArgumentException(v);
   }
}
