package oecd.ties.fatca.v1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import oecd.ties.stffatcatypes.v1.MessageSpecType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "",
   propOrder = {"messageSpec", "fatca"}
)
@XmlRootElement(
   name = "FATCA_OECD"
)
public class FATCAOECD {
   @XmlElement(
      name = "MessageSpec",
      required = true
   )
   protected MessageSpecType messageSpec;
   @XmlElement(
      name = "FATCA",
      required = true
   )
   protected List<FatcaType> fatca;
   @XmlAttribute
   protected String version;

   public MessageSpecType getMessageSpec() {
      return this.messageSpec;
   }

   public void setMessageSpec(MessageSpecType value) {
      this.messageSpec = value;
   }

   public List<FatcaType> getFATCA() {
      if (this.fatca == null) {
         this.fatca = new ArrayList();
      }

      return this.fatca;
   }

   public String getVersion() {
      return this.version;
   }

   public void setVersion(String value) {
      this.version = value;
   }
}
