package oecd.ties.fatca.v1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

@XmlType(
   name = "FatcaDocTypeIndic_EnumType"
)
@XmlEnum
public enum FatcaDocTypeIndicEnumType {
   @XmlEnumValue("FATCA1")
   FATCA_1("FATCA1"),
   @XmlEnumValue("FATCA2")
   FATCA_2("FATCA2"),
   @XmlEnumValue("FATCA3")
   FATCA_3("FATCA3"),
   @XmlEnumValue("FATCA4")
   FATCA_4("FATCA4"),
   @XmlEnumValue("FATCA11")
   FATCA_11("FATCA11"),
   @XmlEnumValue("FATCA12")
   FATCA_12("FATCA12"),
   @XmlEnumValue("FATCA13")
   FATCA_13("FATCA13"),
   @XmlEnumValue("FATCA14")
   FATCA_14("FATCA14");

   private final String value;

   private FatcaDocTypeIndicEnumType(String v) {
      this.value = v;
   }

   public String value() {
      return this.value;
   }

   public static FatcaDocTypeIndicEnumType fromValue(String v) {
      FatcaDocTypeIndicEnumType[] var4;
      int var3 = (var4 = values()).length;

      for(int var2 = 0; var2 < var3; ++var2) {
         FatcaDocTypeIndicEnumType c = var4[var2];
         if (c.value.equals(v)) {
            return c;
         }
      }

      throw new IllegalArgumentException(v);
   }
}
