package oecd.ties.fatca.v1;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import oecd.ties.stffatcatypes.v1.MonAmntType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "CorrectablePoolReport_Type",
   propOrder = {"docSpec", "accountCount", "accountPoolReportType", "poolBalance"}
)
public class CorrectablePoolReportType {
   @XmlElement(
      name = "DocSpec",
      required = true
   )
   protected DocSpecType docSpec;
   @XmlElement(
      name = "AccountCount",
      required = true
   )
   protected BigInteger accountCount;
   @XmlElement(
      name = "AccountPoolReportType",
      required = true
   )
   protected FatcaAcctPoolReportTypeEnumType accountPoolReportType;
   @XmlElement(
      name = "PoolBalance",
      required = true
   )
   protected MonAmntType poolBalance;

   public DocSpecType getDocSpec() {
      return this.docSpec;
   }

   public void setDocSpec(DocSpecType value) {
      this.docSpec = value;
   }

   public BigInteger getAccountCount() {
      return this.accountCount;
   }

   public void setAccountCount(BigInteger value) {
      this.accountCount = value;
   }

   public FatcaAcctPoolReportTypeEnumType getAccountPoolReportType() {
      return this.accountPoolReportType;
   }

   public void setAccountPoolReportType(FatcaAcctPoolReportTypeEnumType value) {
      this.accountPoolReportType = value;
   }

   public MonAmntType getPoolBalance() {
      return this.poolBalance;
   }

   public void setPoolBalance(MonAmntType value) {
      this.poolBalance = value;
   }
}
