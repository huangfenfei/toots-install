package oecd.ties.fatca.v1;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;

// $FF: synthetic class
@XmlSchema(
   namespace = "urn:oecd:ties:fatca:v1",
   elementFormDefault = XmlNsForm.QUALIFIED
)
interface package-info {
}
