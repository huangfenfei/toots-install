package oecd.ties.fatca.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import oecd.ties.stffatcatypes.v1.OrganisationPartyType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "CorrectableOrganisationParty_Type",
   propOrder = {"docSpec"}
)
public class CorrectableOrganisationPartyType extends OrganisationPartyType {
   @XmlElement(
      name = "DocSpec",
      required = true
   )
   protected DocSpecType docSpec;

   public DocSpecType getDocSpec() {
      return this.docSpec;
   }

   public void setDocSpec(DocSpecType value) {
      this.docSpec = value;
   }
}
