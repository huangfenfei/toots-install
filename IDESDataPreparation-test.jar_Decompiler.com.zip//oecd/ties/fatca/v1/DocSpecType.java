package oecd.ties.fatca.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "DocSpec_Type",
   propOrder = {"docTypeIndic", "docRefId", "corrMessageRefId", "corrDocRefId"}
)
public class DocSpecType {
   @XmlElement(
      name = "DocTypeIndic",
      required = true
   )
   protected FatcaDocTypeIndicEnumType docTypeIndic;
   @XmlElement(
      name = "DocRefId",
      required = true
   )
   protected String docRefId;
   @XmlElement(
      name = "CorrMessageRefId"
   )
   protected String corrMessageRefId;
   @XmlElement(
      name = "CorrDocRefId"
   )
   protected String corrDocRefId;

   public FatcaDocTypeIndicEnumType getDocTypeIndic() {
      return this.docTypeIndic;
   }

   public void setDocTypeIndic(FatcaDocTypeIndicEnumType value) {
      this.docTypeIndic = value;
   }

   public String getDocRefId() {
      return this.docRefId;
   }

   public void setDocRefId(String value) {
      this.docRefId = value;
   }

   public String getCorrMessageRefId() {
      return this.corrMessageRefId;
   }

   public void setCorrMessageRefId(String value) {
      this.corrMessageRefId = value;
   }

   public String getCorrDocRefId() {
      return this.corrDocRefId;
   }

   public void setCorrDocRefId(String value) {
      this.corrDocRefId = value;
   }
}
