package oecd.ties.stf.v4;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

@XmlType(
   name = "OECDNameType_EnumType",
   namespace = "urn:oecd:ties:stf:v4"
)
@XmlEnum
public enum OECDNameTypeEnumType {
   @XmlEnumValue("OECD201")
   OECD_201("OECD201"),
   @XmlEnumValue("OECD202")
   OECD_202("OECD202"),
   @XmlEnumValue("OECD203")
   OECD_203("OECD203"),
   @XmlEnumValue("OECD204")
   OECD_204("OECD204"),
   @XmlEnumValue("OECD205")
   OECD_205("OECD205"),
   @XmlEnumValue("OECD206")
   OECD_206("OECD206"),
   @XmlEnumValue("OECD207")
   OECD_207("OECD207"),
   @XmlEnumValue("OECD208")
   OECD_208("OECD208");

   private final String value;

   private OECDNameTypeEnumType(String v) {
      this.value = v;
   }

   public String value() {
      return this.value;
   }

   public static OECDNameTypeEnumType fromValue(String v) {
      OECDNameTypeEnumType[] var4;
      int var3 = (var4 = values()).length;

      for(int var2 = 0; var2 < var3; ++var2) {
         OECDNameTypeEnumType c = var4[var2];
         if (c.value.equals(v)) {
            return c;
         }
      }

      throw new IllegalArgumentException(v);
   }
}
