package oecd.ties.stf.v4;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

@XmlType(
   name = "OECDLegalAddressType_EnumType",
   namespace = "urn:oecd:ties:stf:v4"
)
@XmlEnum
public enum OECDLegalAddressTypeEnumType {
   @XmlEnumValue("OECD301")
   OECD_301("OECD301"),
   @XmlEnumValue("OECD302")
   OECD_302("OECD302"),
   @XmlEnumValue("OECD303")
   OECD_303("OECD303"),
   @XmlEnumValue("OECD304")
   OECD_304("OECD304"),
   @XmlEnumValue("OECD305")
   OECD_305("OECD305");

   private final String value;

   private OECDLegalAddressTypeEnumType(String v) {
      this.value = v;
   }

   public String value() {
      return this.value;
   }

   public static OECDLegalAddressTypeEnumType fromValue(String v) {
      OECDLegalAddressTypeEnumType[] var4;
      int var3 = (var4 = values()).length;

      for(int var2 = 0; var2 < var3; ++var2) {
         OECDLegalAddressTypeEnumType c = var4[var2];
         if (c.value.equals(v)) {
            return c;
         }
      }

      throw new IllegalArgumentException(v);
   }
}
