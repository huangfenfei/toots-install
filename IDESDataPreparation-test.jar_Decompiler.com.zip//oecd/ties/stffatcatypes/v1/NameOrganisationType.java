package oecd.ties.stffatcatypes.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import oecd.ties.stf.v4.OECDNameTypeEnumType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "NameOrganisation_Type",
   propOrder = {"value"}
)
public class NameOrganisationType {
   @XmlValue
   protected String value;
   @XmlAttribute
   protected OECDNameTypeEnumType nameType;

   public String getValue() {
      return this.value;
   }

   public void setValue(String value) {
      this.value = value;
   }

   public OECDNameTypeEnumType getNameType() {
      return this.nameType;
   }

   public void setNameType(OECDNameTypeEnumType value) {
      this.nameType = value;
   }
}
