package oecd.ties.stffatcatypes.v1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import oecd.ties.isofatcatypes.v1.CountryCodeType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "MessageSpec_Type",
   propOrder = {"sendingCompanyIN", "transmittingCountry", "receivingCountry", "messageType", "warning", "contact", "messageRefId", "corrMessageRefId", "reportingPeriod", "timestamp"}
)
public class MessageSpecType {
   @XmlElement(
      name = "SendingCompanyIN"
   )
   protected String sendingCompanyIN;
   @XmlElement(
      name = "TransmittingCountry",
      required = true
   )
   protected CountryCodeType transmittingCountry;
   @XmlElement(
      name = "ReceivingCountry",
      required = true
   )
   protected CountryCodeType receivingCountry;
   @XmlElement(
      name = "MessageType",
      required = true
   )
   protected MessageTypeEnumType messageType;
   @XmlElement(
      name = "Warning"
   )
   protected String warning;
   @XmlElement(
      name = "Contact"
   )
   protected String contact;
   @XmlElement(
      name = "MessageRefId",
      required = true
   )
   protected String messageRefId;
   @XmlElement(
      name = "CorrMessageRefId"
   )
   protected List<String> corrMessageRefId;
   @XmlElement(
      name = "ReportingPeriod",
      required = true
   )
   @XmlSchemaType(
      name = "date"
   )
   protected XMLGregorianCalendar reportingPeriod;
   @XmlElement(
      name = "Timestamp",
      required = true
   )
   @XmlSchemaType(
      name = "dateTime"
   )
   protected XMLGregorianCalendar timestamp;

   public String getSendingCompanyIN() {
      return this.sendingCompanyIN;
   }

   public void setSendingCompanyIN(String value) {
      this.sendingCompanyIN = value;
   }

   public CountryCodeType getTransmittingCountry() {
      return this.transmittingCountry;
   }

   public void setTransmittingCountry(CountryCodeType value) {
      this.transmittingCountry = value;
   }

   public CountryCodeType getReceivingCountry() {
      return this.receivingCountry;
   }

   public void setReceivingCountry(CountryCodeType value) {
      this.receivingCountry = value;
   }

   public MessageTypeEnumType getMessageType() {
      return this.messageType;
   }

   public void setMessageType(MessageTypeEnumType value) {
      this.messageType = value;
   }

   public String getWarning() {
      return this.warning;
   }

   public void setWarning(String value) {
      this.warning = value;
   }

   public String getContact() {
      return this.contact;
   }

   public void setContact(String value) {
      this.contact = value;
   }

   public String getMessageRefId() {
      return this.messageRefId;
   }

   public void setMessageRefId(String value) {
      this.messageRefId = value;
   }

   public List<String> getCorrMessageRefId() {
      if (this.corrMessageRefId == null) {
         this.corrMessageRefId = new ArrayList();
      }

      return this.corrMessageRefId;
   }

   public XMLGregorianCalendar getReportingPeriod() {
      return this.reportingPeriod;
   }

   public void setReportingPeriod(XMLGregorianCalendar value) {
      this.reportingPeriod = value;
   }

   public XMLGregorianCalendar getTimestamp() {
      return this.timestamp;
   }

   public void setTimestamp(XMLGregorianCalendar value) {
      this.timestamp = value;
   }
}
