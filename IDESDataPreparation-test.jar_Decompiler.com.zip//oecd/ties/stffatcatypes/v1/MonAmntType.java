package oecd.ties.stffatcatypes.v1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import oecd.ties.isofatcatypes.v1.CurrCodeType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "MonAmnt_Type",
   propOrder = {"value"}
)
public class MonAmntType {
   @XmlValue
   protected BigDecimal value;
   @XmlAttribute(
      required = true
   )
   protected CurrCodeType currCode;

   public BigDecimal getValue() {
      return this.value;
   }

   public void setValue(BigDecimal value) {
      this.value = value;
   }

   public CurrCodeType getCurrCode() {
      return this.currCode;
   }

   public void setCurrCode(CurrCodeType value) {
      this.currCode = value;
   }
}
