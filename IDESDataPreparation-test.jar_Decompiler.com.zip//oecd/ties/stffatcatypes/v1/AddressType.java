package oecd.ties.stffatcatypes.v1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlType;
import oecd.ties.stf.v4.OECDLegalAddressTypeEnumType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "Address_Type",
   propOrder = {"content"}
)
public class AddressType {
   @XmlElementRefs({@XmlElementRef(
   name = "AddressFix",
   namespace = "urn:oecd:ties:stffatcatypes:v1",
   type = JAXBElement.class
), @XmlElementRef(
   name = "AddressFree",
   namespace = "urn:oecd:ties:stffatcatypes:v1",
   type = JAXBElement.class
), @XmlElementRef(
   name = "CountryCode",
   namespace = "urn:oecd:ties:stffatcatypes:v1",
   type = JAXBElement.class
)})
   protected List<JAXBElement<?>> content;
   @XmlAttribute
   protected OECDLegalAddressTypeEnumType legalAddressType;

   public List<JAXBElement<?>> getContent() {
      if (this.content == null) {
         this.content = new ArrayList();
      }

      return this.content;
   }

   public OECDLegalAddressTypeEnumType getLegalAddressType() {
      return this.legalAddressType;
   }

   public void setLegalAddressType(OECDLegalAddressTypeEnumType value) {
      this.legalAddressType = value;
   }
}
