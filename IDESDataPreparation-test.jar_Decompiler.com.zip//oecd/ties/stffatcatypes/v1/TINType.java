package oecd.ties.stffatcatypes.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import oecd.ties.isofatcatypes.v1.CountryCodeType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "TIN_Type",
   propOrder = {"value"}
)
public class TINType {
   @XmlValue
   protected String value;
   @XmlAttribute
   protected CountryCodeType issuedBy;

   public String getValue() {
      return this.value;
   }

   public void setValue(String value) {
      this.value = value;
   }

   public CountryCodeType getIssuedBy() {
      return this.issuedBy;
   }

   public void setIssuedBy(CountryCodeType value) {
      this.issuedBy = value;
   }
}
