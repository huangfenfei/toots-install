package oecd.ties.stffatcatypes.v1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;

@XmlType(
   name = "MessageType_EnumType"
)
@XmlEnum
public enum MessageTypeEnumType {
   FATCA;

   public String value() {
      return this.name();
   }

   public static MessageTypeEnumType fromValue(String v) {
      return valueOf(v);
   }
}
