package oecd.ties.stffatcatypes.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "AddressFix_Type",
   propOrder = {"street", "buildingIdentifier", "suiteIdentifier", "floorIdentifier", "districtName", "pob", "postCode", "city", "countrySubentity"}
)
public class AddressFixType {
   @XmlElement(
      name = "Street"
   )
   protected String street;
   @XmlElement(
      name = "BuildingIdentifier"
   )
   protected String buildingIdentifier;
   @XmlElement(
      name = "SuiteIdentifier"
   )
   protected String suiteIdentifier;
   @XmlElement(
      name = "FloorIdentifier"
   )
   protected String floorIdentifier;
   @XmlElement(
      name = "DistrictName"
   )
   protected String districtName;
   @XmlElement(
      name = "POB"
   )
   protected String pob;
   @XmlElement(
      name = "PostCode"
   )
   protected String postCode;
   @XmlElement(
      name = "City",
      required = true
   )
   protected String city;
   @XmlElement(
      name = "CountrySubentity"
   )
   protected String countrySubentity;

   public String getStreet() {
      return this.street;
   }

   public void setStreet(String value) {
      this.street = value;
   }

   public String getBuildingIdentifier() {
      return this.buildingIdentifier;
   }

   public void setBuildingIdentifier(String value) {
      this.buildingIdentifier = value;
   }

   public String getSuiteIdentifier() {
      return this.suiteIdentifier;
   }

   public void setSuiteIdentifier(String value) {
      this.suiteIdentifier = value;
   }

   public String getFloorIdentifier() {
      return this.floorIdentifier;
   }

   public void setFloorIdentifier(String value) {
      this.floorIdentifier = value;
   }

   public String getDistrictName() {
      return this.districtName;
   }

   public void setDistrictName(String value) {
      this.districtName = value;
   }

   public String getPOB() {
      return this.pob;
   }

   public void setPOB(String value) {
      this.pob = value;
   }

   public String getPostCode() {
      return this.postCode;
   }

   public void setPostCode(String value) {
      this.postCode = value;
   }

   public String getCity() {
      return this.city;
   }

   public void setCity(String value) {
      this.city = value;
   }

   public String getCountrySubentity() {
      return this.countrySubentity;
   }

   public void setCountrySubentity(String value) {
      this.countrySubentity = value;
   }
}
