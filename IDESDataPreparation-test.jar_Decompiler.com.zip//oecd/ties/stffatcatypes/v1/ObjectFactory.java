package oecd.ties.stffatcatypes.v1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import oecd.ties.isofatcatypes.v1.CountryCodeType;

@XmlRegistry
public class ObjectFactory {
   private static final QName _AddressTypeAddressFree_QNAME = new QName("urn:oecd:ties:stffatcatypes:v1", "AddressFree");
   private static final QName _AddressTypeCountryCode_QNAME = new QName("urn:oecd:ties:stffatcatypes:v1", "CountryCode");
   private static final QName _AddressTypeAddressFix_QNAME = new QName("urn:oecd:ties:stffatcatypes:v1", "AddressFix");

   public NamePersonType.MiddleName createNamePersonTypeMiddleName() {
      return new NamePersonType.MiddleName();
   }

   public NameOrganisationType createNameOrganisationType() {
      return new NameOrganisationType();
   }

   public AddressFixType createAddressFixType() {
      return new AddressFixType();
   }

   public NamePersonType createNamePersonType() {
      return new NamePersonType();
   }

   public PersonPartyType createPersonPartyType() {
      return new PersonPartyType();
   }

   public PersonPartyType.BirthInfo createPersonPartyTypeBirthInfo() {
      return new PersonPartyType.BirthInfo();
   }

   public MonAmntType createMonAmntType() {
      return new MonAmntType();
   }

   public NamePersonType.LastName createNamePersonTypeLastName() {
      return new NamePersonType.LastName();
   }

   public OrganisationPartyType createOrganisationPartyType() {
      return new OrganisationPartyType();
   }

   public TINType createTINType() {
      return new TINType();
   }

   public NamePersonType.NamePrefix createNamePersonTypeNamePrefix() {
      return new NamePersonType.NamePrefix();
   }

   public NamePersonType.FirstName createNamePersonTypeFirstName() {
      return new NamePersonType.FirstName();
   }

   public PersonPartyType.BirthInfo.CountryInfo createPersonPartyTypeBirthInfoCountryInfo() {
      return new PersonPartyType.BirthInfo.CountryInfo();
   }

   public MessageSpecType createMessageSpecType() {
      return new MessageSpecType();
   }

   public AddressType createAddressType() {
      return new AddressType();
   }

   @XmlElementDecl(
      namespace = "urn:oecd:ties:stffatcatypes:v1",
      name = "AddressFree",
      scope = AddressType.class
   )
   public JAXBElement<String> createAddressTypeAddressFree(String value) {
      return new JAXBElement(_AddressTypeAddressFree_QNAME, String.class, AddressType.class, value);
   }

   @XmlElementDecl(
      namespace = "urn:oecd:ties:stffatcatypes:v1",
      name = "CountryCode",
      scope = AddressType.class
   )
   public JAXBElement<CountryCodeType> createAddressTypeCountryCode(CountryCodeType value) {
      return new JAXBElement(_AddressTypeCountryCode_QNAME, CountryCodeType.class, AddressType.class, value);
   }

   @XmlElementDecl(
      namespace = "urn:oecd:ties:stffatcatypes:v1",
      name = "AddressFix",
      scope = AddressType.class
   )
   public JAXBElement<AddressFixType> createAddressTypeAddressFix(AddressFixType value) {
      return new JAXBElement(_AddressTypeAddressFix_QNAME, AddressFixType.class, AddressType.class, value);
   }
}
