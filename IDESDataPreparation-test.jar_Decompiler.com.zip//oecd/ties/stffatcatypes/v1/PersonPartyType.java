package oecd.ties.stffatcatypes.v1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import oecd.ties.isofatcatypes.v1.CountryCodeType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "PersonParty_Type",
   propOrder = {"resCountryCode", "tin", "name", "address", "nationality", "birthInfo"}
)
public class PersonPartyType {
   @XmlElement(
      name = "ResCountryCode"
   )
   protected List<CountryCodeType> resCountryCode;
   @XmlElement(
      name = "TIN"
   )
   protected List<TINType> tin;
   @XmlElement(
      name = "Name",
      required = true
   )
   protected List<NamePersonType> name;
   @XmlElement(
      name = "Address",
      required = true
   )
   protected List<AddressType> address;
   @XmlElement(
      name = "Nationality"
   )
   protected List<CountryCodeType> nationality;
   @XmlElement(
      name = "BirthInfo"
   )
   protected PersonPartyType.BirthInfo birthInfo;

   public List<CountryCodeType> getResCountryCode() {
      if (this.resCountryCode == null) {
         this.resCountryCode = new ArrayList();
      }

      return this.resCountryCode;
   }

   public List<TINType> getTIN() {
      if (this.tin == null) {
         this.tin = new ArrayList();
      }

      return this.tin;
   }

   public List<NamePersonType> getName() {
      if (this.name == null) {
         this.name = new ArrayList();
      }

      return this.name;
   }

   public List<AddressType> getAddress() {
      if (this.address == null) {
         this.address = new ArrayList();
      }

      return this.address;
   }

   public List<CountryCodeType> getNationality() {
      if (this.nationality == null) {
         this.nationality = new ArrayList();
      }

      return this.nationality;
   }

   public PersonPartyType.BirthInfo getBirthInfo() {
      return this.birthInfo;
   }

   public void setBirthInfo(PersonPartyType.BirthInfo value) {
      this.birthInfo = value;
   }

   @XmlAccessorType(XmlAccessType.FIELD)
   @XmlType(
      name = "",
      propOrder = {"birthDate", "city", "citySubentity", "countryInfo"}
   )
   public static class BirthInfo {
      @XmlElement(
         name = "BirthDate"
      )
      @XmlSchemaType(
         name = "date"
      )
      protected XMLGregorianCalendar birthDate;
      @XmlElement(
         name = "City"
      )
      protected String city;
      @XmlElement(
         name = "CitySubentity"
      )
      protected String citySubentity;
      @XmlElement(
         name = "CountryInfo"
      )
      protected PersonPartyType.BirthInfo.CountryInfo countryInfo;

      public XMLGregorianCalendar getBirthDate() {
         return this.birthDate;
      }

      public void setBirthDate(XMLGregorianCalendar value) {
         this.birthDate = value;
      }

      public String getCity() {
         return this.city;
      }

      public void setCity(String value) {
         this.city = value;
      }

      public String getCitySubentity() {
         return this.citySubentity;
      }

      public void setCitySubentity(String value) {
         this.citySubentity = value;
      }

      public PersonPartyType.BirthInfo.CountryInfo getCountryInfo() {
         return this.countryInfo;
      }

      public void setCountryInfo(PersonPartyType.BirthInfo.CountryInfo value) {
         this.countryInfo = value;
      }

      @XmlAccessorType(XmlAccessType.FIELD)
      @XmlType(
         name = "",
         propOrder = {"countryCode", "formerCountryName"}
      )
      public static class CountryInfo {
         @XmlElement(
            name = "CountryCode"
         )
         protected CountryCodeType countryCode;
         @XmlElement(
            name = "FormerCountryName"
         )
         protected String formerCountryName;

         public CountryCodeType getCountryCode() {
            return this.countryCode;
         }

         public void setCountryCode(CountryCodeType value) {
            this.countryCode = value;
         }

         public String getFormerCountryName() {
            return this.formerCountryName;
         }

         public void setFormerCountryName(String value) {
            this.formerCountryName = value;
         }
      }
   }
}
