package oecd.ties.stffatcatypes.v1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import oecd.ties.fatca.v1.CorrectableOrganisationPartyType;
import oecd.ties.isofatcatypes.v1.CountryCodeType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "OrganisationParty_Type",
   propOrder = {"resCountryCode", "tin", "name", "address"}
)
@XmlSeeAlso({CorrectableOrganisationPartyType.class})
public class OrganisationPartyType {
   @XmlElement(
      name = "ResCountryCode"
   )
   protected List<CountryCodeType> resCountryCode;
   @XmlElement(
      name = "TIN"
   )
   protected List<TINType> tin;
   @XmlElement(
      name = "Name",
      required = true
   )
   protected List<NameOrganisationType> name;
   @XmlElement(
      name = "Address",
      required = true
   )
   protected List<AddressType> address;

   public List<CountryCodeType> getResCountryCode() {
      if (this.resCountryCode == null) {
         this.resCountryCode = new ArrayList();
      }

      return this.resCountryCode;
   }

   public List<TINType> getTIN() {
      if (this.tin == null) {
         this.tin = new ArrayList();
      }

      return this.tin;
   }

   public List<NameOrganisationType> getName() {
      if (this.name == null) {
         this.name = new ArrayList();
      }

      return this.name;
   }

   public List<AddressType> getAddress() {
      if (this.address == null) {
         this.address = new ArrayList();
      }

      return this.address;
   }
}
