package oecd.ties.stffatcatypes.v1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import oecd.ties.stf.v4.OECDNameTypeEnumType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "NamePerson_Type",
   propOrder = {"precedingTitle", "title", "firstName", "middleName", "namePrefix", "lastName", "generationIdentifier", "suffix", "generalSuffix"}
)
public class NamePersonType {
   @XmlElement(
      name = "PrecedingTitle"
   )
   protected String precedingTitle;
   @XmlElement(
      name = "Title"
   )
   protected List<String> title;
   @XmlElement(
      name = "FirstName",
      required = true
   )
   protected NamePersonType.FirstName firstName;
   @XmlElement(
      name = "MiddleName"
   )
   protected List<NamePersonType.MiddleName> middleName;
   @XmlElement(
      name = "NamePrefix"
   )
   protected NamePersonType.NamePrefix namePrefix;
   @XmlElement(
      name = "LastName",
      required = true
   )
   protected NamePersonType.LastName lastName;
   @XmlElement(
      name = "GenerationIdentifier"
   )
   protected List<String> generationIdentifier;
   @XmlElement(
      name = "Suffix"
   )
   protected List<String> suffix;
   @XmlElement(
      name = "GeneralSuffix"
   )
   protected String generalSuffix;
   @XmlAttribute
   protected OECDNameTypeEnumType nameType;

   public String getPrecedingTitle() {
      return this.precedingTitle;
   }

   public void setPrecedingTitle(String value) {
      this.precedingTitle = value;
   }

   public List<String> getTitle() {
      if (this.title == null) {
         this.title = new ArrayList();
      }

      return this.title;
   }

   public NamePersonType.FirstName getFirstName() {
      return this.firstName;
   }

   public void setFirstName(NamePersonType.FirstName value) {
      this.firstName = value;
   }

   public List<NamePersonType.MiddleName> getMiddleName() {
      if (this.middleName == null) {
         this.middleName = new ArrayList();
      }

      return this.middleName;
   }

   public NamePersonType.NamePrefix getNamePrefix() {
      return this.namePrefix;
   }

   public void setNamePrefix(NamePersonType.NamePrefix value) {
      this.namePrefix = value;
   }

   public NamePersonType.LastName getLastName() {
      return this.lastName;
   }

   public void setLastName(NamePersonType.LastName value) {
      this.lastName = value;
   }

   public List<String> getGenerationIdentifier() {
      if (this.generationIdentifier == null) {
         this.generationIdentifier = new ArrayList();
      }

      return this.generationIdentifier;
   }

   public List<String> getSuffix() {
      if (this.suffix == null) {
         this.suffix = new ArrayList();
      }

      return this.suffix;
   }

   public String getGeneralSuffix() {
      return this.generalSuffix;
   }

   public void setGeneralSuffix(String value) {
      this.generalSuffix = value;
   }

   public OECDNameTypeEnumType getNameType() {
      return this.nameType;
   }

   public void setNameType(OECDNameTypeEnumType value) {
      this.nameType = value;
   }

   @XmlAccessorType(XmlAccessType.FIELD)
   @XmlType(
      name = "",
      propOrder = {"value"}
   )
   public static class FirstName {
      @XmlValue
      protected String value;
      @XmlAttribute
      @XmlSchemaType(
         name = "anySimpleType"
      )
      protected String xnlNameType;

      public String getValue() {
         return this.value;
      }

      public void setValue(String value) {
         this.value = value;
      }

      public String getXnlNameType() {
         return this.xnlNameType;
      }

      public void setXnlNameType(String value) {
         this.xnlNameType = value;
      }
   }

   @XmlAccessorType(XmlAccessType.FIELD)
   @XmlType(
      name = "",
      propOrder = {"value"}
   )
   public static class LastName {
      @XmlValue
      protected String value;
      @XmlAttribute
      @XmlSchemaType(
         name = "anySimpleType"
      )
      protected String xnlNameType;

      public String getValue() {
         return this.value;
      }

      public void setValue(String value) {
         this.value = value;
      }

      public String getXnlNameType() {
         return this.xnlNameType;
      }

      public void setXnlNameType(String value) {
         this.xnlNameType = value;
      }
   }

   @XmlAccessorType(XmlAccessType.FIELD)
   @XmlType(
      name = "",
      propOrder = {"value"}
   )
   public static class MiddleName {
      @XmlValue
      protected String value;
      @XmlAttribute
      @XmlSchemaType(
         name = "anySimpleType"
      )
      protected String xnlNameType;

      public String getValue() {
         return this.value;
      }

      public void setValue(String value) {
         this.value = value;
      }

      public String getXnlNameType() {
         return this.xnlNameType;
      }

      public void setXnlNameType(String value) {
         this.xnlNameType = value;
      }
   }

   @XmlAccessorType(XmlAccessType.FIELD)
   @XmlType(
      name = "",
      propOrder = {"value"}
   )
   public static class NamePrefix {
      @XmlValue
      protected String value;
      @XmlAttribute
      @XmlSchemaType(
         name = "anySimpleType"
      )
      protected String xnlNameType;

      public String getValue() {
         return this.value;
      }

      public void setValue(String value) {
         this.value = value;
      }

      public String getXnlNameType() {
         return this.xnlNameType;
      }

      public void setXnlNameType(String value) {
         this.xnlNameType = value;
      }
   }
}
