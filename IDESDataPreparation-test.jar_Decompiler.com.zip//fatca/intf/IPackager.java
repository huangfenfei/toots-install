package fatca.intf;

import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.ArrayList;

public interface IPackager extends IPackagerExtra {
   String defaultKeystoreType = "pkcs12";
   String certificateType = "X.509";
   int maxAttemptsToCreateNewFile = 10;

   void setAesCipherOpMode(String var1) throws Exception;

   String getAesCipherOpMode();

   String signAndCreatePkgStreaming(String var1, PrivateKey var2, X509Certificate var3, String var4, String var5, X509Certificate var6, int var7, String var8) throws Exception;

   String signAndCreatePkg(String var1, PrivateKey var2, X509Certificate var3, String var4, String var5, X509Certificate var6, int var7, String var8) throws Exception;

   String createPkg(String var1, String var2, String var3, X509Certificate var4, int var5, String var6) throws Exception;

   ArrayList<String> unpack(String var1, String var2, String var3, String var4, String var5, String var6) throws Exception;

   ArrayList<String> unpack(String var1, PrivateKey var2) throws Exception;

   String signBinaryFileAndCreatePkgStreaming(String var1, PrivateKey var2, X509Certificate var3, String var4, String var5, X509Certificate var6, int var7, IPackager.MetadataFileFormat var8, String var9) throws Exception;

   String signBinaryFileAndCreatePkg(String var1, PrivateKey var2, X509Certificate var3, String var4, String var5, X509Certificate var6, int var7, IPackager.MetadataFileFormat var8, String var9) throws Exception;

   String signTextFileAndCreatePkgStreaming(String var1, PrivateKey var2, X509Certificate var3, String var4, String var5, X509Certificate var6, int var7, String var8) throws Exception;

   String signTextFileAndCreatePkg(String var1, PrivateKey var2, X509Certificate var3, String var4, String var5, X509Certificate var6, int var7, String var8) throws Exception;

   void setBufSize(int var1);

   int getBufSize();

   ISigner getSigner();

   void setSigner(ISigner var1);

   String encryptZipPkg(String var1, String var2, String var3, X509Certificate var4, String var5, X509Certificate var6, int var7, IPackager.MetadataFileFormat var8, IPackager.MetadataBinaryEncoding var9, String var10) throws Exception;

   String signAndCreatePkgWithApproverStreaming(String var1, PrivateKey var2, X509Certificate var3, String var4, String var5, X509Certificate var6, String var7, X509Certificate var8, int var9, String var10) throws Exception;

   String signAndCreatePkgWithApprover(String var1, PrivateKey var2, X509Certificate var3, String var4, String var5, X509Certificate var6, String var7, X509Certificate var8, int var9, String var10) throws Exception;

   String createPkgWithApprover(String var1, String var2, String var3, X509Certificate var4, String var5, X509Certificate var6, int var7, String var8) throws Exception;

   ArrayList<String> unpackForApprover(String var1, String var2, String var3, String var4, String var5, String var6) throws Exception;

   ArrayList<String> unpackForApprover(String var1, PrivateKey var2) throws Exception;

   public static enum AesCipherOpMode {
      CBC,
      ECB;
   }

   public static enum MetadataBinaryEncoding {
      NONE,
      BASE_64;
   }

   public static enum MetadataFileFormat {
      XML,
      TXT,
      JPG,
      PDF,
      RTF;
   }
}
