package fatca.intf;

public interface ISignerExtra {
   String getSignaturePrefix();

   void setSignaturePrefix(String var1);

   boolean isXmlChunkStreaming();

   void setXmlChunkStreaming(boolean var1);

   int getXmlChunkStreamingSize();

   void setXmlChunkStreamingSize(int var1);

   StringBuilder getDigestBuf();

   void setDigestBuf(StringBuilder var1);

   void setValidationSuccess(Boolean var1);

   void setValidateAllSignature(boolean var1);

   boolean isValidateAllSignature();

   Boolean isValidationSuccess();
}
