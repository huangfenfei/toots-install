package fatca;

import fatca.impl.FATCAPackager;
import fatca.intf.IPackager;
import fatca.intf.ISigner;
import fatca.util.UtilShared;
import java.io.BufferedReader;
import java.io.FileReader;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;
import org.apache.log4j.Logger;

public class FATCADataPrepPETestTool {
   protected Logger logger = Logger.getLogger((new Object() {
   }).getClass().getEnclosingClass().getName());
   protected String receiverPublicCertName = null;
   protected String senderPublicCertName = null;
   protected String approverPublicCertName = null;
   protected IPackager pkgr = new FATCAPackager();
   protected ISigner signer;
   protected String defaultConfigFile;
   protected X509Certificate receiverPublicCert;
   protected X509Certificate senderPublicCert;
   protected X509Certificate approverPublicCert;
   protected PrivateKey receiverPrivateKey;
   protected PrivateKey senderPrivateKey;
   protected PrivateKey approverPrivateKey;
   protected String senderGiin;
   protected String receiverGiin;
   protected String approverGiin;
   protected String metaDataEmail;

   public FATCADataPrepPETestTool() {
      this.signer = this.pkgr.getSigner();
      this.defaultConfigFile = "ConfigAndCmdsPackSample.txt";
      this.receiverPublicCert = null;
      this.senderPublicCert = null;
      this.approverPublicCert = null;
      this.receiverPrivateKey = null;
      this.senderPrivateKey = null;
      this.approverPrivateKey = null;
      this.senderGiin = null;
      this.receiverGiin = null;
      this.approverGiin = null;
      this.metaDataEmail = null;
   }

   private void readConfigAndExceuteCommands() throws Exception {
      this.readConfigAndExceuteCommands(this.defaultConfigFile);
   }

   protected void readConfigAndExceuteCommands(String conf) throws Exception {
      try {
         String senderPrivateKSFile = null;
         String senderPublicKSFile = null;
         String receiverPrivateKSFile = null;
         String receiverPublicKSFile = null;
         String approverPrivateKSFile = null;
         String approverPublicKSFile = null;
         String senderPrivateKeyPwd = null;
         String receiverPrivateKeyPwd = null;
         String approverPrivateKeyPwd = null;
         String senderPrivateKeyAlias = null;
         String senderPublicKeyAlias = null;
         String receiverPrivateKeyAlias = null;
         String receiverPublicKeyAlias = null;
         String approverPrivateKeyAlias = null;
         String approverPublicKeyAlias = null;
         String approverPublicKSType = "pkcs12";
         String approverPrivateKSType = "pkcs12";
         String receiverPublicKSType = "pkcs12";
         String receiverPrivateKSType = "pkcs12";
         String senderPublicKSType = "pkcs12";
         String senderPrivateKSType = "pkcs12";
         String approverPublicKSPwd = "pwd123";
         String approverPrivateKSPwd = "pwd123";
         String receiverPublicKSPwd = "pwd123";
         String receiverPrivateKSPwd = "pwd123";
         String senderPublicKSPwd = "pwd123";
         String senderPrivateKSPwd = "pwd123";
         int taxyear = -1;
         ArrayList<FATCADataPrepPETestTool.Cmd> listCmds = new ArrayList();
         BufferedReader br = new BufferedReader(new FileReader(conf));
         String input = null;
         String output = null;
         boolean isComment = false;

         String line;
         String key;
         String val;
         StringTokenizer st;
         FATCADataPrepPETestTool.Cmd cmd;
         while((line = br.readLine()) != null) {
            line = line.trim();
            if (!line.startsWith("//") && !line.startsWith("!")) {
               if (line.startsWith("/*") && !isComment) {
                  isComment = true;
               } else {
                  if (line.startsWith("*/") && isComment) {
                     isComment = false;
                     line = line.substring(2).trim();
                  }

                  if (!"".equals(line) && !isComment) {
                     val = null;
                     key = null;
                     st = new StringTokenizer(line, " =");
                     if (st.hasMoreTokens()) {
                        key = st.nextToken();
                        if (st.hasMoreTokens()) {
                           val = line.substring(key.length() + 1).trim();
                        }

                        if (val != null && "senderPrivateKSType".equalsIgnoreCase(key)) {
                           senderPrivateKSType = val;
                        } else if (val != null && "senderPublicKSType".equalsIgnoreCase(key)) {
                           senderPublicKSType = val;
                        } else if (val != null && "receiverPrivateKSType".equalsIgnoreCase(key)) {
                           receiverPrivateKSType = val;
                        } else if (val != null && "receiverPublicKSType".equalsIgnoreCase(key)) {
                           receiverPublicKSType = val;
                        } else if (val != null && "approverPrivateKSType".equalsIgnoreCase(key)) {
                           approverPrivateKSType = val;
                        } else if (val != null && "approverPublicKSType".equalsIgnoreCase(key)) {
                           approverPublicKSType = val;
                        } else if (val != null && "senderPrivateKSFile".equalsIgnoreCase(key)) {
                           senderPrivateKSFile = val;
                           if (val.endsWith(".jks")) {
                              senderPrivateKSType = "jks";
                           }
                        } else if (val != null && "senderPublicKSFile".equalsIgnoreCase(key)) {
                           senderPublicKSFile = val;
                           if (val.endsWith(".jks")) {
                              senderPublicKSType = "jks";
                           }
                        } else if (val != null && "receiverPrivateKSFile".equalsIgnoreCase(key)) {
                           receiverPrivateKSFile = val;
                           if (val.endsWith(".jks")) {
                              receiverPrivateKSType = "jks";
                           }
                        } else if (val != null && "receiverPublicKSFile".equalsIgnoreCase(key)) {
                           receiverPublicKSFile = val;
                           if (val.endsWith(".jks")) {
                              receiverPublicKSType = "jks";
                           }
                        } else if (val != null && "approverPrivateKSFile".equalsIgnoreCase(key)) {
                           approverPrivateKSFile = val;
                           if (val.endsWith(".jks")) {
                              approverPrivateKSType = "jks";
                           }
                        } else if (val != null && "approverPublicKSFile".equalsIgnoreCase(key)) {
                           approverPublicKSFile = val;
                           if (val.endsWith(".jks")) {
                              approverPublicKSType = "jks";
                           }
                        } else if (val != null && "senderPrivateKSPwd".equalsIgnoreCase(key)) {
                           senderPrivateKSPwd = val;
                        } else if (val != null && "senderPublicKSPwd".equalsIgnoreCase(key)) {
                           senderPublicKSPwd = val;
                        } else if (val != null && "receiverPublicCertName".equalsIgnoreCase(key)) {
                           this.receiverPublicCertName = val;
                        } else if (val != null && "senderPublicCertName".equalsIgnoreCase(key)) {
                           this.senderPublicCertName = val;
                        } else if (val != null && "approverPublicCertName".equalsIgnoreCase(key)) {
                           this.approverPublicCertName = val;
                        } else if (val != null && "receiverPrivateKSPwd".equalsIgnoreCase(key)) {
                           receiverPrivateKSPwd = val;
                        } else if (val != null && "receiverPublicKSPwd".equalsIgnoreCase(key)) {
                           receiverPublicKSPwd = val;
                        } else if (val != null && "approverPrivateKSPwd".equalsIgnoreCase(key)) {
                           approverPrivateKSPwd = val;
                        } else if (val != null && "approverPublicKSPwd".equalsIgnoreCase(key)) {
                           approverPublicKSPwd = val;
                        } else if (val != null && "senderPrivateKeyPwd".equalsIgnoreCase(key)) {
                           senderPrivateKeyPwd = val;
                        } else if (val != null && "receiverPrivateKeyPwd".equalsIgnoreCase(key)) {
                           receiverPrivateKeyPwd = val;
                        } else if (val != null && "approverPrivateKeyPwd".equalsIgnoreCase(key)) {
                           approverPrivateKeyPwd = val;
                        } else if (val != null && "senderPrivateKeyAlias".equalsIgnoreCase(key)) {
                           senderPrivateKeyAlias = val;
                        } else if (val != null && "senderPublicKeyAlias".equalsIgnoreCase(key)) {
                           senderPublicKeyAlias = val;
                        } else if (val != null && "receiverPrivateKeyAlias".equalsIgnoreCase(key)) {
                           receiverPrivateKeyAlias = val;
                        } else if (val != null && "receiverPublicKeyAlias".equalsIgnoreCase(key)) {
                           receiverPublicKeyAlias = val;
                        } else if (val != null && "approverPrivateKeyAlias".equalsIgnoreCase(key)) {
                           approverPrivateKeyAlias = val;
                        } else if (val != null && "approverPublicKeyAlias".equalsIgnoreCase(key)) {
                           approverPublicKeyAlias = val;
                        } else if (val != null && "senderGiin".equalsIgnoreCase(key)) {
                           this.senderGiin = val;
                        } else if (val != null && "receiverGiin".equalsIgnoreCase(key)) {
                           this.receiverGiin = val;
                        } else if (val != null && "approverGiin".equalsIgnoreCase(key)) {
                           this.approverGiin = val;
                        } else if (val != null && "taxYear".equalsIgnoreCase(key)) {
                           taxyear = Integer.parseInt(val);
                        } else {
                           cmd = new FATCADataPrepPETestTool.Cmd();
                           cmd.cmdStr = key;
                           listCmds.add(cmd);
                           if ("stop".equalsIgnoreCase(cmd.cmdStr)) {
                              break;
                           }

                           if (val != null) {
                              st = new StringTokenizer(val);

                              while(st.hasMoreTokens()) {
                                 val = st.nextToken();
                                 int pos = val.indexOf(61);
                                 if (pos == -1) {
                                    cmd.hashCmdArgs.put(cmd.cmdStr, val);
                                    break;
                                 }

                                 cmd.hashCmdArgs.put(val.substring(0, pos).toLowerCase(), val.substring(pos + 1));
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         br.close();
         if (receiverPublicKSType != null && receiverPublicKSFile != null && receiverPublicKSPwd != null) {
            try {
               this.receiverPublicCert = UtilShared.getCert(receiverPublicKSType, receiverPublicKSFile, receiverPublicKSPwd, receiverPublicKeyAlias);
            } catch (Exception var60) {
            }
         }

         if (this.receiverPublicCert == null && this.receiverPublicCertName != null) {
            try {
               this.receiverPublicCert = (X509Certificate)UtilShared.getCert(this.receiverPublicCertName);
            } catch (Exception var59) {
            }
         }

         if (senderPublicKSType != null && senderPublicKSFile != null && senderPublicKSPwd != null) {
            try {
               this.senderPublicCert = UtilShared.getCert(senderPublicKSType, senderPublicKSFile, senderPublicKSPwd, senderPublicKeyAlias);
            } catch (Exception var58) {
            }
         }

         if (this.senderPublicCert == null && this.senderPublicCertName != null) {
            try {
               this.senderPublicCert = (X509Certificate)UtilShared.getCert(this.senderPublicCertName);
            } catch (Exception var57) {
            }
         }

         if (approverPublicKSType != null && approverPublicKSFile != null && approverPublicKSPwd != null) {
            try {
               this.approverPublicCert = UtilShared.getCert(approverPublicKSType, approverPublicKSFile, approverPublicKSPwd, approverPublicKeyAlias);
            } catch (Exception var56) {
            }
         }

         if (this.approverPublicCert == null && this.approverPublicCertName != null) {
            try {
               this.approverPublicCert = (X509Certificate)UtilShared.getCert(this.approverPublicCertName);
            } catch (Exception var55) {
            }
         }

         if (senderPrivateKSType != null && senderPrivateKSFile != null && senderPrivateKeyPwd != null && senderPrivateKSPwd != null) {
            try {
               this.senderPrivateKey = UtilShared.getPrivateKey(senderPrivateKSType, senderPrivateKSFile, senderPrivateKSPwd, senderPrivateKeyPwd, senderPrivateKeyAlias);
            } catch (Exception var54) {
            }
         }

         if (receiverPrivateKSType != null && receiverPrivateKSFile != null && receiverPrivateKeyPwd != null && receiverPrivateKSPwd != null) {
            try {
               this.receiverPrivateKey = UtilShared.getPrivateKey(receiverPrivateKSType, receiverPrivateKSFile, receiverPrivateKSPwd, receiverPrivateKeyPwd, receiverPrivateKeyAlias);
            } catch (Exception var53) {
            }
         }

         if (approverPrivateKSType != null && approverPrivateKSFile != null && approverPrivateKeyPwd != null && approverPrivateKSPwd != null) {
            try {
               this.approverPrivateKey = UtilShared.getPrivateKey(approverPrivateKSType, approverPrivateKSFile, approverPrivateKSPwd, approverPrivateKeyPwd, approverPrivateKeyAlias);
            } catch (Exception var52) {
            }
         }

         IPackager.MetadataFileFormat fileFormat = null;
         IPackager.MetadataBinaryEncoding binaryEncoding = null;

         for(int i = 0; i < listCmds.size(); ++i) {
            cmd = (FATCADataPrepPETestTool.Cmd)listCmds.get(i);
            if ("stop".equalsIgnoreCase(cmd.cmdStr) || "exit".equalsIgnoreCase(cmd.cmdStr)) {
               break;
            }

            if ("isWrapperXsi".equalsIgnoreCase(cmd.cmdStr)) {
               this.signer.setWrapperXsi("true".equals(cmd.hashCmdArgs.get(cmd.cmdStr)));
            } else if ("isWrapperXsiSchemaLoc".equalsIgnoreCase(cmd.cmdStr)) {
               this.signer.setWrapperXsiSchemaLoc("true".equals(cmd.hashCmdArgs.get(cmd.cmdStr)));
            } else if ("isXmlChunkStreaming".equalsIgnoreCase(cmd.cmdStr)) {
               this.signer.setXmlChunkStreaming("true".equals(cmd.hashCmdArgs.get(cmd.cmdStr)));
            } else if ("xmlChunkStreamingSize".equalsIgnoreCase(cmd.cmdStr)) {
               this.signer.setXmlChunkStreamingSize(Integer.parseInt((String)cmd.hashCmdArgs.get(cmd.cmdStr)));
            } else if ("wrapperXsiSchemaLoc".equalsIgnoreCase(cmd.cmdStr)) {
               this.signer.setWrapperXsiSchemaLoc((String)cmd.hashCmdArgs.get(cmd.cmdStr));
            } else if ("isValidateAllSignature".equalsIgnoreCase(cmd.cmdStr)) {
               this.pkgr.getSigner().setValidateAllSignature("true".equals(cmd.hashCmdArgs.get(cmd.cmdStr)));
            } else if ("keepSignedXmlAfterSignAndCreatePkgFlag".equalsIgnoreCase(cmd.cmdStr)) {
               this.pkgr.setKeepSignedXmlAfterSignAndCreatePkgFlag("true".equals(cmd.hashCmdArgs.get(cmd.cmdStr)));
            } else if ("wrapperNS".equalsIgnoreCase(cmd.cmdStr)) {
               this.signer.setWrapperNS((String)cmd.hashCmdArgs.get(cmd.cmdStr));
            } else if ("wrapperPrefix".equalsIgnoreCase(cmd.cmdStr)) {
               this.signer.setWrapperPrefix((String)cmd.hashCmdArgs.get(cmd.cmdStr));
            } else if ("signaturePrefix".equalsIgnoreCase(cmd.cmdStr)) {
               this.signer.setSignaturePrefix((String)cmd.hashCmdArgs.get(cmd.cmdStr));
            } else if ("aesCipherOpMode".equalsIgnoreCase(cmd.cmdStr)) {
               this.pkgr.setAesCipherOpMode((String)cmd.hashCmdArgs.get(cmd.cmdStr));
            } else if ("isDualModeDecryption".equalsIgnoreCase(cmd.cmdStr)) {
               this.pkgr.setDualModeDecryption("true".equalsIgnoreCase((String)cmd.hashCmdArgs.get(cmd.cmdStr)));
            } else if ("sigRefIdPos".equalsIgnoreCase(cmd.cmdStr)) {
               this.pkgr.getSigner().setSigRefIdPos((String)cmd.hashCmdArgs.get(cmd.cmdStr));
            } else if ("sigXmlTransform".equalsIgnoreCase(cmd.cmdStr)) {
               this.pkgr.getSigner().setSigXmlTransform((String)cmd.hashCmdArgs.get(cmd.cmdStr));
            } else {
               key = "input";
               if (cmd.hashCmdArgs.containsKey(key)) {
                  input = (String)cmd.hashCmdArgs.get(key);
               } else {
                  input = (String)cmd.hashCmdArgs.get(cmd.cmdStr);
               }

               if (input == null) {
                  input = output;
               }

               output = null;
               key = "output";
               if (cmd.hashCmdArgs.containsKey(key)) {
                  output = (String)cmd.hashCmdArgs.get(key);
               }

               if (input == null) {
                  this.logger.error("ERROR: invalid cmd or missing input. cmd=" + cmd.cmdStr);
               } else {
                  fileFormat = null;
                  binaryEncoding = null;
                  key = "fileFormat".toLowerCase();
                  if (cmd.hashCmdArgs.containsKey(key)) {
                     fileFormat = this.getFileFormat((String)cmd.hashCmdArgs.get(key));
                  }

                  key = "binaryEncoding".toLowerCase();
                  if (cmd.hashCmdArgs.containsKey(key)) {
                     binaryEncoding = this.getBinaryEncoding((String)cmd.hashCmdArgs.get(key));
                  }

                  if (!"signBinary".equalsIgnoreCase(cmd.cmdStr) && !"signBinaryStreaming".equalsIgnoreCase(cmd.cmdStr) && !"signXml".equalsIgnoreCase(cmd.cmdStr) && !"signXmlStreaming".equalsIgnoreCase(cmd.cmdStr) && !"signText".equalsIgnoreCase(cmd.cmdStr) && !"signTextStreaming".equalsIgnoreCase(cmd.cmdStr) && !"wrapBinaryInXmlAndSign".equalsIgnoreCase(cmd.cmdStr) && !"wrapBinaryInXmlAndSignStreaming".equalsIgnoreCase(cmd.cmdStr) && !"wrapTextInXmlAndSign".equalsIgnoreCase(cmd.cmdStr) && !"wrapTextInXmlAndSignStreaming".equalsIgnoreCase(cmd.cmdStr)) {
                     if ("validateSignature".equalsIgnoreCase(cmd.cmdStr)) {
                        X509Certificate sigVerifyCert = null;
                        key = "sigPublicCert".toLowerCase();
                        if (cmd.hashCmdArgs.containsKey(key)) {
                           val = (String)cmd.hashCmdArgs.get(key);
                           if (!"senderPublicCert".equalsIgnoreCase(val) && !"senderPubCert".equalsIgnoreCase(val)) {
                              if (!"receiverPublicCert".equalsIgnoreCase(val) && !"receiverPubCert".equalsIgnoreCase(val)) {
                                 if (!"approverPublicCert".equalsIgnoreCase(val) && !"approverPubCert".equalsIgnoreCase(val)) {
                                    try {
                                       sigVerifyCert = (X509Certificate)UtilShared.getCert(val);
                                    } catch (Exception var51) {
                                    }
                                 } else {
                                    sigVerifyCert = this.approverPublicCert;
                                 }
                              } else {
                                 sigVerifyCert = this.receiverPublicCert;
                              }
                           } else {
                              sigVerifyCert = this.senderPublicCert;
                           }
                        }

                        boolean flag = UtilShared.verifySignatureDOM(input, sigVerifyCert == null ? null : sigVerifyCert.getPublicKey());
                        this.logger.info("signature validation=" + flag);
                     } else if (!"createPkg".equalsIgnoreCase(cmd.cmdStr) && !"createPkgWithApprover".equalsIgnoreCase(cmd.cmdStr) && !"signAndCreatePkg".equalsIgnoreCase(cmd.cmdStr) && !"signAndCreatePkgWithApprover".equalsIgnoreCase(cmd.cmdStr) && !"signAndCreatePkgStreaming".equalsIgnoreCase(cmd.cmdStr) && !"signAndCreatePkgWithApproverStreaming".equalsIgnoreCase(cmd.cmdStr) && !"signBinaryAndCreatePkg".equalsIgnoreCase(cmd.cmdStr) && !"signTextAndCreatePkg".equalsIgnoreCase(cmd.cmdStr) && !"signBinaryAndCreatePkgStreaming".equalsIgnoreCase(cmd.cmdStr) && !"signTextAndCreatePkgStreaming".equalsIgnoreCase(cmd.cmdStr)) {
                        if (!"unpack".equalsIgnoreCase(cmd.cmdStr) && !"unpackForApprover".equalsIgnoreCase(cmd.cmdStr)) {
                           if ("createBinaryFromSignedBase64Binary".equalsIgnoreCase(cmd.cmdStr)) {
                              if (output == null) {
                                 output = input + ".bin";
                              }

                              UtilShared.createBinaryFileFromSignedBase64BinaryFile(input, output);
                           } else {
                              ArrayList list;
                              int idx;
                              if ("createZipPkg".equalsIgnoreCase(cmd.cmdStr)) {
                                 list = null;
                                 st = new StringTokenizer(input, "|");
                                 String[] files = new String[st.countTokens()];

                                 for(idx = 0; idx < files.length; ++idx) {
                                    files[idx] = st.nextToken();
                                 }

                                 if (output == null) {
                                    output = this.senderGiin + "_Payload.zip";
                                 }

                                 if (files != null && files.length > 0) {
                                    this.pkgr.createZipFile(files, output);
                                 } else if (this.senderGiin != null) {
                                    this.pkgr.createZipPkg(input, this.senderGiin, output);
                                 }
                              } else if ("encryptZipPkg".equalsIgnoreCase(cmd.cmdStr) && this.senderGiin != null && this.receiverGiin != null && this.receiverPublicCert != null && taxyear != -1) {
                                 output = this.pkgr.encryptZipPkg(input, this.senderGiin, this.receiverGiin, this.receiverPublicCert, (String)null, (X509Certificate)null, taxyear, fileFormat, binaryEncoding, this.metaDataEmail);
                              } else if ("encryptZipPkgWithApprover".equalsIgnoreCase(cmd.cmdStr) && this.senderGiin != null && this.receiverGiin != null && this.receiverPublicCert != null && this.approverGiin != null && this.approverPublicCert != null && taxyear != -1) {
                                 output = this.pkgr.encryptZipPkg(input, this.senderGiin, this.receiverGiin, this.receiverPublicCert, this.approverGiin, this.approverPublicCert, taxyear, fileFormat, binaryEncoding, this.metaDataEmail);
                              } else if (("unencryptZipPkg".equalsIgnoreCase(cmd.cmdStr) || "decryptZipPkg".equalsIgnoreCase(cmd.cmdStr)) && this.receiverPrivateKey != null) {
                                 list = this.pkgr.unencryptZipPkg(input, this.receiverPrivateKey, false);

                                 for(idx = 0; idx < list.size(); ++idx) {
                                    if (((String)list.get(idx)).toLowerCase().contains("payload")) {
                                       output = (String)list.get(idx);
                                       break;
                                    }
                                 }
                              } else if (("unencryptZipPkgForApprover".equalsIgnoreCase(cmd.cmdStr) || "decryptZipPkgForApprover".equalsIgnoreCase(cmd.cmdStr)) && this.approverPrivateKey != null) {
                                 list = this.pkgr.unencryptZipPkg(input, this.approverPrivateKey, true);

                                 for(idx = 0; idx < list.size(); ++idx) {
                                    if (((String)list.get(idx)).toLowerCase().contains("payload")) {
                                       output = (String)list.get(idx);
                                       break;
                                    }
                                 }
                              } else if ("extractZipPkg".equalsIgnoreCase(cmd.cmdStr)) {
                                 this.pkgr.unzipFile(input);
                              } else {
                                 this.logger.error("ERROR: unable to execute " + cmd.cmdStr + "....there may be missing info to execute cmd");
                              }
                           }
                        } else {
                           PrivateKey unpackPrivateKey = null;
                           key = "unpackPrivateKey".toLowerCase();
                           if (cmd.hashCmdArgs.containsKey(key)) {
                              val = (String)cmd.hashCmdArgs.get(key);
                              if ("receiverPrivateKey".equalsIgnoreCase(val)) {
                                 unpackPrivateKey = this.receiverPrivateKey;
                              } else if ("approverPrivateKey".equalsIgnoreCase(val)) {
                                 unpackPrivateKey = this.approverPrivateKey;
                              } else if ("senderPrivateKey".equalsIgnoreCase(val)) {
                                 unpackPrivateKey = this.senderPrivateKey;
                              }
                           }

                           if ("unpack".equalsIgnoreCase(cmd.cmdStr)) {
                              this.pkgr.unpack(input, unpackPrivateKey == null ? this.receiverPrivateKey : unpackPrivateKey);
                           } else if ("unpackForApprover".equalsIgnoreCase(cmd.cmdStr)) {
                              this.pkgr.unpackForApprover(input, unpackPrivateKey == null ? this.approverPrivateKey : unpackPrivateKey);
                           }
                        }
                     } else if ("createPkg".equalsIgnoreCase(cmd.cmdStr) && this.senderGiin != null && this.receiverGiin != null && this.receiverPublicCert != null && taxyear != -1) {
                        output = this.pkgr.createPkg(input, this.senderGiin, this.receiverGiin, this.receiverPublicCert, taxyear, this.metaDataEmail);
                     } else if ("createPkgWithApprover".equalsIgnoreCase(cmd.cmdStr) && this.senderGiin != null && this.receiverGiin != null && this.approverGiin != null && this.receiverPublicCert != null && this.approverPublicCert != null && taxyear != -1) {
                        output = this.pkgr.createPkgWithApprover(input, this.senderGiin, this.receiverGiin, this.receiverPublicCert, this.approverGiin, this.approverPublicCert, taxyear, this.metaDataEmail);
                     } else if ("signAndCreatePkg".equalsIgnoreCase(cmd.cmdStr) && this.senderPrivateKey != null && this.senderPublicCert != null && this.senderGiin != null && this.receiverGiin != null && this.receiverPublicCert != null && taxyear != -1) {
                        output = this.pkgr.signAndCreatePkg(input, this.senderPrivateKey, this.senderPublicCert, this.senderGiin, this.receiverGiin, this.receiverPublicCert, taxyear, this.metaDataEmail);
                     } else if ("signAndCreatePkgWithApprover".equalsIgnoreCase(cmd.cmdStr) && this.senderPrivateKey != null && this.senderPublicCert != null && this.senderGiin != null && this.receiverGiin != null && this.receiverPublicCert != null && this.approverGiin != null && this.approverPublicCert != null && taxyear != -1) {
                        output = this.pkgr.signAndCreatePkgWithApprover(input, this.senderPrivateKey, this.senderPublicCert, this.senderGiin, this.receiverGiin, this.receiverPublicCert, this.approverGiin, this.approverPublicCert, taxyear, this.metaDataEmail);
                     } else if ("signAndCreatePkgStreaming".equalsIgnoreCase(cmd.cmdStr) && this.senderPrivateKey != null && this.senderPublicCert != null && this.senderGiin != null && this.receiverGiin != null && this.receiverPublicCert != null && taxyear != -1) {
                        output = this.pkgr.signAndCreatePkgStreaming(input, this.senderPrivateKey, this.senderPublicCert, this.senderGiin, this.receiverGiin, this.receiverPublicCert, taxyear, this.metaDataEmail);
                     } else if ("signAndCreatePkgWithApproverStreaming".equalsIgnoreCase(cmd.cmdStr) && this.senderPrivateKey != null && this.senderPublicCert != null && this.senderGiin != null && this.receiverGiin != null && this.receiverPublicCert != null && this.approverGiin != null && this.approverPublicCert != null && taxyear != -1) {
                        output = this.pkgr.signAndCreatePkgWithApproverStreaming(input, this.senderPrivateKey, this.senderPublicCert, this.senderGiin, this.receiverGiin, this.receiverPublicCert, this.approverGiin, this.approverPublicCert, taxyear, this.metaDataEmail);
                     } else if ("signBinaryAndCreatePkg".equalsIgnoreCase(cmd.cmdStr) && this.senderPrivateKey != null && this.senderPublicCert != null && this.senderGiin != null && this.receiverGiin != null && this.receiverPublicCert != null && this.approverGiin != null && this.approverPublicCert != null && taxyear != -1) {
                        output = this.pkgr.signBinaryFileAndCreatePkg(input, this.senderPrivateKey, this.senderPublicCert, this.senderGiin, this.receiverGiin, this.receiverPublicCert, taxyear, fileFormat, this.metaDataEmail);
                     } else if ("signTextAndCreatePkg".equalsIgnoreCase(cmd.cmdStr) && this.senderPrivateKey != null && this.senderPublicCert != null && this.senderGiin != null && this.receiverGiin != null && this.receiverPublicCert != null && this.approverGiin != null && this.approverPublicCert != null && taxyear != -1) {
                        output = this.pkgr.signTextFileAndCreatePkg(input, this.senderPrivateKey, this.senderPublicCert, this.senderGiin, this.receiverGiin, this.receiverPublicCert, taxyear, this.metaDataEmail);
                     } else if ("signBinaryAndCreatePkgStreaming".equalsIgnoreCase(cmd.cmdStr) && this.senderPrivateKey != null && this.senderPublicCert != null && this.senderGiin != null && this.receiverGiin != null && this.receiverPublicCert != null && this.approverGiin != null && this.approverPublicCert != null && taxyear != -1) {
                        output = this.pkgr.signBinaryFileAndCreatePkgStreaming(input, this.senderPrivateKey, this.senderPublicCert, this.senderGiin, this.receiverGiin, this.receiverPublicCert, taxyear, fileFormat, this.metaDataEmail);
                     } else if ("signTextAndCreatePkgStreaming".equalsIgnoreCase(cmd.cmdStr) && this.senderPrivateKey != null && this.senderPublicCert != null && this.senderGiin != null && this.receiverGiin != null && this.receiverPublicCert != null && this.approverGiin != null && this.approverPublicCert != null && taxyear != -1) {
                        output = this.pkgr.signTextFileAndCreatePkgStreaming(input, this.senderPrivateKey, this.senderPublicCert, this.senderGiin, this.receiverGiin, this.receiverPublicCert, taxyear, this.metaDataEmail);
                     } else {
                        this.logger.error("ERROR: unable to execute " + cmd.cmdStr + "....there may be missing info to execute cmd");
                     }
                  } else {
                     if (output == null) {
                        output = input + ".signed.xml";
                     }

                     X509Certificate sigPublicCert = this.senderPublicCert;
                     PrivateKey sigPrivateKey = this.senderPrivateKey;
                     key = "sigPublicCert".toLowerCase();
                     if (cmd.hashCmdArgs.containsKey(key)) {
                        val = (String)cmd.hashCmdArgs.get(key);
                        if (!"senderPublicCert".equalsIgnoreCase(val) && !"senderPubCert".equalsIgnoreCase(val)) {
                           if (!"receiverPublicCert".equalsIgnoreCase(val) && !"receiverPubCert".equalsIgnoreCase(val)) {
                              if ("approverPublicCert".equalsIgnoreCase(val) || "approverPubCert".equalsIgnoreCase(val)) {
                                 sigPublicCert = this.approverPublicCert;
                              }
                           } else {
                              sigPublicCert = this.receiverPublicCert;
                           }
                        } else {
                           sigPublicCert = this.senderPublicCert;
                        }
                     }

                     key = "sigKey".toLowerCase();
                     if (cmd.hashCmdArgs.containsKey(key)) {
                        val = (String)cmd.hashCmdArgs.get(key);
                        if ("senderPrivateKey".equalsIgnoreCase(val)) {
                           sigPrivateKey = this.senderPrivateKey;
                        } else if ("receiverPrivateKey".equalsIgnoreCase(val)) {
                           sigPrivateKey = this.receiverPrivateKey;
                        } else if ("approverPrivateKey".equalsIgnoreCase(val)) {
                           sigPrivateKey = this.approverPrivateKey;
                        }
                     }

                     if ("signText".equalsIgnoreCase(cmd.cmdStr)) {
                        this.signer.signTextFile(input, output, sigPrivateKey, sigPublicCert);
                     } else if ("signTextStreaming".equalsIgnoreCase(cmd.cmdStr)) {
                        this.signer.signTextFileStreaming(input, output, sigPrivateKey, sigPublicCert);
                     } else if ("signBinary".equalsIgnoreCase(cmd.cmdStr)) {
                        this.signer.signBinaryFile(input, output, sigPrivateKey, sigPublicCert);
                     } else if ("signBinaryStreaming".equalsIgnoreCase(cmd.cmdStr)) {
                        this.signer.signBinaryFileStreaming(input, output, this.senderPrivateKey, this.senderPublicCert);
                     } else if ("signXml".equalsIgnoreCase(cmd.cmdStr)) {
                        this.signer.signXmlFile(input, output, this.senderPrivateKey, this.senderPublicCert);
                     } else if ("signXmlStreaming".equalsIgnoreCase(cmd.cmdStr)) {
                        this.signer.signXmlFileStreaming(input, output, this.senderPrivateKey, this.senderPublicCert);
                     } else if ("wrapBinaryInXmlAndSign".equalsIgnoreCase(cmd.cmdStr)) {
                        this.signer.wrapBinaryFileInXmlAndSign(input, output, this.senderPrivateKey, this.senderPublicCert);
                     } else if ("wrapBinaryInXmlAndSignStreaming".equalsIgnoreCase(cmd.cmdStr)) {
                        this.signer.wrapBinaryFileInXmlAndSignStreaming(input, output, this.senderPrivateKey, this.senderPublicCert);
                     } else if ("wrapTextInXmlAndSign".equalsIgnoreCase(cmd.cmdStr)) {
                        this.signer.wrapTextFileInXmlAndSign(input, output, this.senderPrivateKey, this.senderPublicCert);
                     } else if ("wrapTextInXmlAndSignStreaming".equalsIgnoreCase(cmd.cmdStr)) {
                        this.signer.wrapTextFileInXmlAndSignStreaming(input, output, this.senderPrivateKey, this.senderPublicCert);
                     } else {
                        this.logger.error("ERROR: unable to execute " + cmd.cmdStr + "....there may be missing info to execute cmd");
                     }
                  }

                  this.logger.info("finished..." + cmd.cmdStr + " input=" + input + (output == null ? "" : ", output=" + output));
               }
            }
         }

         if (this.pkgr.getSigner().isValidateAllSignature()) {
            this.logger.info("all signature validation=" + this.pkgr.getSigner().isValidationSuccess());
         }

      } catch (Exception var61) {
         var61.printStackTrace();
         throw var61;
      }
   }

   protected IPackager.MetadataFileFormat getFileFormat(String ff) {
      if ("PDF".equalsIgnoreCase(ff)) {
         return IPackager.MetadataFileFormat.PDF;
      } else if ("JPG".equalsIgnoreCase(ff)) {
         return IPackager.MetadataFileFormat.JPG;
      } else if ("TXT".equalsIgnoreCase(ff)) {
         return IPackager.MetadataFileFormat.TXT;
      } else if ("RTF".equalsIgnoreCase(ff)) {
         return IPackager.MetadataFileFormat.RTF;
      } else {
         return "XML".equalsIgnoreCase(ff) ? IPackager.MetadataFileFormat.XML : null;
      }
   }

   protected IPackager.MetadataBinaryEncoding getBinaryEncoding(String be) {
      if ("NONE".equalsIgnoreCase(be)) {
         return IPackager.MetadataBinaryEncoding.NONE;
      } else {
         return !"BASE64".equalsIgnoreCase(be) && !"BASE_64".equalsIgnoreCase(be) ? null : IPackager.MetadataBinaryEncoding.BASE_64;
      }
   }

   public static void main(String[] args) throws Exception {
      FATCADataPrepPETestTool m = new FATCADataPrepPETestTool();
      if (args.length > 0) {
         m.readConfigAndExceuteCommands(args[0]);
      } else {
         m.readConfigAndExceuteCommands();
      }

   }

   protected class Cmd {
      public String cmdStr;
      public HashMap<String, String> hashCmdArgs = new HashMap();
   }
}
