package fatca.idessenderfilemetadata1_1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;

@XmlRegistry
public class ObjectFactory {
   private static final QName _SenderFileId_QNAME = new QName("urn:fatca:idessenderfilemetadata", "SenderFileId");
   private static final QName _BinaryEncodingSchemeCd_QNAME = new QName("urn:fatca:idessenderfilemetadata", "BinaryEncodingSchemeCd");
   private static final QName _FATCAEntCommunicationTypeCd_QNAME = new QName("urn:fatca:idessenderfilemetadata", "FATCAEntCommunicationTypeCd");
   private static final QName _TaxYear_QNAME = new QName("urn:fatca:idessenderfilemetadata", "TaxYear");
   private static final QName _FileRevisionInd_QNAME = new QName("urn:fatca:idessenderfilemetadata", "FileRevisionInd");
   private static final QName _FATCAIDESSenderFileMetadata_QNAME = new QName("urn:fatca:idessenderfilemetadata", "FATCAIDESSenderFileMetadata");
   private static final QName _SenderContactEmailAddressTxt_QNAME = new QName("urn:fatca:idessenderfilemetadata", "SenderContactEmailAddressTxt");
   private static final QName _FATCAEntitySenderId_QNAME = new QName("urn:fatca:idessenderfilemetadata", "FATCAEntitySenderId");
   private static final QName _FATCAEntityReceiverId_QNAME = new QName("urn:fatca:idessenderfilemetadata", "FATCAEntityReceiverId");
   private static final QName _OriginalIDESTransmissionId_QNAME = new QName("urn:fatca:idessenderfilemetadata", "OriginalIDESTransmissionId");
   private static final QName _FileCreateTs_QNAME = new QName("urn:fatca:idessenderfilemetadata", "FileCreateTs");
   private static final QName _FileFormatCd_QNAME = new QName("urn:fatca:idessenderfilemetadata", "FileFormatCd");

   public FATCAIDESSenderFileMetadataType createFATCAIDESSenderFileMetadataType() {
      return new FATCAIDESSenderFileMetadataType();
   }

   @XmlElementDecl(
      namespace = "urn:fatca:idessenderfilemetadata",
      name = "SenderFileId"
   )
   public JAXBElement<String> createSenderFileId(String value) {
      return new JAXBElement(_SenderFileId_QNAME, String.class, (Class)null, value);
   }

   @XmlElementDecl(
      namespace = "urn:fatca:idessenderfilemetadata",
      name = "BinaryEncodingSchemeCd"
   )
   public JAXBElement<BinaryEncodingSchemeCdType> createBinaryEncodingSchemeCd(BinaryEncodingSchemeCdType value) {
      return new JAXBElement(_BinaryEncodingSchemeCd_QNAME, BinaryEncodingSchemeCdType.class, (Class)null, value);
   }

   @XmlElementDecl(
      namespace = "urn:fatca:idessenderfilemetadata",
      name = "FATCAEntCommunicationTypeCd"
   )
   public JAXBElement<FATCAEntCommunicationTypeCdType> createFATCAEntCommunicationTypeCd(FATCAEntCommunicationTypeCdType value) {
      return new JAXBElement(_FATCAEntCommunicationTypeCd_QNAME, FATCAEntCommunicationTypeCdType.class, (Class)null, value);
   }

   @XmlElementDecl(
      namespace = "urn:fatca:idessenderfilemetadata",
      name = "TaxYear"
   )
   public JAXBElement<XMLGregorianCalendar> createTaxYear(XMLGregorianCalendar value) {
      return new JAXBElement(_TaxYear_QNAME, XMLGregorianCalendar.class, (Class)null, value);
   }

   @XmlElementDecl(
      namespace = "urn:fatca:idessenderfilemetadata",
      name = "FileRevisionInd"
   )
   public JAXBElement<Boolean> createFileRevisionInd(Boolean value) {
      return new JAXBElement(_FileRevisionInd_QNAME, Boolean.class, (Class)null, value);
   }

   @XmlElementDecl(
      namespace = "urn:fatca:idessenderfilemetadata",
      name = "FATCAIDESSenderFileMetadata"
   )
   public JAXBElement<FATCAIDESSenderFileMetadataType> createFATCAIDESSenderFileMetadata(FATCAIDESSenderFileMetadataType value) {
      return new JAXBElement(_FATCAIDESSenderFileMetadata_QNAME, FATCAIDESSenderFileMetadataType.class, (Class)null, value);
   }

   @XmlElementDecl(
      namespace = "urn:fatca:idessenderfilemetadata",
      name = "SenderContactEmailAddressTxt"
   )
   public JAXBElement<String> createSenderContactEmailAddressTxt(String value) {
      return new JAXBElement(_SenderContactEmailAddressTxt_QNAME, String.class, (Class)null, value);
   }

   @XmlElementDecl(
      namespace = "urn:fatca:idessenderfilemetadata",
      name = "FATCAEntitySenderId"
   )
   public JAXBElement<String> createFATCAEntitySenderId(String value) {
      return new JAXBElement(_FATCAEntitySenderId_QNAME, String.class, (Class)null, value);
   }

   @XmlElementDecl(
      namespace = "urn:fatca:idessenderfilemetadata",
      name = "FATCAEntityReceiverId"
   )
   public JAXBElement<String> createFATCAEntityReceiverId(String value) {
      return new JAXBElement(_FATCAEntityReceiverId_QNAME, String.class, (Class)null, value);
   }

   @XmlElementDecl(
      namespace = "urn:fatca:idessenderfilemetadata",
      name = "OriginalIDESTransmissionId"
   )
   public JAXBElement<String> createOriginalIDESTransmissionId(String value) {
      return new JAXBElement(_OriginalIDESTransmissionId_QNAME, String.class, (Class)null, value);
   }

   @XmlElementDecl(
      namespace = "urn:fatca:idessenderfilemetadata",
      name = "FileCreateTs"
   )
   public JAXBElement<String> createFileCreateTs(String value) {
      return new JAXBElement(_FileCreateTs_QNAME, String.class, (Class)null, value);
   }

   @XmlElementDecl(
      namespace = "urn:fatca:idessenderfilemetadata",
      name = "FileFormatCd"
   )
   public JAXBElement<FileFormatCdType> createFileFormatCd(FileFormatCdType value) {
      return new JAXBElement(_FileFormatCd_QNAME, FileFormatCdType.class, (Class)null, value);
   }
}
