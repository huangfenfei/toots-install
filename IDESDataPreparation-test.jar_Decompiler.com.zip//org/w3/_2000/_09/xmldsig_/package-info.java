package org.w3._2000._09.xmldsig_;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;

// $FF: synthetic class
@XmlSchema(
   namespace = "http://www.w3.org/2000/09/xmldsig#",
   elementFormDefault = XmlNsForm.QUALIFIED
)
interface package-info {
}
