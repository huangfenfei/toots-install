package fatca.idessenderfilemetadata1_1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;

@XmlType(
   name = "FATCAEntCommunicationTypeCdType"
)
@XmlEnum
public enum FATCAEntCommunicationTypeCdType {
   NTF,
   RPT,
   CAR,
   REG;

   public String value() {
      return this.name();
   }

   public static FATCAEntCommunicationTypeCdType fromValue(String v) {
      return valueOf(v);
   }
}
