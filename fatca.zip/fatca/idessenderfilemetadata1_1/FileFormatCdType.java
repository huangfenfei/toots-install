package fatca.idessenderfilemetadata1_1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;

@XmlType(
   name = "FileFormatCdType"
)
@XmlEnum
public enum FileFormatCdType {
   XML,
   TXT,
   PDF,
   RTF,
   JPG;

   public String value() {
      return this.name();
   }

   public static FileFormatCdType fromValue(String v) {
      return valueOf(v);
   }
}
