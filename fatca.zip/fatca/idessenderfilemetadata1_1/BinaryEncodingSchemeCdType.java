package fatca.idessenderfilemetadata1_1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

@XmlType(
   name = "BinaryEncodingSchemeCdType"
)
@XmlEnum
public enum BinaryEncodingSchemeCdType {
   NONE("NONE"),
   @XmlEnumValue("BASE64")
   BASE_64("BASE64");

   private final String value;

   private BinaryEncodingSchemeCdType(String v) {
      this.value = v;
   }

   public String value() {
      return this.value;
   }

   public static BinaryEncodingSchemeCdType fromValue(String v) {
      BinaryEncodingSchemeCdType[] var4;
      int var3 = (var4 = values()).length;

      for(int var2 = 0; var2 < var3; ++var2) {
         BinaryEncodingSchemeCdType c = var4[var2];
         if (c.value.equals(v)) {
            return c;
         }
      }

      throw new IllegalArgumentException(v);
   }
}
