package fatca.idessenderfilemetadata1_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
   name = "FATCAIDESSenderFileMetadataType",
   propOrder = {"fatcaEntitySenderId", "fatcaEntityReceiverId", "fatcaEntCommunicationTypeCd", "senderFileId", "fileFormatCd", "binaryEncodingSchemeCd", "fileCreateTs", "taxYear", "fileRevisionInd", "originalIDESTransmissionId", "senderContactEmailAddressTxt"}
)
public class FATCAIDESSenderFileMetadataType {
   @XmlElement(
      name = "FATCAEntitySenderId",
      required = true
   )
   protected String fatcaEntitySenderId;
   @XmlElement(
      name = "FATCAEntityReceiverId",
      required = true
   )
   protected String fatcaEntityReceiverId;
   @XmlElement(
      name = "FATCAEntCommunicationTypeCd",
      required = true
   )
   protected FATCAEntCommunicationTypeCdType fatcaEntCommunicationTypeCd;
   @XmlElement(
      name = "SenderFileId",
      required = true
   )
   protected String senderFileId;
   @XmlElement(
      name = "FileFormatCd"
   )
   protected FileFormatCdType fileFormatCd;
   @XmlElement(
      name = "BinaryEncodingSchemeCd"
   )
   protected BinaryEncodingSchemeCdType binaryEncodingSchemeCd;
   @XmlElement(
      name = "FileCreateTs",
      required = true
   )
   protected String fileCreateTs;
   @XmlElement(
      name = "TaxYear",
      required = true
   )
   protected XMLGregorianCalendar taxYear;
   @XmlElement(
      name = "FileRevisionInd"
   )
   protected boolean fileRevisionInd;
   @XmlElement(
      name = "OriginalIDESTransmissionId"
   )
   protected String originalIDESTransmissionId;
   @XmlElement(
      name = "SenderContactEmailAddressTxt"
   )
   protected String senderContactEmailAddressTxt;

   public String getFATCAEntitySenderId() {
      return this.fatcaEntitySenderId;
   }

   public void setFATCAEntitySenderId(String value) {
      this.fatcaEntitySenderId = value;
   }

   public String getFATCAEntityReceiverId() {
      return this.fatcaEntityReceiverId;
   }

   public void setFATCAEntityReceiverId(String value) {
      this.fatcaEntityReceiverId = value;
   }

   public FATCAEntCommunicationTypeCdType getFATCAEntCommunicationTypeCd() {
      return this.fatcaEntCommunicationTypeCd;
   }

   public void setFATCAEntCommunicationTypeCd(FATCAEntCommunicationTypeCdType value) {
      this.fatcaEntCommunicationTypeCd = value;
   }

   public String getSenderFileId() {
      return this.senderFileId;
   }

   public void setSenderFileId(String value) {
      this.senderFileId = value;
   }

   public FileFormatCdType getFileFormatCd() {
      return this.fileFormatCd;
   }

   public void setFileFormatCd(FileFormatCdType value) {
      this.fileFormatCd = value;
   }

   public BinaryEncodingSchemeCdType getBinaryEncodingSchemeCd() {
      return this.binaryEncodingSchemeCd;
   }

   public void setBinaryEncodingSchemeCd(BinaryEncodingSchemeCdType value) {
      this.binaryEncodingSchemeCd = value;
   }

   public String getFileCreateTs() {
      return this.fileCreateTs;
   }

   public void setFileCreateTs(String value) {
      this.fileCreateTs = value;
   }

   public XMLGregorianCalendar getTaxYear() {
      return this.taxYear;
   }

   public void setTaxYear(XMLGregorianCalendar value) {
      this.taxYear = value;
   }

   public boolean isFileRevisionInd() {
      return this.fileRevisionInd;
   }

   public void setFileRevisionInd(boolean value) {
      this.fileRevisionInd = value;
   }

   public String getOriginalIDESTransmissionId() {
      return this.originalIDESTransmissionId;
   }

   public void setOriginalIDESTransmissionId(String value) {
      this.originalIDESTransmissionId = value;
   }

   public String getSenderContactEmailAddressTxt() {
      return this.senderContactEmailAddressTxt;
   }

   public void setSenderContactEmailAddressTxt(String value) {
      this.senderContactEmailAddressTxt = value;
   }
}
