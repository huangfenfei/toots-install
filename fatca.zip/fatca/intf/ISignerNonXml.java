package fatca.intf;

import java.security.PrivateKey;
import java.security.cert.X509Certificate;

public interface ISignerNonXml {
   boolean wrapTextFileInXmlAndSign(String var1, String var2, PrivateKey var3, X509Certificate var4) throws Exception;

   boolean wrapTextFileInXmlAndSignStreaming(String var1, String var2, PrivateKey var3, X509Certificate var4) throws Exception;

   boolean wrapBinaryFileInXmlAndSign(String var1, String var2, PrivateKey var3, X509Certificate var4) throws Exception;

   boolean wrapBinaryFileInXmlAndSignStreaming(String var1, String var2, PrivateKey var3, X509Certificate var4) throws Exception;

   String getWrapperXsiSchemaLoc();

   void setWrapperXsiSchemaLoc(boolean var1);

   boolean isWrapperXsiSchemaLoc();

   void setWrapperXsiSchemaLoc(String var1);

   boolean isWrapperXsi();

   void setWrapperXsi(boolean var1);

   String getWrapperPrefix();

   void setWrapperPrefix(String var1);

   String getWrapperNS();

   void setWrapperNS(String var1);

   boolean signTextFile(String var1, String var2, PrivateKey var3, X509Certificate var4) throws Exception;

   boolean signBinaryFile(String var1, String var2, PrivateKey var3, X509Certificate var4) throws Exception;

   boolean signTextFileStreaming(String var1, String var2, PrivateKey var3, X509Certificate var4) throws Exception;

   boolean signBinaryFileStreaming(String var1, String var2, PrivateKey var3, X509Certificate var4) throws Exception;
}
