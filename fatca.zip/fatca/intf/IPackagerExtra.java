package fatca.intf;

import fatca.idessenderfilemetadata1_1.BinaryEncodingSchemeCdType;
import fatca.idessenderfilemetadata1_1.FileFormatCdType;
import java.security.PrivateKey;
import java.util.ArrayList;
import java.util.Date;

public interface IPackagerExtra {
   void createZipPkg(String var1, String var2, String var3) throws Exception;

   boolean createZipFile(String[] var1, String var2) throws Exception;

   ArrayList<String> unzipFile(String var1) throws Exception;

   ArrayList<String> unzipFile(String var1, String var2) throws Exception;

   ArrayList<String> unencryptZipPkg(String var1, PrivateKey var2, boolean var3) throws Exception;

   boolean isDualModeDecryption();

   void setDualModeDecryption(boolean var1);

   String createMetadata1_0(String var1, String var2, String var3, int var4, String var5, Date var6, String var7) throws Exception;

   String createMetadata1_1(String var1, String var2, String var3, int var4, String var5, Date var6, FileFormatCdType var7, BinaryEncodingSchemeCdType var8, String var9) throws Exception;

   boolean renameZipEntries(String var1, String[] var2, String[] var3) throws Exception;

   void setMetadataVer(float var1);

   void setKeepSignedXmlAfterSignAndCreatePkgFlag(boolean var1);

   boolean getKeepSignedXmlAfterSignAndCreatePkgFlag();
}
