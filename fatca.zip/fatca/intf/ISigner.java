package fatca.intf;

import java.security.PrivateKey;
import java.security.cert.X509Certificate;

public interface ISigner extends ISignerNonXml, ISignerExtra {
   boolean signXmlFile(String var1, String var2, PrivateKey var3, X509Certificate var4) throws Exception;

   boolean signXmlFileStreaming(String var1, String var2, PrivateKey var3, X509Certificate var4) throws Exception;

   String getSigRefIdPos();

   void setSigRefIdPos(String var1) throws Exception;

   String getSigXmlTransform();

   void setSigXmlTransform(String var1) throws Exception;
}
