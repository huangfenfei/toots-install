package fatca.idessenderfilemetadata;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;

// $FF: synthetic class
@XmlSchema(
   namespace = "urn:fatca:idessenderfilemetadata",
   elementFormDefault = XmlNsForm.QUALIFIED
)
interface package-info {
}
