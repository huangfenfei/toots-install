package fatca.idessenderfilemetadata;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;

@XmlType(
   name = "FATCAEntCommunicationTypeCdType"
)
@XmlEnum
public enum FATCAEntCommunicationTypeCdType {
   NTF,
   RPT;

   public String value() {
      return this.name();
   }

   public static FATCAEntCommunicationTypeCdType fromValue(String v) {
      return valueOf(v);
   }
}
