package fatca.impl;

import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;
import fatca.idessenderfilemetadata.FATCAEntCommunicationTypeCdType;
import fatca.idessenderfilemetadata.ObjectFactory;
import fatca.idessenderfilemetadata1_1.BinaryEncodingSchemeCdType;
import fatca.idessenderfilemetadata1_1.FATCAIDESSenderFileMetadataType;
import fatca.idessenderfilemetadata1_1.FileFormatCdType;
import fatca.intf.IPackager;
import fatca.intf.ISigner;
import fatca.util.UtilShared;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.security.Key;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.XMLGregorianCalendar;
import org.apache.log4j.Logger;

public class FATCAPackager implements IPackager {
   protected final String RSA_TRANSFORMATION = "RSA";
   protected final String SECRET_KEY_ALGO = "AES";
   protected final int SECRET_KEY_SIZE_IN_BITS = 256;
   protected String metaDataEmailAddress = "Fatca@scb.co.th";
   protected final String AesTransformationCBC = "AES/CBC/PKCS5Padding";
   protected final String AesTransformationECB = "AES/ECB/PKCS5Padding";
   protected Logger logger = Logger.getLogger((new Object() {
   }).getClass().getEnclosingClass().getName());
   protected ObjectFactory objFMetadata1_0 = new ObjectFactory();
   protected fatca.idessenderfilemetadata1_1.ObjectFactory objFMetadata1_1 = new fatca.idessenderfilemetadata1_1.ObjectFactory();
   protected SimpleDateFormat sdfFileName;
   protected SimpleDateFormat sdfFileCreateTs;
   protected JAXBContext jaxbCtxMetadata1_0;
   protected JAXBContext jaxbCtxMetadata1_1;
   protected boolean keepSignedXmlAfterSignAndCreatePkgFlag;
   protected int defaultBufSize;
   protected FATCAPackager.MyThreadSafeData myThreadSafeData;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$fatca$intf$IPackager$MetadataFileFormat;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$fatca$intf$IPackager$MetadataBinaryEncoding;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$fatca$intf$IPackager$AesCipherOpMode;

   public void setmetaDataEmailAddress(String mail) {
      this.metaDataEmailAddress = mail;
   }

   public FATCAPackager() {
      this.sdfFileName = new SimpleDateFormat("yyyyMMdd'T'HHmmssSSS'Z'", Locale.ENGLISH);
      this.sdfFileCreateTs = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.ENGLISH);
      this.keepSignedXmlAfterSignAndCreatePkgFlag = false;
      this.defaultBufSize = 8192;
      this.myThreadSafeData = new FATCAPackager.MyThreadSafeData();

      try {
         this.jaxbCtxMetadata1_0 = JAXBContext.newInstance("fatca.idessenderfilemetadata");
         this.jaxbCtxMetadata1_1 = JAXBContext.newInstance("fatca.idessenderfilemetadata1_1");
      } catch (Throwable var2) {
         var2.printStackTrace();
         throw new RuntimeException(var2);
      }
   }

   protected FileFormatCdType getFileFormat(IPackager.MetadataFileFormat ff) {
      if (ff == null) {
         return null;
      } else {
         switch($SWITCH_TABLE$fatca$intf$IPackager$MetadataFileFormat()[ff.ordinal()]) {
         case 1:
            return FileFormatCdType.XML;
         case 2:
            return FileFormatCdType.TXT;
         case 3:
            return FileFormatCdType.JPG;
         case 4:
            return FileFormatCdType.PDF;
         case 5:
            return FileFormatCdType.RTF;
         default:
            return null;
         }
      }
   }

   protected BinaryEncodingSchemeCdType getBinaryEncoding(IPackager.MetadataBinaryEncoding be) {
      if (be == null) {
         return null;
      } else {
         switch($SWITCH_TABLE$fatca$intf$IPackager$MetadataBinaryEncoding()[be.ordinal()]) {
         case 1:
            return BinaryEncodingSchemeCdType.NONE;
         case 2:
            return BinaryEncodingSchemeCdType.BASE_64;
         default:
            return null;
         }
      }
   }

   protected Cipher aes(int opmode, String inputFile, String outputFile, SecretKey secretKey) throws Exception {
      this.logger.debug("--> aes(). opmode=" + (opmode == 1 ? "ENCRYPT" : "DECRYPT") + ", inputFile=" + inputFile + ", outputFile=" + outputFile);
      if (opmode != 1 && opmode != 2) {
         throw new Exception("Invalid opmode " + opmode + ". Allowed opmodes are Cipher.ENCRYPT_MODE or Cipher.DECRYPT_MODE");
      } else {
         Cipher ret = null;
         BufferedInputStream bis = null;
         BufferedOutputStream bos = null;
         byte[] output = null;
         byte[] buf = new byte[this.myThreadSafeData.getBufSize()];
         IvParameterSpec iv = null;

         try {
            IPackager.AesCipherOpMode cipherOpMode = this.myThreadSafeData.getAesCipherOpMode();
            String transformation = this.myThreadSafeData.getAesTransformation();
            byte[] ivBuf = null;
            if (opmode == 2) {
               byte[] skeyBuf = null;
               byte[] skeyIvBuf = ((SecretKey)secretKey).getEncoded();
               int expectedSKeySizeInBytes = 32;
               if (skeyIvBuf.length > expectedSKeySizeInBytes) {
                  byte[] skeyBuf = new byte[expectedSKeySizeInBytes];
                  byte[] ivBuf = new byte[skeyIvBuf.length - skeyBuf.length];
                  System.arraycopy(skeyIvBuf, 0, skeyBuf, 0, skeyBuf.length);
                  System.arraycopy(skeyIvBuf, skeyBuf.length, ivBuf, 0, ivBuf.length);
                  if (ivBuf.length != 16) {
                     throw new Exception("incorrect IV size - " + ivBuf.length + " bytes");
                  }

                  if (skeyBuf.length != expectedSKeySizeInBytes) {
                     throw new Exception("incorrect KEY size - " + skeyBuf.length + " bytes");
                  }

                  secretKey = new SecretKeySpec(skeyBuf, "AES");
                  iv = new IvParameterSpec(ivBuf);
               }

               if (this.myThreadSafeData.isDualModeDecryption()) {
                  if (iv != null) {
                     transformation = "AES/CBC/PKCS5Padding";
                  } else {
                     transformation = "AES/ECB/PKCS5Padding";
                  }
               } else {
                  if (cipherOpMode == IPackager.AesCipherOpMode.CBC && iv == null) {
                     throw new Exception("invalid KEY size - missing IV");
                  }

                  if (cipherOpMode == IPackager.AesCipherOpMode.ECB && iv != null) {
                     throw new Exception("invalid KEY size - not expecting IV with KEY");
                  }
               }
            }

            Cipher cipher = Cipher.getInstance(transformation);
            cipher.init(opmode, (Key)secretKey, iv);
            bis = new BufferedInputStream(new FileInputStream(new File(inputFile)));
            bos = new BufferedOutputStream(new FileOutputStream(new File(outputFile)));

            int len;
            byte[] output;
            while((len = bis.read(buf)) != -1) {
               output = cipher.update(buf, 0, len);
               if (output.length > 0) {
                  bos.write(output);
               }
            }

            output = cipher.doFinal();
            if (output.length > 0) {
               bos.write(output);
            }

            bos.close();
            bos = null;
            bis.close();
            bis = null;
            ret = cipher;
         } finally {
            if (bis != null) {
               try {
                  bis.close();
               } catch (Exception var27) {
               }
            }

            if (bos != null) {
               try {
                  bos.close();
               } catch (Exception var26) {
               }
            }

         }

         this.logger.debug("<-- aes()");
         return ret;
      }
   }

   protected boolean encrypt(String zippedSignedPlainTextFile, String cipherTextOutFile, Certificate[] receiversPublicCert, String[] encryptedAESKeyOutFiles) throws Exception {
      this.logger.debug("--> encrypt(). zippedSignedPlainTextFile=" + zippedSignedPlainTextFile + ", cipherTextOutFile=" + cipherTextOutFile);
      PublicKey[] pubkeys = new PublicKey[receiversPublicCert.length];

      for(int i = 0; i < receiversPublicCert.length; ++i) {
         pubkeys[i] = receiversPublicCert[i].getPublicKey();
      }

      boolean flag = this.encrypt(zippedSignedPlainTextFile, cipherTextOutFile, pubkeys, encryptedAESKeyOutFiles);
      this.logger.debug("<-- encrypt()");
      return flag;
   }

   protected boolean encrypt(String zippedSignedPlainTextFile, String cipherTextOutFile, PublicKey[] receiversPublicKey, String[] encryptedAESKeyOutFiles) throws Exception {
      this.logger.debug("--> encrypt(). zippedSignedPlainTextFile=" + zippedSignedPlainTextFile + ", cipherTextOutFile" + cipherTextOutFile);
      boolean ret = false;
      SecretKey skey = null;
      BufferedOutputStream bos = null;
      Object var10 = null;

      try {
         KeyGenerator generator = KeyGenerator.getInstance("AES");
         generator.init(256);
         skey = generator.generateKey();
         byte[] skeyBuf = ((SecretKey)skey).getEncoded();
         Cipher aesCipher = this.aes(1, zippedSignedPlainTextFile, cipherTextOutFile, (SecretKey)skey);
         if (aesCipher != null) {
            byte[] ivBuf = aesCipher.getIV();

            for(int i = 0; i < receiversPublicKey.length && i < encryptedAESKeyOutFiles.length; ++i) {
               Cipher cipher = Cipher.getInstance("RSA");
               cipher.init(3, receiversPublicKey[i]);
               if (ivBuf != null) {
                  byte[] skeyPlusIvBuf = new byte[skeyBuf.length + ivBuf.length];
                  System.arraycopy(skeyBuf, 0, skeyPlusIvBuf, 0, skeyBuf.length);
                  System.arraycopy(ivBuf, 0, skeyPlusIvBuf, skeyBuf.length, ivBuf.length);
                  this.logger.debug("key buf size=" + skeyPlusIvBuf.length);
                  skey = new SecretKeySpec(skeyPlusIvBuf, "AES");
               }

               byte[] encryptedAESKeyBuf = cipher.wrap((Key)skey);
               bos = new BufferedOutputStream(new FileOutputStream(new File(encryptedAESKeyOutFiles[i])));
               bos.write(encryptedAESKeyBuf);
               bos.close();
               bos = null;
            }

            ret = true;
         }
      } finally {
         if (bos != null) {
            try {
               bos.close();
            } catch (Exception var21) {
            }
         }

      }

      this.logger.debug("<-- encrypt)");
      return ret;
   }

   public boolean createZipFile(String[] inFiles, String outFile) throws Exception {
      StringBuilder bis;
      if (this.logger.isDebugEnabled()) {
         bis = new StringBuilder("--> createZipFile()");
         bis.append(", inFiles=[");

         for(int i = 0; i < inFiles.length; ++i) {
            if (i > 0) {
               bis.append(",");
            }

            bis.append(inFiles[i]);
         }

         bis.append("], outFile=");
         bis.append(outFile);
         this.logger.debug(bis.toString());
      }

      bis = null;
      ZipOutputStream zos = null;
      boolean ret = false;
      byte[] buf = new byte[this.myThreadSafeData.getBufSize()];

      try {
         zos = new ZipOutputStream(new FileOutputStream(new File(outFile)));
         zos.setLevel(9);

         for(int i = 0; i < inFiles.length; ++i) {
            String infile = inFiles[i];
            int len = infile.lastIndexOf("/");
            if (len == -1) {
               len = infile.lastIndexOf("\\");
            }

            if (len != -1) {
               infile = infile.substring(len + 1);
            }

            ZipEntry zipEntry = new ZipEntry(infile);
            zos.putNextEntry(zipEntry);
            BufferedInputStream bis = new BufferedInputStream(new FileInputStream(new File(inFiles[i])));

            while((len = bis.read(buf)) != -1) {
               zos.write(buf, 0, len);
            }

            bis.close();
            bis = null;
            zos.closeEntry();
         }

         zos.close();
         zos = null;
         ret = true;
      } finally {
         if (bis != null) {
            try {
               bis.close();
            } catch (Exception var19) {
            }
         }

         if (zos != null) {
            try {
               zos.close();
            } catch (Exception var18) {
            }
         }

      }

      this.logger.debug("<-- createZipFile()");
      return ret;
   }

   protected boolean renameZipEntry(String zipFile, String entryName, String newEntryName) throws Exception {
      this.logger.debug("--> renameZipEntry(). zipFile=" + zipFile + ", entryName=" + entryName + ", newEntryName=" + newEntryName);
      boolean ret = false;
      ZipFile inzip = new ZipFile(zipFile);
      String tmpfile = UtilShared.getTmpFileName(zipFile, "tmp");
      ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(new File(tmpfile)));
      Enumeration<? extends ZipEntry> e = inzip.entries();
      byte[] buf = new byte[8192];

      while(e.hasMoreElements()) {
         ZipEntry entry = (ZipEntry)e.nextElement();
         InputStream is = inzip.getInputStream(entry);
         ZipEntry newentry;
         if (entryName.equalsIgnoreCase(entry.getName())) {
            newentry = new ZipEntry(newEntryName);
         } else {
            newentry = new ZipEntry(entry.getName());
         }

         zos.putNextEntry(newentry);

         int len;
         while((len = is.read(buf)) != -1) {
            zos.write(buf, 0, len);
         }

         is.close();
         zos.closeEntry();
      }

      zos.close();
      inzip.close();
      File dest = new File(zipFile);
      File src = new File(tmpfile);
      UtilShared.deleteDestAndRenameFile(src, dest);
      ret = true;
      this.logger.debug("<-- renameZipEntry()");
      return ret;
   }

   public boolean renameZipEntries(String zipFile, String[] entryNames, String[] newEntryNames) throws Exception {
      if (this.logger.isDebugEnabled()) {
         StringBuilder sb = new StringBuilder("--> renameZipEntries()");
         sb.append(", zipFile=");
         sb.append(zipFile);
         sb.append(", entryNames=[");

         int i;
         for(i = 0; i < entryNames.length; ++i) {
            if (i > 0) {
               sb.append(",");
            }

            sb.append(entryNames[i]);
         }

         sb.append("], newEntryNames=[");

         for(i = 0; i < newEntryNames.length; ++i) {
            if (i > 0) {
               sb.append(",");
            }

            sb.append(newEntryNames[i]);
         }

         sb.append("]");
         this.logger.debug(sb.toString());
      }

      boolean ret = false;
      if (entryNames.length != newEntryNames.length) {
         throw new Exception("renameZipEntries entryNames and newEntryNames length should be same");
      } else {
         ZipFile inzip = new ZipFile(zipFile);
         String tmpfile = UtilShared.getTmpFileName(zipFile, "tmp");
         ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(new File(tmpfile)));
         Enumeration<? extends ZipEntry> e = inzip.entries();
         byte[] buf = new byte[8192];

         while(e.hasMoreElements()) {
            ZipEntry entry = (ZipEntry)e.nextElement();
            InputStream is = inzip.getInputStream(entry);
            ZipEntry newentry = null;

            for(int i = 0; i < entryNames.length; ++i) {
               if (entryNames[i].equalsIgnoreCase(entry.getName())) {
                  newentry = new ZipEntry(newEntryNames[i]);
                  break;
               }
            }

            if (newentry == null) {
               newentry = new ZipEntry(entry.getName());
            }

            zos.putNextEntry(newentry);

            int len;
            while((len = is.read(buf)) != -1) {
               zos.write(buf, 0, len);
            }

            is.close();
            zos.closeEntry();
         }

         zos.close();
         inzip.close();
         File dest = new File(zipFile);
         File src = new File(tmpfile);
         UtilShared.deleteDestAndRenameFile(src, dest);
         ret = true;
         this.logger.debug("<-- renameZipEntries()");
         return ret;
      }
   }

   public ArrayList<String> unzipFile(String inFile) throws Exception {
      String workingDir = (new File(inFile)).getAbsoluteFile().getParent();
      if (!"".equals(workingDir) && !workingDir.endsWith("/") && !workingDir.endsWith("\\")) {
         workingDir = workingDir + File.separator;
      }

      return this.unzipFile(inFile, workingDir);
   }

   public ArrayList<String> unzipFile(String inFile, String extractFolder) throws Exception {
      this.logger.debug("--> unzipFile(). inFile=" + inFile + ", extractFolder=" + extractFolder);
      BufferedInputStream bis = null;
      BufferedOutputStream bos = null;
      ZipFile zipFile = null;
      ArrayList<String> entryList = null;
      byte[] buf = new byte[this.myThreadSafeData.getBufSize()];

      try {
         if (extractFolder == null || "".equals(extractFolder)) {
            extractFolder = ".";
         }

         if (!extractFolder.endsWith("/") && !extractFolder.endsWith("\\")) {
            extractFolder = extractFolder + File.separator;
         }

         zipFile = new ZipFile(inFile);

         for(Enumeration entries = zipFile.entries(); entries.hasMoreElements(); bis = null) {
            if (entryList == null) {
               entryList = new ArrayList();
            }

            ZipEntry entry = (ZipEntry)entries.nextElement();
            String outFile = extractFolder + entry.getName();
            entryList.add(outFile);
            bis = new BufferedInputStream(zipFile.getInputStream(entry));
            bos = new BufferedOutputStream(new FileOutputStream(new File(outFile)));

            int len;
            while((len = bis.read(buf)) != -1) {
               bos.write(buf, 0, len);
            }

            bos.close();
            bos = null;
            bis.close();
         }

         zipFile.close();
         zipFile = null;
      } finally {
         if (bis != null) {
            try {
               bis.close();
            } catch (Exception var23) {
            }
         }

         if (bos != null) {
            try {
               bos.close();
            } catch (Exception var22) {
            }
         }

         if (zipFile != null) {
            try {
               zipFile.close();
            } catch (Exception var21) {
            }
         }

      }

      this.logger.debug("<-- unzipFile()");
      return entryList;
   }

   protected synchronized String getIDESFileName(String folder, String senderGiin) throws Exception {
      this.logger.debug("--> getIDESFileName(). folder=" + folder + ", senderGiin=" + senderGiin);
      if (!"".equals(folder) && !folder.endsWith("/") && !folder.endsWith("\\")) {
         folder = folder + File.separator;
      }

      int attempts = 10;

      while(true) {
         String outfile = folder + this.sdfFileName.format(new Date(System.currentTimeMillis())) + "_" + senderGiin + ".zip";
         File file = new File(outfile);
         if (!file.exists() && (file.createNewFile() || attempts-- <= 0)) {
            if (attempts <= 0) {
               throw new Exception("Unable to getIDESFileName() - file=" + file.getAbsolutePath());
            } else {
               this.logger.debug("<-- getIDESFileName()");
               return outfile;
            }
         }

         Thread.sleep(100L);
      }
   }

   protected XMLGregorianCalendar genTaxYear(int year) {
      XMLGregorianCalendar taxyear = new XMLGregorianCalendarImpl(new GregorianCalendar());
      taxyear.setTimezone(Integer.MIN_VALUE);
      taxyear.setTime(Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE);
      taxyear.setDay(Integer.MIN_VALUE);
      taxyear.setMonth(Integer.MIN_VALUE);
      taxyear.setYear(year);
      return taxyear;
   }

   protected String getFileName(String filename) {
      File f = new File(filename);
      return f.getName();
   }

   protected boolean decrypt(String cipherTextFile, String encryptedAESKeyFile, String zippedSignedPlainTextFile, PrivateKey privkey) throws Exception {
      this.logger.debug("--> decrypt(). cipherTextFile= " + cipherTextFile + ", encryptedAESKeyFile=" + encryptedAESKeyFile + ", zippedSignedPlainTextFile=" + zippedSignedPlainTextFile);
      boolean ret = false;
      BufferedInputStream bis = null;
      byte[] skeyBuf = null;

      try {
         byte[] buf = new byte[this.myThreadSafeData.getBufSize()];
         bis = new BufferedInputStream(new FileInputStream(new File(encryptedAESKeyFile)));

         int len;
         while((len = bis.read(buf)) != -1) {
            if (skeyBuf == null) {
               skeyBuf = new byte[len];
               System.arraycopy(buf, 0, skeyBuf, 0, len);
            } else {
               int count = skeyBuf.length;
               skeyBuf = Arrays.copyOf(skeyBuf, skeyBuf.length + len);
               System.arraycopy(buf, 0, skeyBuf, count, len);
            }
         }

         bis.close();
         bis = null;
         Cipher cipher = Cipher.getInstance("RSA");
         cipher.init(4, privkey);
         SecretKey skey = (SecretKey)cipher.unwrap(skeyBuf, "AES", 3);
         ret = this.aes(2, cipherTextFile, zippedSignedPlainTextFile, skey) != null;
      } finally {
         if (bis != null) {
            try {
               bis.close();
            } catch (Exception var18) {
            }
         }

      }

      this.logger.debug("<-- decrypt()");
      return ret;
   }

   public ArrayList<String> unencryptZipPkg(String idesPkgFile, PrivateKey privateKey, boolean isApprover) throws Exception {
      return this.unencryptZipPkg(idesPkgFile, privateKey, isApprover, true);
   }

   public ArrayList<String> unencryptZipPkg(String idesPkgFile, PrivateKey privateKey, boolean isApprover, boolean isRenameZip) throws Exception {
      this.logger.debug("--> unencryptZipPkg(). idesPkg=" + idesPkgFile + ", isApprover=" + isApprover);
      boolean ret = false;
      String workingDir = (new File(idesPkgFile)).getAbsoluteFile().getParent();
      if (!"".equals(workingDir) && !workingDir.endsWith("/") && !workingDir.endsWith("\\")) {
         workingDir = workingDir + File.separator;
      }

      ArrayList<String> entryList = this.unzipFile(idesPkgFile, workingDir);
      String approverKeyFile = null;
      String receiverKeyFile = null;
      String payloadFile = null;
      String metadataFile = null;
      String receiverGiin = null;
      String senderGiin = null;

      String filename;
      for(int i = 0; i < entryList.size(); ++i) {
         filename = (String)entryList.get(i);
         if (filename.contains("Metadata")) {
            metadataFile = filename;
         } else if (filename.contains("Payload")) {
            payloadFile = filename;
         } else if (filename.contains("Key")) {
            if (receiverKeyFile == null) {
               receiverKeyFile = filename;
            } else {
               approverKeyFile = filename;
            }
         }
      }

      if (metadataFile == null) {
         throw new Exception("Invalid package - no metadata file");
      } else if (payloadFile == null) {
         throw new Exception("Invalid package - no payload file");
      } else {
         Unmarshaller unmrshlr = null;
         Object obj = null;

         try {
            unmrshlr = this.jaxbCtxMetadata1_1.createUnmarshaller();
            obj = unmrshlr.unmarshal(new File(metadataFile));
            if (obj instanceof JAXBElement) {
               JAXBElement<FATCAIDESSenderFileMetadataType> jaxbElem = (JAXBElement)obj;
               FATCAIDESSenderFileMetadataType metadataObj = (FATCAIDESSenderFileMetadataType)jaxbElem.getValue();
               receiverGiin = metadataObj.getFATCAEntityReceiverId();
               senderGiin = metadataObj.getFATCAEntitySenderId();
            }
         } catch (Exception var22) {
            unmrshlr = this.jaxbCtxMetadata1_0.createUnmarshaller();
            obj = unmrshlr.unmarshal(new File(metadataFile));
            if (obj instanceof JAXBElement) {
               JAXBElement<fatca.idessenderfilemetadata.FATCAIDESSenderFileMetadataType> jaxbElem = (JAXBElement)obj;
               fatca.idessenderfilemetadata.FATCAIDESSenderFileMetadataType metadataObj = (fatca.idessenderfilemetadata.FATCAIDESSenderFileMetadataType)jaxbElem.getValue();
               receiverGiin = metadataObj.getFATCAEntityReceiverId();
               senderGiin = metadataObj.getFATCAEntitySenderId();
            }
         }

         if (approverKeyFile != null && !receiverKeyFile.contains(receiverGiin)) {
            filename = approverKeyFile;
            approverKeyFile = receiverKeyFile;
            receiverKeyFile = filename;
         }

         if (receiverGiin != null && senderGiin != null && receiverKeyFile != null) {
            if (isApprover && approverKeyFile == null) {
               throw new Exception("Invalid package - no approverKeyFile");
            } else {
               String zippedSignedPlainTextFile = UtilShared.getTmpFileName(workingDir, senderGiin, "Payload.zip");
               if (approverKeyFile != null && isApprover) {
                  ret = this.decrypt(payloadFile, approverKeyFile, zippedSignedPlainTextFile, privateKey);
               } else {
                  ret = this.decrypt(payloadFile, receiverKeyFile, zippedSignedPlainTextFile, privateKey);
               }

               File file = new File(zippedSignedPlainTextFile);
               if (!ret) {
                  if (file.exists() && !file.delete()) {
                     file.deleteOnExit();
                  }

                  zippedSignedPlainTextFile = null;
               } else if (isRenameZip) {
                  String tmp = workingDir + senderGiin + "_Payload.zip";
                  File dest = new File(tmp);
                  UtilShared.deleteDestAndRenameFile(file, dest);
                  zippedSignedPlainTextFile = tmp;
               }

               if (zippedSignedPlainTextFile != null) {
                  entryList.add(zippedSignedPlainTextFile);
               }

               entryList.remove(payloadFile);
               file = new File(payloadFile);
               if (file.exists() && !file.delete()) {
                  file.deleteOnExit();
               }

               entryList.remove(receiverKeyFile);
               file = new File(receiverKeyFile);
               if (file.exists() && !file.delete()) {
                  file.deleteOnExit();
               }

               if (approverKeyFile != null) {
                  entryList.remove(approverKeyFile);
                  file = new File(approverKeyFile);
                  if (file.exists() && !file.delete()) {
                     file.deleteOnExit();
                  }
               }

               this.logger.debug("<-- unencryptZipPkg()");
               return entryList;
            }
         } else {
            throw new Exception("Invalid metadata file - missing receiver or sender giin OR corrupt zip file - no reveiverKeyFile");
         }
      }
   }

   protected ArrayList<String> unpack(String idesPkgFile, PrivateKey privateKey, boolean isApprover) throws Exception {
      this.logger.debug("--> unpack(). idesPkg=" + idesPkgFile + ", isApprover=" + isApprover);
      boolean isRenameZip = false;
      ArrayList<String> entryList = this.unencryptZipPkg(idesPkgFile, privateKey, isApprover, isRenameZip);
      ArrayList<String> outEntryList = null;

      for(int i = 0; i < entryList.size(); ++i) {
         String filename = (String)entryList.get(i);
         if (filename.endsWith("zip")) {
            ArrayList<String> tmpEntryList = this.unzipFile(filename);
            File file = new File(filename);
            if (file.exists() && !file.delete()) {
               file.deleteOnExit();
            }

            for(int j = 0; j < tmpEntryList.size(); ++j) {
               if (outEntryList == null) {
                  outEntryList = new ArrayList();
               }

               outEntryList.add((String)tmpEntryList.get(j));
            }
         } else {
            if (outEntryList == null) {
               outEntryList = new ArrayList();
            }

            outEntryList.add(filename);
         }
      }

      this.logger.debug("<-- unpack()");
      return outEntryList;
   }

   public String createMetadata1_0(String folder, String senderGiin, String receiverGiin, int taxyear, String senderFileId, Date fileCreateTs, String metaDataEmail) throws Exception {
      this.logger.debug("--> createMetadata1_0(). senderGiin=" + senderGiin + ", receiverGiin=" + receiverGiin + ", taxyear=" + taxyear + ", senderFileId=" + senderFileId + ", fileCreateTs=" + fileCreateTs);
      String metadatafile = UtilShared.getTmpFileName(folder, senderGiin, "Metadata.xml");
      JAXBContext jaxbCtxMetadata = JAXBContext.newInstance(fatca.idessenderfilemetadata.FATCAIDESSenderFileMetadataType.class);
      Marshaller mrshler = jaxbCtxMetadata.createMarshaller();
      mrshler.setProperty("jaxb.formatted.output", Boolean.TRUE);
      fatca.idessenderfilemetadata.FATCAIDESSenderFileMetadataType metadata = this.objFMetadata1_0.createFATCAIDESSenderFileMetadataType();
      JAXBElement<fatca.idessenderfilemetadata.FATCAIDESSenderFileMetadataType> jaxbElemMetadata = this.objFMetadata1_0.createFATCAIDESSenderFileMetadata(metadata);
      metadata.setFATCAEntCommunicationTypeCd(FATCAEntCommunicationTypeCdType.RPT);
      metadata.setFATCAEntitySenderId(senderGiin);
      metadata.setFileRevisionInd(false);
      metadata.setSenderFileId(senderFileId);
      metadata.setTaxYear(this.genTaxYear(taxyear));
      metadata.setFATCAEntityReceiverId(receiverGiin);
      metadata.setFileCreateTs(this.sdfFileCreateTs.format(fileCreateTs));
      metadata.setSenderContactEmailAddressTxt(metaDataEmail);
      FileWriter fw = new FileWriter(new File(metadatafile));
      mrshler.marshal(jaxbElemMetadata, fw);
      fw.close();
      this.logger.debug("<-- createMetadata1_0()");
      return metadatafile;
   }

   public String createMetadata1_1(String folder, String senderGiin, String receiverGiin, int taxyear, String senderFileId, Date fileCreateTs, FileFormatCdType fileFormatCd, BinaryEncodingSchemeCdType binaryEncodingCd, String metaDataEmail) throws Exception {
      this.logger.debug("--> createMetadata1_1(). senderGiin=" + senderGiin + ", receiverGiin=" + receiverGiin + ", taxyear=" + taxyear + ", senderFileId=" + senderFileId + ", fileCreateTs=" + fileCreateTs + ", fileFormatCd=" + fileFormatCd + ", binaryEncodingCd=" + binaryEncodingCd);
      String metadatafile = UtilShared.getTmpFileName(folder, senderGiin, "Metadata.xml");
      JAXBContext jaxbCtxMetadata = JAXBContext.newInstance(FATCAIDESSenderFileMetadataType.class);
      Marshaller mrshler = jaxbCtxMetadata.createMarshaller();
      mrshler.setProperty("jaxb.formatted.output", Boolean.TRUE);
      FATCAIDESSenderFileMetadataType metadata = this.objFMetadata1_1.createFATCAIDESSenderFileMetadataType();
      JAXBElement<FATCAIDESSenderFileMetadataType> jaxbElemMetadata = this.objFMetadata1_1.createFATCAIDESSenderFileMetadata(metadata);
      metadata.setFATCAEntCommunicationTypeCd(fatca.idessenderfilemetadata1_1.FATCAEntCommunicationTypeCdType.RPT);
      metadata.setFATCAEntitySenderId(senderGiin);
      metadata.setFileRevisionInd(false);
      metadata.setSenderFileId(senderFileId);
      metadata.setTaxYear(this.genTaxYear(taxyear));
      metadata.setFATCAEntityReceiverId(receiverGiin);
      metadata.setFileCreateTs(this.sdfFileCreateTs.format(fileCreateTs));
      metadata.setSenderContactEmailAddressTxt(metaDataEmail);
      metadata.setBinaryEncodingSchemeCd(binaryEncodingCd);
      metadata.setFileFormatCd(fileFormatCd);
      FileWriter fw = new FileWriter(new File(metadatafile));
      mrshler.marshal(jaxbElemMetadata, fw);
      fw.close();
      this.logger.debug("<-- createMetadata1_1()");
      return metadatafile;
   }

   protected String createPkgWithApprover(String signedXmlFile, String senderGiin, String receiverGiin, X509Certificate receiverPublicCert, String approverGiin, X509Certificate approvercert, int taxyear, IPackager.MetadataFileFormat fileFormat, IPackager.MetadataBinaryEncoding binaryEncoding, String metaDataEmail) throws Exception {
      this.logger.debug("--> createPkgWithApprover(). signedXmlFile= " + signedXmlFile + ", senderGiin=" + senderGiin + ", receiverGiin=" + receiverGiin + ", approverGiin=" + approverGiin + ", fileFormat=" + fileFormat + ", binaryEncoding=" + binaryEncoding);
      String folder = (new File(signedXmlFile)).getAbsoluteFile().getParent();
      String xmlzipFilename = UtilShared.getTmpFileName(folder, senderGiin, ".zip");
      this.createZipPkg(signedXmlFile, senderGiin, xmlzipFilename);
      String idesOutFile = this.encryptZipPkg(xmlzipFilename, senderGiin, receiverGiin, receiverPublicCert, approverGiin, approvercert, taxyear, fileFormat, binaryEncoding, metaDataEmail);
      File file = new File(xmlzipFilename);
      if (file.exists() && !file.delete()) {
         file.deleteOnExit();
      }

      this.logger.debug("<-- createPkgWithApprover()");
      return idesOutFile;
   }

   protected String signAndCreatePkgWithApprover(String unsignedXml, PrivateKey senderPrivateKey, X509Certificate senderPublicCert, String senderGiin, String receiverGiin, X509Certificate receiverPublicCert, String approverGiin, X509Certificate approverPublicCert, int taxyear, IPackager.MetadataFileFormat fileFormat, IPackager.MetadataBinaryEncoding binaryEncoding, boolean isStreaming, String metaDataEmail) throws Exception {
      this.logger.debug("--> signAndCreatePkg(). unsignedXml=" + unsignedXml + ", senderGiin=" + senderGiin + ", receiverGiin=" + receiverGiin + ", approverGiin=" + approverGiin + ", taxyear=" + taxyear + ", fileFormat=" + fileFormat + ", binaryEncoding=" + binaryEncoding + ", isStreaming=" + isStreaming);
      String signedxml = UtilShared.getTmpFileName(unsignedXml, "signed.xml");
      boolean success = false;
      String ret = null;
      if (isStreaming) {
         success = this.myThreadSafeData.getSigner().signXmlFileStreaming(unsignedXml, signedxml, senderPrivateKey, senderPublicCert);
      } else {
         success = this.myThreadSafeData.getSigner().signXmlFile(unsignedXml, signedxml, senderPrivateKey, senderPublicCert);
      }

      if (success) {
         ret = this.createPkgWithApprover(signedxml, senderGiin, receiverGiin, receiverPublicCert, approverGiin, approverPublicCert, taxyear, fileFormat, binaryEncoding, metaDataEmail);
      }

      if (this.keepSignedXmlAfterSignAndCreatePkgFlag) {
         UtilShared.renameToNextSequencedFile(signedxml, (String)null, unsignedXml, ".signed.xml");
      } else {
         File f = new File(signedxml);
         if (f.exists() && !f.delete()) {
            f.deleteOnExit();
         }
      }

      this.logger.debug("<-- signAndCreatePkg()");
      return ret;
   }

   protected String signBinaryFileAndCreatePkgWithApprover(String unsignedBinaryDoc, PrivateKey senderPrivateKey, X509Certificate senderPublicCert, String senderGiin, String receiverGiin, X509Certificate receiverPublicCert, String approverGiin, X509Certificate approverPublicCert, int taxyear, IPackager.MetadataFileFormat fileFormat, IPackager.MetadataBinaryEncoding binaryEncoding, boolean isStreaming, String metaDataEmail) throws Exception {
      this.logger.debug("--> signBinaryFileAndCreatePkg(). unsignedXml=" + unsignedBinaryDoc + ", senderGiin=" + senderGiin + ", receiverGiin=" + receiverGiin + ", taxyear=" + taxyear + ", fileFormat=" + fileFormat + ", binaryEncoding=" + binaryEncoding + ", isStreaming=" + isStreaming);
      String signedxml = UtilShared.getTmpFileName(unsignedBinaryDoc, "signed.xml");
      String ret = null;
      boolean success = false;
      if (isStreaming) {
         success = this.myThreadSafeData.getSigner().wrapBinaryFileInXmlAndSignStreaming(unsignedBinaryDoc, signedxml, senderPrivateKey, senderPublicCert);
      } else {
         success = this.myThreadSafeData.getSigner().wrapBinaryFileInXmlAndSign(unsignedBinaryDoc, signedxml, senderPrivateKey, senderPublicCert);
      }

      if (success) {
         ret = this.createPkgWithApprover(signedxml, senderGiin, receiverGiin, receiverPublicCert, approverGiin, approverPublicCert, taxyear, fileFormat, binaryEncoding, metaDataEmail);
      }

      File f = new File(signedxml);
      if (f.exists() && !f.delete()) {
         f.deleteOnExit();
      }

      this.logger.debug("<-- signBinaryFileAndCreatePkg()");
      return ret;
   }

   protected String signTextFileAndCreatePkgWithApprover(String unsignedText, PrivateKey senderPrivateKey, X509Certificate senderPublicCert, String senderGiin, String receiverGiin, X509Certificate receiverPublicCert, String approverGiin, X509Certificate approverPublicCert, int taxyear, IPackager.MetadataFileFormat fileFormat, IPackager.MetadataBinaryEncoding binaryEncoding, boolean isStreaming, String metaDataEmail) throws Exception {
      this.logger.debug("--> signTextFileAndCreatePkg(). unsignedXml=" + unsignedText + ", senderGiin=" + senderGiin + ", receiverGiin=" + receiverGiin + ", taxyear=" + taxyear + ", fileFormat=" + fileFormat + ", binaryEncoding=" + binaryEncoding + ", isStreaming=" + isStreaming);
      String signedxml = UtilShared.getTmpFileName(unsignedText, "signed.xml");
      String ret = null;
      boolean success = false;
      if (isStreaming) {
         success = this.myThreadSafeData.getSigner().wrapTextFileInXmlAndSignStreaming(unsignedText, signedxml, senderPrivateKey, senderPublicCert);
      } else {
         success = this.myThreadSafeData.getSigner().wrapTextFileInXmlAndSign(unsignedText, signedxml, senderPrivateKey, senderPublicCert);
      }

      if (success) {
         ret = this.createPkgWithApprover(signedxml, senderGiin, receiverGiin, receiverPublicCert, approverGiin, approverPublicCert, taxyear, fileFormat, binaryEncoding, metaDataEmail);
      }

      File f = new File(signedxml);
      if (f.exists() && !f.delete()) {
         f.deleteOnExit();
      }

      this.logger.debug("<-- signTextFileAndCreatePkg()");
      return ret;
   }

   public String signAndCreatePkgStreaming(String unsignedXml, PrivateKey senderPrivateKey, X509Certificate senderPublicCert, String senderGiin, String receiverGiin, X509Certificate receiverPublicCert, int taxyear, String metaDataEmail) throws Exception {
      boolean isStreaming = true;
      IPackager.MetadataFileFormat fileFormat = IPackager.MetadataFileFormat.XML;
      IPackager.MetadataBinaryEncoding binaryEncoding = IPackager.MetadataBinaryEncoding.NONE;
      String approverGiin = null;
      X509Certificate approverPublicCert = null;
      if (this.myThreadSafeData.getMetadataVer() == 1.0F) {
         fileFormat = null;
         binaryEncoding = null;
      }

      return this.signAndCreatePkgWithApprover(unsignedXml, senderPrivateKey, senderPublicCert, senderGiin, receiverGiin, receiverPublicCert, (String)approverGiin, (X509Certificate)approverPublicCert, taxyear, fileFormat, binaryEncoding, isStreaming, metaDataEmail);
   }

   public String signAndCreatePkgWithApproverStreaming(String unsignedXml, PrivateKey senderPrivateKey, X509Certificate senderPublicCert, String senderGiin, String receiverGiin, X509Certificate receiverPublicCert, String approverGiin, X509Certificate approverPublicCert, int taxyear, String metaDataEmail) throws Exception {
      boolean isStreaming = true;
      IPackager.MetadataFileFormat fileFormat = IPackager.MetadataFileFormat.XML;
      IPackager.MetadataBinaryEncoding binaryEncoding = IPackager.MetadataBinaryEncoding.NONE;
      if (this.myThreadSafeData.getMetadataVer() == 1.0F) {
         fileFormat = null;
         binaryEncoding = null;
      }

      return this.signAndCreatePkgWithApprover(unsignedXml, senderPrivateKey, senderPublicCert, senderGiin, receiverGiin, receiverPublicCert, approverGiin, approverPublicCert, taxyear, fileFormat, binaryEncoding, isStreaming, metaDataEmail);
   }

   public String signAndCreatePkg(String unsignedXml, PrivateKey senderPrivateKey, X509Certificate senderPublicCert, String senderGiin, String receiverGiin, X509Certificate receiverPublicCert, int taxyear, String metaDataEmail) throws Exception {
      boolean isStreaming = false;
      IPackager.MetadataFileFormat fileFormat = IPackager.MetadataFileFormat.XML;
      IPackager.MetadataBinaryEncoding binaryEncoding = IPackager.MetadataBinaryEncoding.NONE;
      String approverGiin = null;
      X509Certificate approverPublicCert = null;
      if (this.myThreadSafeData.getMetadataVer() == 1.0F) {
         fileFormat = null;
         binaryEncoding = null;
      }

      return this.signAndCreatePkgWithApprover(unsignedXml, senderPrivateKey, senderPublicCert, senderGiin, receiverGiin, receiverPublicCert, (String)approverGiin, (X509Certificate)approverPublicCert, taxyear, fileFormat, binaryEncoding, isStreaming, metaDataEmail);
   }

   public String signAndCreatePkgWithApprover(String unsignedXml, PrivateKey senderPrivateKey, X509Certificate senderPublicCert, String senderGiin, String receiverGiin, X509Certificate receiverPublicCert, String approverGiin, X509Certificate approverPublicCert, int taxyear, String metaDataEmail) throws Exception {
      boolean isStreaming = false;
      IPackager.MetadataFileFormat fileFormat = IPackager.MetadataFileFormat.XML;
      IPackager.MetadataBinaryEncoding binaryEncoding = IPackager.MetadataBinaryEncoding.NONE;
      if (this.myThreadSafeData.getMetadataVer() == 1.0F) {
         fileFormat = null;
         binaryEncoding = null;
      }

      return this.signAndCreatePkgWithApprover(unsignedXml, senderPrivateKey, senderPublicCert, senderGiin, receiverGiin, receiverPublicCert, approverGiin, approverPublicCert, taxyear, fileFormat, binaryEncoding, isStreaming, metaDataEmail);
   }

   public String createPkg(String signedXmlFile, String senderGiin, String receiverGiin, X509Certificate receiverPublicCert, int taxyear, String metaDataEmail) throws Exception {
      String approverGiin = null;
      X509Certificate approverPublicCert = null;
      IPackager.MetadataFileFormat fileFormat = IPackager.MetadataFileFormat.XML;
      IPackager.MetadataBinaryEncoding binaryEncoding = IPackager.MetadataBinaryEncoding.NONE;
      if (this.myThreadSafeData.getMetadataVer() == 1.0F) {
         fileFormat = null;
         binaryEncoding = null;
      }

      return this.createPkgWithApprover(signedXmlFile, senderGiin, receiverGiin, receiverPublicCert, (String)approverGiin, (X509Certificate)approverPublicCert, taxyear, fileFormat, binaryEncoding, metaDataEmail);
   }

   public String createPkgWithApprover(String signedXmlFile, String senderGiin, String receiverGiin, X509Certificate receiverPublicCert, String approverGiin, X509Certificate approverPublicCert, int taxyear, String metaDataEmail) throws Exception {
      IPackager.MetadataFileFormat fileFormat = IPackager.MetadataFileFormat.XML;
      IPackager.MetadataBinaryEncoding binaryEncoding = IPackager.MetadataBinaryEncoding.NONE;
      if (this.myThreadSafeData.getMetadataVer() == 1.0F) {
         fileFormat = null;
         binaryEncoding = null;
      }

      return this.createPkgWithApprover(signedXmlFile, senderGiin, receiverGiin, receiverPublicCert, approverGiin, approverPublicCert, taxyear, fileFormat, binaryEncoding, metaDataEmail);
   }

   public void createZipPkg(String signedXmlFile, String senderGiin, String outputZipFilename) throws Exception {
      this.logger.debug("--> createZipPkg(). signedXmlFile= " + signedXmlFile + ", senderGiin=" + senderGiin + ", outputZipFilename=" + outputZipFilename);
      boolean success = false;
      String folder = (new File(signedXmlFile)).getAbsoluteFile().getParent();
      if (outputZipFilename == null) {
         outputZipFilename = UtilShared.getTmpFileName(folder, senderGiin, "Payload.zip");
      }

      success = this.createZipFile(new String[]{signedXmlFile}, outputZipFilename);
      if (success) {
         success = this.renameZipEntry(outputZipFilename, this.getFileName(signedXmlFile), senderGiin + "_Payload.xml");
      }

      if (!success) {
         throw new Exception("uanble to create " + outputZipFilename);
      } else {
         this.logger.debug("<-- createZipPkg()");
      }
   }

   public ArrayList<String> unpack(String idesPkgFile, String keystoreType, String keystoreFile, String keystorePwd, String keyPwd, String keyAlias) throws Exception {
      this.logger.debug("--> unpack(). idesPkgFile=" + idesPkgFile + ", keystoreType=" + keystoreType + ", keystoreFile=" + keystoreFile + ", keyAlias=" + keyAlias);
      PrivateKey privateKey = UtilShared.getPrivateKey(keystoreType, keystoreFile, keystorePwd, keyPwd, keyAlias);
      ArrayList<String> ret = this.unpack(idesPkgFile, privateKey);
      this.logger.debug("<-- unpack()");
      return ret;
   }

   public ArrayList<String> unpack(String idesPkgFile, PrivateKey receiverPrivateKey) throws Exception {
      this.logger.debug("--> unpack(). idesPkgFile=" + idesPkgFile);
      boolean isApprover = false;
      ArrayList<String> ret = this.unpack(idesPkgFile, receiverPrivateKey, isApprover);
      this.logger.debug("<-- unpack()");
      return ret;
   }

   public ArrayList<String> unpackForApprover(String idesPkgFile, String approverKeystoreType, String approverKeystoreFile, String approverKeystorePwd, String approverKeyPwd, String approverKeyAlias) throws Exception {
      this.logger.debug("--> unpackForApprover(). idesPkgFile=" + idesPkgFile + ", approverKeystoreType=" + approverKeystoreType + ", approverKeystoreFile=" + approverKeystoreFile + ", approverKeyAlias=" + approverKeyAlias);
      PrivateKey approverPrivateKey = UtilShared.getPrivateKey(approverKeystoreType, approverKeystoreFile, approverKeystorePwd, approverKeyPwd, approverKeyAlias);
      ArrayList<String> ret = this.unpackForApprover(idesPkgFile, approverPrivateKey);
      this.logger.debug("<-- unpackForApprover()");
      return ret;
   }

   public ArrayList<String> unpackForApprover(String idesPkgFile, PrivateKey approverPrivateKey) throws Exception {
      this.logger.debug("--> unpackForApprover(). idesPkgFile=" + idesPkgFile);
      ArrayList<String> ret = this.unpack(idesPkgFile, approverPrivateKey, true);
      this.logger.debug("<-- unpackForApprover()");
      return ret;
   }

   public String signBinaryFileAndCreatePkg(String unsignedBinaryDoc, PrivateKey senderPrivateKey, X509Certificate senderPublicCert, String senderGiin, String receiverGiin, X509Certificate receiverPublicCert, int taxyear, IPackager.MetadataFileFormat fileFormat, String metaDataEmail) throws Exception {
      boolean isStreaming = false;
      IPackager.MetadataBinaryEncoding binaryEncoding = IPackager.MetadataBinaryEncoding.BASE_64;
      String approverGiin = null;
      X509Certificate approverPublicCert = null;
      switch($SWITCH_TABLE$fatca$intf$IPackager$MetadataFileFormat()[fileFormat.ordinal()]) {
      case 3:
      case 4:
      case 5:
         return this.signBinaryFileAndCreatePkgWithApprover(unsignedBinaryDoc, senderPrivateKey, senderPublicCert, senderGiin, receiverGiin, receiverPublicCert, (String)approverGiin, (X509Certificate)approverPublicCert, taxyear, fileFormat, binaryEncoding, isStreaming, metaDataEmail);
      default:
         throw new Exception("invalid fileFormat=" + fileFormat + ". Valid binary fileFormat JPG|PDF|RTF");
      }
   }

   public String signBinaryFileAndCreatePkgStreaming(String unsignedBinaryDoc, PrivateKey senderPrivateKey, X509Certificate senderPublicCert, String senderGiin, String receiverGiin, X509Certificate receiverPublicCert, int taxyear, IPackager.MetadataFileFormat fileFormat, String metaDataEmail) throws Exception {
      boolean isStreaming = true;
      IPackager.MetadataBinaryEncoding binaryEncoding = IPackager.MetadataBinaryEncoding.BASE_64;
      String approverGiin = null;
      X509Certificate approverPublicCert = null;
      switch($SWITCH_TABLE$fatca$intf$IPackager$MetadataFileFormat()[fileFormat.ordinal()]) {
      case 3:
      case 4:
      case 5:
         return this.signBinaryFileAndCreatePkgWithApprover(unsignedBinaryDoc, senderPrivateKey, senderPublicCert, senderGiin, receiverGiin, receiverPublicCert, (String)approverGiin, (X509Certificate)approverPublicCert, taxyear, fileFormat, binaryEncoding, isStreaming, metaDataEmail);
      default:
         throw new Exception("invalid fileFormat=" + fileFormat + ". Valid binary fileFormat JPG|PDF|RTF");
      }
   }

   public String signTextFileAndCreatePkg(String unsignedText, PrivateKey senderPrivateKey, X509Certificate senderPublicCert, String senderGiin, String receiverGiin, X509Certificate receiverPublicCert, int taxyear, String metaDataEmail) throws Exception {
      boolean isStreaming = false;
      IPackager.MetadataBinaryEncoding binaryEncoding = IPackager.MetadataBinaryEncoding.NONE;
      String approverGiin = null;
      X509Certificate approverPublicCert = null;
      IPackager.MetadataFileFormat fileFormat = IPackager.MetadataFileFormat.TXT;
      return this.signTextFileAndCreatePkgWithApprover(unsignedText, senderPrivateKey, senderPublicCert, senderGiin, receiverGiin, receiverPublicCert, (String)approverGiin, (X509Certificate)approverPublicCert, taxyear, fileFormat, binaryEncoding, isStreaming, metaDataEmail);
   }

   public String signTextFileAndCreatePkgStreaming(String unsignedText, PrivateKey senderPrivateKey, X509Certificate senderPublicCert, String senderGiin, String receiverGiin, X509Certificate receiverPublicCert, int taxyear, String metaDataEmail) throws Exception {
      boolean isStreaming = true;
      IPackager.MetadataBinaryEncoding binaryEncoding = IPackager.MetadataBinaryEncoding.NONE;
      String approverGiin = null;
      X509Certificate approverPublicCert = null;
      IPackager.MetadataFileFormat fileFormat = IPackager.MetadataFileFormat.TXT;
      return this.signTextFileAndCreatePkgWithApprover(unsignedText, senderPrivateKey, senderPublicCert, senderGiin, receiverGiin, receiverPublicCert, (String)approverGiin, (X509Certificate)approverPublicCert, taxyear, fileFormat, binaryEncoding, isStreaming, metaDataEmail);
   }

   public void setBufSize(int val) {
      this.myThreadSafeData.setBufSize(val);
   }

   public int getBufSize() {
      return this.myThreadSafeData.getBufSize();
   }

   public ISigner getSigner() {
      return this.myThreadSafeData.getSigner();
   }

   public void setSigner(ISigner val) {
      this.myThreadSafeData.setSigner(val);
   }

   public void setAesCipherOpMode(String aesCipherOpMode) throws Exception {
      if ("CBC".equalsIgnoreCase(aesCipherOpMode)) {
         this.myThreadSafeData.setAesCipherOpMode(IPackager.AesCipherOpMode.CBC);
      } else {
         if (!"ECB".equalsIgnoreCase(aesCipherOpMode)) {
            throw new Exception(aesCipherOpMode + " not allowed. Allowed values are CBC and ECB");
         }

         this.myThreadSafeData.setAesCipherOpMode(IPackager.AesCipherOpMode.ECB);
      }

   }

   public String getAesCipherOpMode() {
      switch($SWITCH_TABLE$fatca$intf$IPackager$AesCipherOpMode()[this.myThreadSafeData.getAesCipherOpMode().ordinal()]) {
      case 1:
         return "CBC";
      case 2:
         return "ECB";
      default:
         return null;
      }
   }

   public boolean isDualModeDecryption() {
      return this.myThreadSafeData.isDualModeDecryption();
   }

   public void setDualModeDecryption(boolean flag) {
      this.myThreadSafeData.setDualModeDecryption(flag);
   }

   public String encryptZipPkg(String xmlzipFilename, String senderGiin, String receiverGiin, X509Certificate receiverPublicCert, String approverGiin, X509Certificate approverPublicCert, int taxyear, IPackager.MetadataFileFormat fileFormat, IPackager.MetadataBinaryEncoding binaryEncoding, String metaDataEmail) throws Exception {
      this.logger.debug("--> encryptZipPkg(). xmlzipFilename= " + xmlzipFilename + ", senderGiin=" + senderGiin + ", receiverGiin=" + receiverGiin + ", approverGiin=" + approverGiin + ", taxyear=" + taxyear + ", fileFormat=" + fileFormat + ", binaryEncoding=" + binaryEncoding);
      boolean success = false;
      String folder = (new File(xmlzipFilename)).getAbsoluteFile().getParent();
      Date date = new Date();
      String idesOutFile = this.getIDESFileName(folder, senderGiin);
      File file = new File(idesOutFile);
      String senderFileId = file.getName();
      String metadatafile = null;
      FileFormatCdType fileFormatCd = null;
      BinaryEncodingSchemeCdType binaryEncodingCd = null;
      binaryEncodingCd = this.getBinaryEncoding(binaryEncoding);
      fileFormatCd = this.getFileFormat(fileFormat);
      if (fileFormatCd != null && binaryEncodingCd != null) {
         metadatafile = this.createMetadata1_1(folder, senderGiin, receiverGiin, taxyear, senderFileId, date, fileFormatCd, binaryEncodingCd, metaDataEmail);
      } else {
         metadatafile = this.createMetadata1_0(folder, senderGiin, receiverGiin, taxyear, senderFileId, date, metaDataEmail);
      }

      Certificate[] certs = null;
      String[] encryptedAESKeyOutFiles = null;
      if (approverPublicCert != null && approverGiin != null) {
         certs = new X509Certificate[]{receiverPublicCert, approverPublicCert};
         encryptedAESKeyOutFiles = new String[]{UtilShared.getTmpFileName(folder, receiverGiin, "Key"), UtilShared.getTmpFileName(folder, approverGiin, "Key")};
      } else {
         if (receiverPublicCert == null) {
            throw new Exception("both approvingEntityCert and receivingEntityCert is null");
         }

         certs = new X509Certificate[]{receiverPublicCert};
         encryptedAESKeyOutFiles = new String[]{UtilShared.getTmpFileName(folder, receiverGiin, "Key")};
      }

      String xmlZippedEncryptedFile = UtilShared.getTmpFileName(folder, senderGiin, "Payload");
      success = this.encrypt(xmlzipFilename, xmlZippedEncryptedFile, (Certificate[])certs, encryptedAESKeyOutFiles);
      if (!success) {
         throw new Exception("encryption failed. xmlzipFilename=" + xmlzipFilename);
      } else {
         int count = false;
         String[] infiles = new String[encryptedAESKeyOutFiles.length + 2];

         int count;
         for(count = 0; count < encryptedAESKeyOutFiles.length; ++count) {
            infiles[count] = encryptedAESKeyOutFiles[count];
         }

         infiles[count++] = xmlZippedEncryptedFile;
         infiles[count] = metadatafile;
         success = this.createZipFile(infiles, idesOutFile);
         if (success) {
            if (encryptedAESKeyOutFiles.length == 2) {
               success = this.renameZipEntries(idesOutFile, new String[]{this.getFileName(xmlZippedEncryptedFile), this.getFileName(metadatafile), this.getFileName(encryptedAESKeyOutFiles[0]), this.getFileName(encryptedAESKeyOutFiles[1])}, new String[]{senderGiin + "_Payload", senderGiin + "_Metadata.xml", receiverGiin + "_Key", approverGiin + "_Key"});
            } else {
               success = this.renameZipEntries(idesOutFile, new String[]{this.getFileName(xmlZippedEncryptedFile), this.getFileName(metadatafile), this.getFileName(encryptedAESKeyOutFiles[0])}, new String[]{senderGiin + "_Payload", senderGiin + "_Metadata.xml", receiverGiin + "_Key"});
            }
         }

         if (!success) {
            throw new Exception("unable to create zip file " + idesOutFile);
         } else {
            for(int i = 0; i < infiles.length; ++i) {
               file = new File(infiles[i]);
               if (file.exists() && !file.delete()) {
                  file.deleteOnExit();
               }
            }

            this.logger.debug("<-- encryptZipPkg()");
            return idesOutFile;
         }
      }
   }

   public void setMetadataVer(float metadataVer) {
      this.myThreadSafeData.setMetadataVer(metadataVer);
   }

   public void setKeepSignedXmlAfterSignAndCreatePkgFlag(boolean flag) {
      this.keepSignedXmlAfterSignAndCreatePkgFlag = flag;
   }

   public boolean getKeepSignedXmlAfterSignAndCreatePkgFlag() {
      return this.keepSignedXmlAfterSignAndCreatePkgFlag;
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$fatca$intf$IPackager$MetadataFileFormat() {
      int[] var10000 = $SWITCH_TABLE$fatca$intf$IPackager$MetadataFileFormat;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[IPackager.MetadataFileFormat.values().length];

         try {
            var0[IPackager.MetadataFileFormat.JPG.ordinal()] = 3;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[IPackager.MetadataFileFormat.PDF.ordinal()] = 4;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[IPackager.MetadataFileFormat.RTF.ordinal()] = 5;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[IPackager.MetadataFileFormat.TXT.ordinal()] = 2;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[IPackager.MetadataFileFormat.XML.ordinal()] = 1;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$fatca$intf$IPackager$MetadataFileFormat = var0;
         return var0;
      }
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$fatca$intf$IPackager$MetadataBinaryEncoding() {
      int[] var10000 = $SWITCH_TABLE$fatca$intf$IPackager$MetadataBinaryEncoding;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[IPackager.MetadataBinaryEncoding.values().length];

         try {
            var0[IPackager.MetadataBinaryEncoding.BASE_64.ordinal()] = 2;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[IPackager.MetadataBinaryEncoding.NONE.ordinal()] = 1;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$fatca$intf$IPackager$MetadataBinaryEncoding = var0;
         return var0;
      }
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$fatca$intf$IPackager$AesCipherOpMode() {
      int[] var10000 = $SWITCH_TABLE$fatca$intf$IPackager$AesCipherOpMode;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[IPackager.AesCipherOpMode.values().length];

         try {
            var0[IPackager.AesCipherOpMode.CBC.ordinal()] = 1;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[IPackager.AesCipherOpMode.ECB.ordinal()] = 2;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$fatca$intf$IPackager$AesCipherOpMode = var0;
         return var0;
      }
   }

   protected class MyThreadSafeData {
      private int bufSize;
      private ISigner signer;
      private IPackager.AesCipherOpMode aesCipherOpMode;
      private Boolean isDualModeDecryption;
      private Float metadataVer;
      private final String genericLock;
      private final String cipherLock;
      private final String signerLock;
      // $FF: synthetic field
      private static int[] $SWITCH_TABLE$fatca$intf$IPackager$AesCipherOpMode;

      protected MyThreadSafeData() {
         this.bufSize = FATCAPackager.this.defaultBufSize;
         this.signer = new FATCAXmlSigner();
         this.aesCipherOpMode = IPackager.AesCipherOpMode.CBC;
         this.isDualModeDecryption = false;
         this.metadataVer = 1.0F;
         this.genericLock = "genericLock";
         this.cipherLock = "cipherLock";
         this.signerLock = "signerLock";
      }

      public float getMetadataVer() {
         String var1 = "genericLock";
         synchronized("genericLock") {
            return this.metadataVer;
         }
      }

      public void setMetadataVer(float metadataVer) {
         String var2 = "genericLock";
         synchronized("genericLock") {
            this.metadataVer = metadataVer;
         }
      }

      public boolean isDualModeDecryption() {
         String var1 = "genericLock";
         synchronized("genericLock") {
            return this.isDualModeDecryption;
         }
      }

      public void setDualModeDecryption(boolean flag) {
         String var2 = "genericLock";
         synchronized("genericLock") {
            this.isDualModeDecryption = flag;
         }
      }

      public IPackager.AesCipherOpMode getAesCipherOpMode() {
         String var1 = "cipherLock";
         synchronized("cipherLock") {
            return this.aesCipherOpMode;
         }
      }

      public void setAesCipherOpMode(IPackager.AesCipherOpMode aesCipherOpMode) {
         String var2 = "cipherLock";
         synchronized("cipherLock") {
            this.aesCipherOpMode = aesCipherOpMode;
         }
      }

      public String getAesTransformation() {
         String var1 = "cipherLock";
         synchronized("cipherLock") {
            switch($SWITCH_TABLE$fatca$intf$IPackager$AesCipherOpMode()[this.aesCipherOpMode.ordinal()]) {
            case 1:
               return "AES/CBC/PKCS5Padding";
            case 2:
               return "AES/ECB/PKCS5Padding";
            default:
               return null;
            }
         }
      }

      public ISigner getSigner() {
         String var1 = "signerLock";
         synchronized("signerLock") {
            return this.signer;
         }
      }

      public void setSigner(ISigner signer) {
         String var2 = "signerLock";
         synchronized("signerLock") {
            this.signer = signer;
         }
      }

      public int getBufSize() {
         String var1 = "genericLock";
         synchronized("genericLock") {
            return this.bufSize;
         }
      }

      public void setBufSize(int val) {
         String var2 = "genericLock";
         synchronized("genericLock") {
            this.bufSize = val;
         }
      }

      // $FF: synthetic method
      static int[] $SWITCH_TABLE$fatca$intf$IPackager$AesCipherOpMode() {
         int[] var10000 = $SWITCH_TABLE$fatca$intf$IPackager$AesCipherOpMode;
         if (var10000 != null) {
            return var10000;
         } else {
            int[] var0 = new int[IPackager.AesCipherOpMode.values().length];

            try {
               var0[IPackager.AesCipherOpMode.CBC.ordinal()] = 1;
            } catch (NoSuchFieldError var2) {
            }

            try {
               var0[IPackager.AesCipherOpMode.ECB.ordinal()] = 2;
            } catch (NoSuchFieldError var1) {
            }

            $SWITCH_TABLE$fatca$intf$IPackager$AesCipherOpMode = var0;
            return var0;
         }
      }
   }
}
