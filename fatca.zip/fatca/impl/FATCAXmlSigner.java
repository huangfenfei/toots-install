package fatca.impl;

import com.sun.org.apache.xml.internal.security.Init;
import com.sun.org.apache.xml.internal.security.c14n.Canonicalizer;
import com.sun.org.apache.xml.internal.security.utils.Base64;
import com.sun.org.apache.xml.internal.security.utils.IgnoreAllErrorHandler;
import fatca.intf.ISigner;
import fatca.util.UtilShared;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.Signature;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;
import java.util.UUID;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dom.DOMStructure;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureProperties;
import javax.xml.crypto.dsig.SignatureProperty;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLObject;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.DigestMethodParameterSpec;
import javax.xml.crypto.dsig.spec.SignatureMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class FATCAXmlSigner implements ISigner {
   protected Logger logger = Logger.getLogger((new Object() {
   }).getClass().getEnclosingClass().getName());
   protected final String xmlTagReferenceUriValue = "FATCA";
   protected final String xmlTagSignatureIdValue = "SignatureId";
   protected final String xmlTagDigestMethodAlgoValue = "http://www.w3.org/2001/04/xmlenc#sha256";
   protected final String xmlTagSignatureMethodAlgoValue = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256";
   protected final String SIGNATUER_ALGO = "SHA256withRSA";
   protected final String MESSAGE_DIGEST_ALGO = "SHA-256";
   protected Provider defaultSignatureFactoryProvider = null;
   protected Provider defaultSignatureProvider = null;
   protected Provider defaultMessageDigestProvider = null;
   protected final int STARTTAG = 0;
   protected final int ENDTAG = 1;
   protected final int CHAR = 2;
   protected int defaultBufSize = 8192;
   protected int defaultChunkStreamingSize = 8192;
   protected FATCAXmlSigner.MyThreadSafeData myThreadSafeData = new FATCAXmlSigner.MyThreadSafeData((FATCAXmlSigner.MyThreadSafeData)null);
   private String uuid = UUID.randomUUID().toString().replace("-", "");
   public StringBuilder digestBuf = null;
   public boolean isValidateAllSignature = false;
   public Boolean isValidationSuccess = true;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigXmlTransform;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigRefIdPos;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigDocType;

   public FATCAXmlSigner() {
      if (!Init.isInitialized()) {
         Init.init();
      }

   }

   protected byte[][] getWrapperTags() throws Exception {
      String ns = this.myThreadSafeData.getWrapperNS();
      String prefix = this.myThreadSafeData.getWrapperPrefix();
      String xsi = null;
      String xsiSchemaLoc = null;
      boolean isXsi = this.myThreadSafeData.isWrapperXsi();
      boolean isXsiSchemaLoc = this.myThreadSafeData.isWrapperXsiSchemaLoc();
      if (isXsi) {
         xsi = this.myThreadSafeData.getWrapperXsi();
         if (isXsiSchemaLoc) {
            xsiSchemaLoc = this.myThreadSafeData.getWrapperXsiSchemaLoc();
         }
      }

      if ("".equals(ns) && !"".equals(prefix)) {
         throw new Exception("non-empty wrapperPrefix not allower for empty wrapperNS");
      } else {
         byte[][] tags = new byte[2][];
         Canonicalizer canonicalizer = Canonicalizer.getInstance("http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
         String startTag;
         String endTag;
         if ("".equals(prefix)) {
            startTag = "<Wrapper xmlns=\"" + ns + "\"" + (xsi == null ? "" : " " + xsi + (xsiSchemaLoc == null ? "" : " " + xsiSchemaLoc)) + ">";
            endTag = "</Wrapper>";
         } else {
            startTag = "<" + prefix + ":Wrapper xmlns" + ":" + prefix + "=\"" + ns + "\"" + (xsi == null ? "" : " " + xsi + (xsiSchemaLoc == null ? "" : " " + xsiSchemaLoc)) + ">";
            endTag = "</" + prefix + ":Wrapper>";
         }

         startTag = new String(canonicalizer.canonicalize((startTag + endTag).getBytes()));
         startTag = startTag.replaceFirst(endTag, "");
         tags[0] = startTag.getBytes();
         tags[1] = endTag.getBytes();
         return tags;
      }
   }

   protected void processXmlFrag(int type, String tag, String val, MessageDigest messageDigest, Canonicalizer canonicalizer, DocumentBuilder docBuilderNSTrue, String wrapperPrefix, String wrapperNSUri) throws Exception {
      this.logger.trace("--> processXmlFrag(). type=" + type + ", tag=" + tag + ", val=" + val);
      String addedStartTag = "";
      String addedEndTag = "";
      if (type == 0) {
         addedEndTag = "</" + tag + ">";
      } else if (type == 1) {
         addedStartTag = "<" + tag + ">";
      }

      String fakeStartElem = "";
      String fakeEndElem = "";
      String wrapperNS = wrapperPrefix == null ? (wrapperNSUri == null ? null : "xmlns=\"" + wrapperNSUri + "\"") : (wrapperNSUri == null ? null : "xmlns:" + wrapperPrefix + "=\"" + wrapperNSUri + "\"");
      if (wrapperNS != null || type == 2) {
         fakeStartElem = "<fake" + this.uuid;
         fakeEndElem = "</fake" + this.uuid;
         if (wrapperNS != null) {
            fakeStartElem = fakeStartElem + " " + wrapperNS;
         }

         fakeStartElem = fakeStartElem + ">";
         fakeEndElem = fakeEndElem + ">";
      }

      addedStartTag = fakeStartElem + addedStartTag;
      addedEndTag = addedEndTag + fakeEndElem;
      String modifiedval = addedStartTag + val + addedEndTag;
      this.logger.trace("modifiedval=" + modifiedval);
      String digestval = null;

      Document doc;
      try {
         doc = docBuilderNSTrue.parse(new InputSource(new StringReader(modifiedval)));
      } catch (Throwable var20) {
         var20.printStackTrace();
         DocumentBuilderFactory dbfNSFalse = DocumentBuilderFactory.newInstance();
         dbfNSFalse.setNamespaceAware(false);
         DocumentBuilder docBuilderNSFalse = dbfNSFalse.newDocumentBuilder();
         docBuilderNSFalse.setErrorHandler(new IgnoreAllErrorHandler());
         doc = docBuilderNSFalse.parse(new InputSource(new StringReader(modifiedval)));
      }

      digestval = new String(canonicalizer.canonicalizeSubtree(doc));
      digestval = digestval.replace(addedStartTag, "").replace(addedEndTag, "");
      this.logger.trace("digestval=" + digestval);
      messageDigest.update(digestval.getBytes());
      if (this.digestBuf != null) {
         this.digestBuf.append(digestval);
      }

      this.logger.trace("<-- processXmlFrag()");
   }

   protected void writeBase64BinaryAndOptionallyCalcMsgDigest(String infile, String newline, OutputStream os, boolean isCalcDigest, MessageDigest messageDigest) throws Exception {
      this.logger.debug("--> writeBase64BinaryAndOptionallyCalcMsgDigest(). infile=" + infile);
      BufferedInputStream bis = new BufferedInputStream(new FileInputStream(new File(infile)));
      if (isCalcDigest && messageDigest == null) {
         throw new Exception("messageDigest must not be null if isCalcDigest=true");
      } else {
         int offset = 0;
         int lastlinelen = 0;

         int len;
         byte[] buf;
         byte[] tmpBuf;
         for(buf = new byte[this.myThreadSafeData.getBufSize()]; (len = bis.read(buf, offset, buf.length - offset)) != -1; lastlinelen = this.writeEncodedBinary(lastlinelen, tmpBuf, newline, os)) {
            if (isCalcDigest) {
               messageDigest.update(buf, offset, len);
            }

            int nextoffset = (offset + len) % 3;
            tmpBuf = new byte[offset + len - nextoffset];
            System.arraycopy(buf, 0, tmpBuf, 0, offset + len - nextoffset);

            for(int i = 0; i < nextoffset; ++i) {
               buf[i] = buf[offset + len - nextoffset + i];
            }

            offset = nextoffset;
         }

         if (offset > 0) {
            tmpBuf = new byte[offset];
            System.arraycopy(buf, 0, tmpBuf, 0, offset);
            this.writeEncodedBinary(lastlinelen, tmpBuf, newline, os);
         }

         bis.close();
         this.logger.debug("<-- writeBase64BinaryAndOptionallyCalcMsgDigest()");
      }
   }

   protected String getCanonicalizationMethod(FATCAXmlSigner.SigXmlTransform sigXmlTransform) {
      switch($SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigXmlTransform()[sigXmlTransform.ordinal()]) {
      case 1:
      case 5:
      default:
         return "http://www.w3.org/TR/2001/REC-xml-c14n-20010315";
      case 2:
         return "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments";
      case 3:
         return "http://www.w3.org/2001/10/xml-exc-c14n#";
      case 4:
         return "http://www.w3.org/2001/10/xml-exc-c14n#WithComments";
      }
   }

   protected byte[][] getSigRefIdPosTags() {
      byte[][] tags = new byte[2][];
      String prefix = this.myThreadSafeData.getSignaturePrefix();
      switch($SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigRefIdPos()[this.myThreadSafeData.getSigRefIdPos().ordinal()]) {
      case 1:
      default:
         if ("".equals(prefix)) {
            tags[0] = "<Object xmlns=\"http://www.w3.org/2000/09/xmldsig#\" Id=\"FATCA\">".getBytes();
            tags[1] = "</Object>".getBytes();
         } else {
            tags[0] = ("<" + prefix + ":Object xmlns" + ":" + prefix + "=\"" + "http://www.w3.org/2000/09/xmldsig#" + "\" Id=\"" + "FATCA" + "\">").getBytes();
            tags[1] = ("</" + prefix + ":Object>").getBytes();
         }
         break;
      case 2:
         if ("".equals(prefix)) {
            tags[0] = "<SignatureProperty xmlns=\"http://www.w3.org/2000/09/xmldsig#\" Id=\"FATCA\" Target=\"#SignatureId\">".getBytes();
            tags[1] = "</SignatureProperty>".getBytes();
         } else {
            tags[0] = ("<" + prefix + ":SignatureProperty xmlns" + ":" + prefix + "=\"" + "http://www.w3.org/2000/09/xmldsig#" + "\" Id=\"" + "FATCA" + "\" Target=\"#" + "SignatureId" + "\">").getBytes();
            tags[1] = ("</" + prefix + ":SignatureProperty>").getBytes();
         }
         break;
      case 3:
         if ("".equals(prefix)) {
            tags[0] = "<SignatureProperties xmlns=\"http://www.w3.org/2000/09/xmldsig#\" Id=\"FATCA\"><SignatureProperty Target=\"#SignatureId\">".getBytes();
            tags[1] = "</SignatureProperty></SignatureProperties>".getBytes();
         } else {
            tags[0] = ("<" + prefix + ":SignatureProperties xmlns" + ":" + prefix + "=\"" + "http://www.w3.org/2000/09/xmldsig#" + "\" Id=\"" + "FATCA" + "\"><" + prefix + ":SignatureProperty Target=\"#" + "SignatureId" + "\">").getBytes();
            tags[1] = ("</" + prefix + ":SignatureProperty></" + prefix + ":SignatureProperties>").getBytes();
         }
      }

      return tags;
   }

   protected FATCAXmlSigner.ParseXmlReturn calcCanonicalizedXmlMsgDigestByParsingDocChunk(String infile, MessageDigest messageDigest, FATCAXmlSigner.SigXmlTransform sigXmlTransform) throws Exception {
      this.logger.debug("--> calcCanonicalizedXmlMsgDigestByParsingDocChunk(). infile=" + infile + ", sigXmlTransform=" + sigXmlTransform);
      StringBuilder sbns = new StringBuilder();
      StringBuilder sbChunk = new StringBuilder();
      StringBuilder parseBuf = new StringBuilder();
      String retEndXml = null;
      XMLStreamReader reader = null;
      FATCAXmlSigner.ParseXmlReturn ret = new FATCAXmlSigner.ParseXmlReturn((FATCAXmlSigner.ParseXmlReturn)null);
      HashMap<String, String> hashNS = new HashMap();
      HashMap<String, String> hashChunkNS = new HashMap();
      Stack<String> stackTag = new Stack();
      Stack<String> stackChunkStartTag = new Stack();
      Stack<String> stackChunkEndTag = new Stack();
      Stack<HashMap<String, String>> stackNS = new Stack();
      int minChunkSize = this.myThreadSafeData.getXmlChunkStreamingSize();
      boolean isEndDoc = false;

      try {
         byte[][] sigRefIdPosTags = this.getSigRefIdPosTags();
         byte[] digestPrefix = sigRefIdPosTags[0];
         byte[] digestSuffix = sigRefIdPosTags[1];
         messageDigest.update(digestPrefix);
         if (this.digestBuf != null) {
            this.digestBuf.setLength(0);
            this.digestBuf.append(new String(digestPrefix));
         }

         Canonicalizer canonicalizer = Canonicalizer.getInstance(this.getCanonicalizationMethod(sigXmlTransform));
         DocumentBuilderFactory dbfNSTrue = DocumentBuilderFactory.newInstance();
         dbfNSTrue.setNamespaceAware(true);
         DocumentBuilder docBuilderNSTrue = dbfNSTrue.newDocumentBuilder();
         docBuilderNSTrue.setErrorHandler(new IgnoreAllErrorHandler());
         reader = XMLInputFactory.newFactory().createXMLStreamReader(new FileInputStream(new File(infile)));
         this.logger.debug("parsing ----------------------- 3 " + reader.getEventType());

         while(!isEndDoc) {
            sbChunk.setLength(0);
            String prefix;
            String localname;
            String qnameS;
            String tmpS;
            int nscount;
            int count;
            switch(reader.getEventType()) {
            case 1:
               prefix = reader.getPrefix();
               localname = reader.getLocalName();
               qnameS = (prefix == "" ? "" : prefix + ":") + localname;
               stackTag.push(qnameS);
               stackChunkStartTag.push(qnameS);
               sbChunk.append('<');
               sbChunk.append(qnameS);
               nscount = reader.getNamespaceCount();
               int i;
               if (nscount > 0) {
                  if (!stackNS.empty()) {
                     HashMap<String, String> tmpHashNS = (HashMap)((HashMap)stackNS.peek()).clone();
                     hashNS = tmpHashNS;
                  } else {
                     hashNS = new HashMap();
                  }

                  stackNS.push(hashNS);

                  for(i = 0; i < nscount; ++i) {
                     prefix = reader.getNamespacePrefix(i);
                     String nsuri = reader.getNamespaceURI(i);
                     if (nsuri == null) {
                        nsuri = "";
                     }

                     nsuri = "\"" + nsuri + "\"";
                     sbChunk.append(" ");
                     sbChunk.append("xmlns");
                     if (prefix != null) {
                        sbChunk.append(":");
                        sbChunk.append(prefix);
                        hashNS.put("xmlns:" + prefix, nsuri);
                        hashChunkNS.put("xmlns:" + prefix, nsuri);
                     } else {
                        hashNS.put("xmlns", nsuri);
                        hashChunkNS.put("xmlns", nsuri);
                     }

                     sbChunk.append("=");
                     sbChunk.append(nsuri);
                  }
               }

               count = reader.getAttributeCount();

               for(i = 0; i < count; ++i) {
                  tmpS = reader.getAttributeValue(i);
                  localname = reader.getAttributeLocalName(i);
                  prefix = reader.getAttributePrefix(i);
                  sbChunk.append(" " + ("".equals(prefix) ? localname : prefix + ":" + localname) + "=\"" + tmpS + "\"");
               }

               sbChunk.append(">");
               parseBuf.append(sbChunk.toString());
            case 3:
            case 5:
            case 6:
            default:
               break;
            case 4:
               tmpS = reader.getText();
               tmpS = tmpS.replace("&", "&#x26;").replace("\"", "&#x22;").replace("'", "&#x27;").replace("<", "&#x3C;").replace(">", "&#x3E;");
               tmpS = tmpS.replace("\r", "&#xD;").replace("\n", "&#xA;");
               parseBuf.append(tmpS);
               break;
            case 7:
               ret.encoding = reader.getEncoding();
               ret.version = reader.getVersion();
               break;
            case 8:
               isEndDoc = true;
               minChunkSize = 0;
            case 2:
               if (!isEndDoc) {
                  stackTag.pop();
                  prefix = reader.getPrefix();
                  localname = reader.getLocalName();
                  qnameS = (prefix == "" ? "" : prefix + ":") + localname;
                  retEndXml = "</" + qnameS + ">";
                  sbChunk.append(retEndXml);
                  if (stackChunkStartTag.empty()) {
                     stackChunkEndTag.push(qnameS);
                  } else {
                     stackChunkStartTag.pop();
                  }
               }

               parseBuf.append(sbChunk.toString());
               if (parseBuf.length() > minChunkSize) {
                  String startPrefixTags = "";
                  String endSuffixTags = "";
                  sbns.setLength(0);
                  Iterator iter = hashNS.keySet().iterator();

                  while(iter.hasNext()) {
                     tmpS = (String)iter.next();
                     if (!hashChunkNS.containsKey(tmpS)) {
                        sbns.append(" " + tmpS + "=" + (String)hashNS.get(tmpS));
                     }
                  }

                  boolean isStartPrefixTag = true;
                  int startPrefixTagCount = 0;
                  count = stackTag.size();

                  for(int i = 0; i < count; ++i) {
                     localname = (String)stackTag.get(i);
                     if (isStartPrefixTag && !stackChunkStartTag.empty() && localname.equals(stackChunkStartTag.get(0))) {
                        isStartPrefixTag = false;
                     }

                     if (isStartPrefixTag) {
                        if (i == 0) {
                           startPrefixTags = startPrefixTags + "<" + localname + sbns.toString() + ">";
                        } else {
                           startPrefixTags = startPrefixTags + "<" + localname + ">";
                        }

                        ++startPrefixTagCount;
                     }

                     endSuffixTags = "</" + localname + ">" + endSuffixTags;
                  }

                  for(boolean isFirstIteration = true; !stackChunkEndTag.empty(); ++startPrefixTagCount) {
                     localname = (String)stackChunkEndTag.pop();
                     if (isFirstIteration && "".equals(startPrefixTags)) {
                        startPrefixTags = startPrefixTags + "<" + localname + sbns.toString() + ">";
                     } else {
                        startPrefixTags = startPrefixTags + "<" + localname + ">";
                     }

                     isFirstIteration = false;
                  }

                  String modifiedval = startPrefixTags + parseBuf.toString() + endSuffixTags;
                  Document doc = docBuilderNSTrue.parse(new InputSource(new StringReader(modifiedval)));
                  String digestval = new String(canonicalizer.canonicalizeSubtree(doc));
                  if (endSuffixTags.length() > 0) {
                     digestval = digestval.substring(0, digestval.length() - endSuffixTags.length());
                  }

                  int pos = 0;

                  for(int i = 0; i < startPrefixTagCount; ++i) {
                     pos = digestval.indexOf(">", pos + 1);
                  }

                  if (pos > 0) {
                     digestval = digestval.substring(pos + 1);
                  }

                  this.logger.trace("digestval=" + digestval);
                  messageDigest.update(digestval.getBytes());
                  if (this.digestBuf != null) {
                     this.digestBuf.append(digestval);
                  }

                  parseBuf.setLength(0);
                  hashChunkNS.clear();
                  stackChunkStartTag.clear();
                  stackChunkEndTag.clear();
               }

               if (!isEndDoc) {
                  nscount = reader.getNamespaceCount();
                  if (nscount > 0) {
                     stackNS.pop();
                  }
               }
            }

            if (reader.hasNext()) {
               reader.next();
            }
         }

         reader.close();
         reader = null;
         messageDigest.update(digestSuffix);
         if (this.digestBuf != null) {
            this.digestBuf.append(new String(digestSuffix));
         }
      } finally {
         if (reader != null) {
            try {
               reader.close();
            } catch (Exception var47) {
            }
         }

      }

      ret.endXml = retEndXml;
      this.logger.debug("<-- calcCanonicalizedXmlMsgDigestByParsingDocChunk()");
      return ret;
   }

   protected FATCAXmlSigner.ParseXmlReturn calcCanonicalizedXmlMsgDigestByParsingDocNoChunk(String infile, MessageDigest messageDigest, FATCAXmlSigner.SigXmlTransform sigXmlTransform) throws Exception {
      this.logger.debug("--> calcCanonicalizedXmlMsgDigestByParsingDocNoChunk(). infile=" + infile + ", sigXmlTransform=" + sigXmlTransform);
      String retEndXml = null;
      StringBuilder parseBuf = new StringBuilder();
      XMLStreamReader reader = null;
      DocumentBuilder docBuilderNSTrue = null;
      FATCAXmlSigner.ParseXmlReturn ret = new FATCAXmlSigner.ParseXmlReturn((FATCAXmlSigner.ParseXmlReturn)null);

      try {
         DocumentBuilderFactory dbfNSTrue = DocumentBuilderFactory.newInstance();
         dbfNSTrue.setNamespaceAware(true);
         Canonicalizer canonicalizer = Canonicalizer.getInstance(this.getCanonicalizationMethod(sigXmlTransform));
         docBuilderNSTrue = dbfNSTrue.newDocumentBuilder();
         docBuilderNSTrue.setErrorHandler(new IgnoreAllErrorHandler());
         reader = XMLInputFactory.newFactory().createXMLStreamReader(new FileInputStream(new File(infile)));
         int nsCount = true;
         byte[][] sigRefIdPosTags = this.getSigRefIdPosTags();
         byte[] digestPrefix = sigRefIdPosTags[0];
         byte[] digestSuffix = sigRefIdPosTags[1];
         messageDigest.update(digestPrefix);
         if (this.digestBuf != null) {
            this.digestBuf.setLength(0);
            this.digestBuf.append(new String(digestPrefix));
         }

         for(; reader != null && reader.hasNext(); reader.next()) {
            parseBuf.setLength(0);
            String wrapperPrefix = null;
            String wrapperNSUri = null;
            String prefix;
            String localname;
            String qnameS;
            String tmpS;
            switch(reader.getEventType()) {
            case 1:
               prefix = reader.getPrefix();
               localname = reader.getLocalName();
               qnameS = (prefix == "" ? "" : prefix + ":") + localname;
               parseBuf.append('<');
               if (prefix != null && !"".equals(prefix)) {
                  wrapperPrefix = prefix;
                  parseBuf.append(prefix + ":");
               }

               parseBuf.append(localname);
               int nsCount = reader.getNamespaceCount();
               if (nsCount == 0) {
                  wrapperNSUri = reader.getNamespaceURI();
               }

               int i;
               for(i = 0; i < nsCount; ++i) {
                  prefix = reader.getNamespacePrefix(i);
                  String nsuri = reader.getNamespaceURI(i);
                  if (nsuri == null) {
                     nsuri = "";
                  }

                  parseBuf.append(" ");
                  parseBuf.append("xmlns");
                  if (prefix != null && !"".equals(prefix)) {
                     parseBuf.append(":");
                     parseBuf.append(prefix);
                  }

                  parseBuf.append("=\"");
                  parseBuf.append(nsuri);
                  parseBuf.append("\"");
               }

               int count = reader.getAttributeCount();

               for(i = 0; i < count; ++i) {
                  tmpS = reader.getAttributeValue(i);
                  localname = reader.getAttributeLocalName(i);
                  prefix = reader.getAttributePrefix(i);
                  parseBuf.append(" " + ("".equals(prefix) ? localname : prefix + ":" + localname) + "=\"" + tmpS + "\"");
               }

               parseBuf.append(">");
               this.processXmlFrag(0, qnameS, parseBuf.toString(), messageDigest, canonicalizer, docBuilderNSTrue, wrapperPrefix, wrapperNSUri);
               break;
            case 2:
               prefix = reader.getPrefix();
               localname = reader.getLocalName();
               qnameS = (prefix == "" ? "" : prefix + ":") + localname;
               parseBuf.append("</");
               if (prefix != null && !"".equals(prefix)) {
                  wrapperPrefix = prefix;
                  parseBuf.append(prefix + ":");
               }

               wrapperNSUri = reader.getNamespaceURI();
               parseBuf.append(localname);
               parseBuf.append('>');
               this.processXmlFrag(1, qnameS, parseBuf.toString(), messageDigest, canonicalizer, docBuilderNSTrue, wrapperPrefix, wrapperNSUri);
               retEndXml = parseBuf.toString();
            case 3:
            case 5:
            case 6:
            default:
               break;
            case 4:
               tmpS = reader.getText();
               tmpS = tmpS.replace("&", "&#x26;").replace("\"", "&#x22;").replace("'", "&#x27;").replace("<", "&#x3C;").replace(">", "&#x3E;");
               tmpS = tmpS.replace("\r", "&#xD;").replace("\n", "&#xA;");
               this.processXmlFrag(2, "", tmpS, messageDigest, canonicalizer, docBuilderNSTrue, (String)null, (String)null);
               break;
            case 7:
               ret.encoding = reader.getEncoding();
               ret.version = reader.getVersion();
            }
         }

         reader.close();
         reader = null;
         messageDigest.update(digestSuffix);
         if (this.digestBuf != null) {
            this.digestBuf.append(new String(digestSuffix));
         }
      } finally {
         if (reader != null) {
            try {
               reader.close();
            } catch (Exception var29) {
            }
         }

      }

      ret.endXml = retEndXml;
      this.logger.debug("<-- calcCanonicalizedXmlMsgDigestByParsingDocNoChunk()");
      return ret;
   }

   protected void calcXmlMsgDigestNoTransformation(String infile, MessageDigest messageDigest) throws Exception {
      this.logger.debug("--> calcXmlMsgDigestNoTransformation(). infile=" + infile);
      byte[][] sigRefIdPosTags = this.getSigRefIdPosTags();
      byte[] digestPrefix = sigRefIdPosTags[0];
      byte[] digestSuffix = sigRefIdPosTags[1];
      messageDigest.update(digestPrefix);
      if (this.digestBuf != null) {
         this.digestBuf.setLength(0);
         this.digestBuf.append(new String(digestPrefix));
      }

      BufferedInputStream bis = new BufferedInputStream(new FileInputStream(new File(infile)));
      boolean flag = true;

      int len;
      String tmp;
      for(byte[] tmpBuf = new byte[this.myThreadSafeData.getBufSize()]; (len = bis.read(tmpBuf)) != -1; messageDigest.update(tmp.getBytes())) {
         tmp = new String(tmpBuf, 0, len);
         if (flag) {
            flag = false;
            tmp = UtilShared.stripXmlHeader(tmp);
         }

         tmp = tmp.replace("\r", "");
         if (this.digestBuf != null) {
            this.digestBuf.append(tmp);
         }
      }

      bis.close();
      messageDigest.update(digestSuffix);
      if (this.digestBuf != null) {
         this.digestBuf.append(new String(digestSuffix));
      }

      this.logger.debug("<-- calcXmlMsgDigestNoTransformation()");
   }

   protected void calcTextMsgDigestNoTransformation(String infile, MessageDigest messageDigest) throws Exception {
      this.logger.debug("--> calcTextMsgDigestNoTransformation(). infile=" + infile);
      byte[][] sigRefIdPosTags = this.getSigRefIdPosTags();
      byte[] digestPrefix = sigRefIdPosTags[0];
      byte[] digestSuffix = sigRefIdPosTags[1];
      messageDigest.update(digestPrefix);
      if (this.digestBuf != null) {
         this.digestBuf.setLength(0);
         this.digestBuf.append(new String(digestPrefix));
      }

      BufferedInputStream bis = new BufferedInputStream(new FileInputStream(new File(infile)));

      int len;
      String tmp;
      for(byte[] tmpBuf = new byte[this.myThreadSafeData.getBufSize()]; (len = bis.read(tmpBuf)) != -1; messageDigest.update(tmp.getBytes())) {
         tmp = new String(tmpBuf, 0, len);
         tmp = tmp.replace("\r", "&#xD;");
         if (this.digestBuf != null) {
            this.digestBuf.append(tmp);
         }
      }

      bis.close();
      messageDigest.update(digestSuffix);
      if (this.digestBuf != null) {
         this.digestBuf.append(new String(digestSuffix));
      }

      this.logger.debug("<-- calcTextMsgDigestNoTransformation()");
   }

   protected Document createBlankSignedDOMDocForStreamingSignature(PrivateKey sigkey, X509Certificate sigPubCert, FATCAXmlSigner.SigDocType sigDocType, FATCAXmlSigner.SigXmlTransform sigXmlTransform) throws Exception {
      return this.createSignedDOMDoc((String)null, sigkey, sigPubCert, sigDocType, sigXmlTransform);
   }

   protected Document createSignedDOMDoc(String infile, PrivateKey sigkey, X509Certificate sigPubCert, FATCAXmlSigner.SigDocType sigDocType, FATCAXmlSigner.SigXmlTransform sigXmlTransform) throws Exception {
      this.logger.debug("--> createSignedDOMDoc(). infile=" + infile + ", sigDocType=" + sigDocType + ", sigXmlTransform=" + sigXmlTransform);
      BufferedInputStream bis = null;
      Document doc = null;
      XMLObject xmlobj = null;
      List<Transform> transforms = null;
      Node node = null;
      String tmp = null;

      try {
         DocumentBuilderFactory dbfNSTrue = DocumentBuilderFactory.newInstance();
         dbfNSTrue.setNamespaceAware(true);
         DocumentBuilder docBuilderNSTrue = dbfNSTrue.newDocumentBuilder();
         docBuilderNSTrue.setErrorHandler(new IgnoreAllErrorHandler());
         if (infile == null) {
            tmp = Base64.encode(UtilShared.genRandomId().getBytes());
            doc = docBuilderNSTrue.newDocument();
            node = doc.createTextNode(tmp);
         } else {
            switch($SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigDocType()[sigDocType.ordinal()]) {
            case 1:
            case 2:
               doc = docBuilderNSTrue.parse(new File(infile));
               node = doc.getDocumentElement();
               break;
            case 3:
               StringBuffer sb = new StringBuffer();
               bis = new BufferedInputStream(new FileInputStream(new File(infile)));
               byte[] buf = new byte[this.myThreadSafeData.getBufSize()];

               int len;
               while((len = bis.read(buf)) != -1) {
                  sb.append(new String(buf, 0, len));
               }

               bis.close();
               bis = null;
               doc = docBuilderNSTrue.newDocument();
               node = doc.createTextNode(sb.toString());
               break;
            case 4:
               ByteArrayOutputStream baos = new ByteArrayOutputStream();
               this.writeBase64BinaryAndOptionallyCalcMsgDigest(infile, "\n", baos, false, (MessageDigest)null);
               baos.close();
               doc = docBuilderNSTrue.newDocument();
               node = doc.createTextNode(baos.toString());
            }
         }

         XMLSignatureFactory xmlSigFactory;
         if (this.defaultSignatureFactoryProvider != null) {
            xmlSigFactory = XMLSignatureFactory.getInstance("DOM", this.defaultSignatureFactoryProvider);
         } else {
            xmlSigFactory = XMLSignatureFactory.getInstance();
         }

         if (sigDocType == FATCAXmlSigner.SigDocType.XML) {
            if (sigXmlTransform != FATCAXmlSigner.SigXmlTransform.None) {
               transforms = Collections.singletonList(xmlSigFactory.newTransform(this.getCanonicalizationMethod(sigXmlTransform), (TransformParameterSpec)null));
            }
         } else if (sigDocType == FATCAXmlSigner.SigDocType.BINARY) {
            transforms = Collections.singletonList(xmlSigFactory.newTransform("http://www.w3.org/2000/09/xmldsig#base64", (TransformParameterSpec)null));
         }

         XMLStructure content = new DOMStructure((Node)node);
         SignatureProperty sigProp;
         SignatureProperties sigProps;
         switch($SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigRefIdPos()[this.myThreadSafeData.getSigRefIdPos().ordinal()]) {
         case 1:
            xmlobj = xmlSigFactory.newXMLObject(Collections.singletonList(content), "FATCA", (String)null, (String)null);
            break;
         case 2:
            sigProp = xmlSigFactory.newSignatureProperty(Collections.singletonList(content), "#SignatureId", "FATCA");
            sigProps = xmlSigFactory.newSignatureProperties(Collections.singletonList(sigProp), (String)null);
            xmlobj = xmlSigFactory.newXMLObject(Collections.singletonList(sigProps), (String)null, (String)null, (String)null);
            break;
         case 3:
            sigProp = xmlSigFactory.newSignatureProperty(Collections.singletonList(content), "#SignatureId", (String)null);
            sigProps = xmlSigFactory.newSignatureProperties(Collections.singletonList(sigProp), "FATCA");
            xmlobj = xmlSigFactory.newXMLObject(Collections.singletonList(sigProps), (String)null, (String)null, (String)null);
         }

         List<XMLObject> xmlObjs = Collections.singletonList(xmlobj);
         Reference sigref = xmlSigFactory.newReference("#FATCA", xmlSigFactory.newDigestMethod("http://www.w3.org/2001/04/xmlenc#sha256", (DigestMethodParameterSpec)null), transforms, (String)null, (String)null);
         SignedInfo signedInfo = xmlSigFactory.newSignedInfo(xmlSigFactory.newCanonicalizationMethod("http://www.w3.org/TR/2001/REC-xml-c14n-20010315", (C14NMethodParameterSpec)null), xmlSigFactory.newSignatureMethod("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256", (SignatureMethodParameterSpec)null), Collections.singletonList(sigref));
         KeyInfo keyInfo = null;
         if (sigPubCert != null) {
            List<X509Certificate> list = new ArrayList();
            list.add(sigPubCert);
            KeyInfoFactory keyInfoFactory = xmlSigFactory.getKeyInfoFactory();
            X509Data kv = keyInfoFactory.newX509Data(list);
            keyInfo = keyInfoFactory.newKeyInfo(Collections.singletonList(kv));
         }

         XMLSignature signature = xmlSigFactory.newXMLSignature(signedInfo, keyInfo, xmlObjs, "SignatureId", (String)null);
         doc = docBuilderNSTrue.newDocument();
         DOMSignContext dsc = new DOMSignContext(sigkey, doc);
         String sigprefix = this.myThreadSafeData.getSignaturePrefix();
         if (sigprefix != null && !"".equals(sigprefix)) {
            dsc.setDefaultNamespacePrefix(sigprefix);
         }

         signature.sign(dsc);
      } finally {
         if (bis != null) {
            try {
               bis.close();
            } catch (Exception var31) {
            }
         }

      }

      this.logger.debug("<-- createSignedDOMDoc()");
      return doc;
   }

   protected int writeEncodedBinary(int lastlinelen, byte[] buf, String newline, OutputStream os) throws Exception {
      String encoded = Base64.encode(buf).replaceAll("\r", "").replaceAll("\n", "");
      int strlen = encoded.length();
      if (lastlinelen + strlen < 76) {
         os.write(encoded.getBytes());
         lastlinelen += strlen;
      } else {
         String tmpS = encoded.substring(0, 76 - lastlinelen);
         os.write(tmpS.getBytes());
         os.write(newline.getBytes());
         encoded = encoded.substring(tmpS.length());

         for(lastlinelen = 0; encoded.length() >= 76; encoded = encoded.substring(tmpS.length())) {
            tmpS = encoded.substring(0, 76 - lastlinelen);
            os.write(tmpS.getBytes());
            os.write(newline.getBytes());
         }

         if (encoded.length() > 0) {
            os.write(encoded.getBytes());
            lastlinelen = encoded.length();
         }
      }

      return lastlinelen;
   }

   protected boolean writeXmlFileObjectContent(String infile, OutputStream os, String endXml) throws Exception {
      this.logger.debug("--> writeXmlFileObjectContent(). infile=" + infile);
      boolean ret = false;
      BufferedInputStream bis = new BufferedInputStream(new FileInputStream(new File(infile)));
      boolean flag = true;
      byte[] tmpBuf = new byte[this.myThreadSafeData.getBufSize()];

      int len;
      while((len = bis.read(tmpBuf)) != -1) {
         String tmp = new String(tmpBuf, 0, len);
         if (flag) {
            flag = false;
            tmp = UtilShared.stripXmlHeader(tmp);
         }

         int pos;
         if (endXml != null && (pos = tmp.indexOf(endXml)) != -1) {
            tmp = tmp.substring(0, pos + endXml.length());
            os.write(tmp.getBytes());
            break;
         }

         os.write(tmp.getBytes());
      }

      bis.close();
      this.logger.debug("<-- writeXmlFileObjectContent()");
      return ret;
   }

   protected boolean writeTextFileObjectContent(String infile, OutputStream os) throws Exception {
      this.logger.debug("--> writeTextFileObjectContent(). infile=" + infile);
      boolean ret = false;
      BufferedInputStream bis = new BufferedInputStream(new FileInputStream(new File(infile)));
      byte[] tmpBuf = new byte[this.myThreadSafeData.getBufSize()];

      int len;
      while((len = bis.read(tmpBuf)) != -1) {
         String tmp = new String(tmpBuf, 0, len);
         tmp = tmp.replace("\r", "&#13;");
         tmp = tmp.replace("\n", "\r\n");
         os.write(tmp.getBytes());
      }

      bis.close();
      this.logger.debug("<-- writeTextFileObjectContent()");
      return ret;
   }

   protected boolean signFileStreaming(String infile, String outfile, PrivateKey sigkey, X509Certificate sigPubCert, FATCAXmlSigner.SigDocType sigDocType, FATCAXmlSigner.SigXmlTransform sigXmlTransform) throws Exception {
      this.logger.debug("--> signFileStreaming(). infile=" + infile + ", outfile=" + outfile + ", sigDocType=" + sigDocType + ", sigXmlTransform=" + sigXmlTransform);
      boolean ret = false;
      ByteArrayOutputStream baos = null;
      BufferedOutputStream bos = null;
      BufferedInputStream bis = null;
      String base64BinaryFile = null;

      try {
         label283: {
            MessageDigest messageDigest;
            if (this.defaultMessageDigestProvider != null) {
               messageDigest = MessageDigest.getInstance("SHA-256", this.defaultMessageDigestProvider);
            } else {
               messageDigest = MessageDigest.getInstance("SHA-256");
            }

            FATCAXmlSigner.ParseXmlReturn parseXmlRet = null;
            switch($SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigDocType()[sigDocType.ordinal()]) {
            case 1:
               this.logger.debug("parsing xml...." + new Date());
               if (this.myThreadSafeData.isXmlChunkStreaming()) {
                  this.logger.debug("parsing ----------------------- 1 ");
                  parseXmlRet = this.calcCanonicalizedXmlMsgDigestByParsingDocChunk(infile, messageDigest, sigXmlTransform);
               } else {
                  this.logger.debug("parsing ----------------------- 2 ");
                  parseXmlRet = this.calcCanonicalizedXmlMsgDigestByParsingDocNoChunk(infile, messageDigest, sigXmlTransform);
               }

               this.logger.debug("parsing xml....done. " + new Date());
               break;
            case 2:
               this.calcXmlMsgDigestNoTransformation(infile, messageDigest);
               break;
            case 3:
               this.calcTextMsgDigestNoTransformation(infile, messageDigest);
               break;
            case 4:
               base64BinaryFile = UtilShared.getTmpFileName(infile, "base64");
               bos = new BufferedOutputStream(new FileOutputStream(new File(base64BinaryFile)));
               this.writeBase64BinaryAndOptionallyCalcMsgDigest(infile, "\r\n", bos, true, messageDigest);
               bos.close();
               bos = null;
            }

            Document doc = this.createBlankSignedDOMDocForStreamingSignature(sigkey, sigPubCert, sigDocType, sigXmlTransform);
            NodeList nodeList = doc.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "DigestValue");
            if (nodeList.getLength() <= 0) {
               throw new Exception("Invalid document structure. Missing <DigestValue> content");
            }

            Node node = nodeList.item(0);
            node = node.getFirstChild();
            String signatureValue = Base64.encode(messageDigest.digest());
            this.logger.debug("DigestVal=" + signatureValue);
            node.setNodeValue(signatureValue);
            signatureValue = null;
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            nodeList = doc.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "SignedInfo");
            if (nodeList.getLength() > 0) {
               node = nodeList.item(0);
               baos = new ByteArrayOutputStream();
               Transformer trans = transformerFactory.newTransformer();
               trans.setOutputProperty("omit-xml-declaration", "yes");
               trans.transform(new DOMSource(node), new StreamResult(baos));
               baos.close();
               Canonicalizer canonicalizer = Canonicalizer.getInstance("http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
               Signature signature;
               if (this.defaultSignatureProvider != null) {
                  signature = Signature.getInstance("SHA256withRSA", this.defaultSignatureProvider);
               } else {
                  signature = Signature.getInstance("SHA256withRSA");
               }

               signature.initSign(sigkey);
               signature.update(canonicalizer.canonicalize(baos.toByteArray()));
               byte[] signatureBuf = signature.sign();
               signatureValue = Base64.encode(signatureBuf);
               baos = null;
               nodeList = doc.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "SignatureValue");
               if (nodeList.getLength() <= 0) {
                  throw new Exception("Invalid document structure. Missing <SignatureValue> content");
               }

               nodeList.item(0).getFirstChild().setNodeValue(signatureValue);
               canonicalizer = null;
               nodeList = doc.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "Object");
               if (nodeList.getLength() > 0) {
                  node = nodeList.item(0);
                  node = node.getFirstChild();
                  String textContent = node.getTextContent();
                  baos = new ByteArrayOutputStream();
                  trans = transformerFactory.newTransformer();
                  this.logger.debug("parsing ----------------------- encoding");
                  this.logger.debug("parsing ----------------------- " + parseXmlRet.encoding);
                  trans.setOutputProperty("encoding", parseXmlRet.encoding);
                  trans.setOutputProperty("version", parseXmlRet.version);
                  trans.transform(new DOMSource(doc), new StreamResult(baos));
                  baos.close();
                  String tmp = baos.toString();
                  baos = null;
                  int pos = tmp.indexOf(textContent);
                  if (pos == -1) {
                     throw new Exception("Invalid document structure or invalid transformation");
                  }

                  String prefix = tmp.substring(0, pos);
                  String suffix = tmp.substring(pos + textContent.length());
                  bos = new BufferedOutputStream(new FileOutputStream(new File(outfile)));
                  bos.write(prefix.getBytes());
                  switch($SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigDocType()[sigDocType.ordinal()]) {
                  case 1:
                  case 2:
                     this.writeXmlFileObjectContent(infile, bos, parseXmlRet.endXml);
                     break;
                  case 3:
                     this.writeTextFileObjectContent(infile, bos);
                     break;
                  case 4:
                     bis = new BufferedInputStream(new FileInputStream(new File(base64BinaryFile)));
                     byte[] buf = new byte[this.myThreadSafeData.getBufSize()];

                     int len;
                     while((len = bis.read(buf)) != -1) {
                        bos.write(buf, 0, len);
                     }

                     bis.close();
                     bis = null;
                  }

                  bos.write(suffix.getBytes());
                  bos.close();
                  bos = null;
                  ret = true;
                  break label283;
               }

               throw new Exception("Invalid document structure. Missing <Object> content");
            }

            throw new Exception("Invalid document structure. Missing <SignedInfo> content");
         }
      } finally {
         if (bos != null) {
            try {
               bos.close();
            } catch (Exception var43) {
            }
         }

         if (baos != null) {
            try {
               baos.close();
            } catch (Exception var42) {
            }
         }

         if (bis != null) {
            try {
               bis.close();
            } catch (Exception var41) {
            }
         }

         if (base64BinaryFile != null) {
            try {
               File f = new File(base64BinaryFile);
               if (f.exists() && !f.delete()) {
                  f.deleteOnExit();
               }
            } catch (Exception var40) {
            }
         }

      }

      if (this.isValidateAllSignature) {
         boolean flag = UtilShared.verifySignatureDOM(outfile, sigPubCert.getPublicKey());
         synchronized(this.isValidationSuccess) {
            this.isValidationSuccess = this.isValidationSuccess & flag;
         }
      }

      this.logger.debug("<-- signFileStreaming()");
      return ret;
   }

   protected boolean signFile(String infile, String outfile, PrivateKey sigkey, X509Certificate sigPubCert, FATCAXmlSigner.SigDocType sigDocType, FATCAXmlSigner.SigXmlTransform sigXmlTransform) throws Exception {
      this.logger.debug("--> signFile(). infile=" + infile + ", outfile=" + outfile + ", sigDocType=" + sigDocType + ", sigXmlTransform=" + sigXmlTransform);
      BufferedOutputStream bos = null;
      boolean ret = false;

      try {
         Document doc = this.createSignedDOMDoc(infile, sigkey, sigPubCert, sigDocType, sigXmlTransform);
         NodeList nodeList = doc.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "DigestValue");
         if (nodeList.getLength() > 0) {
            this.logger.debug("DigestValue=" + nodeList.item(0).getFirstChild().getNodeValue());
         }

         bos = new BufferedOutputStream(new FileOutputStream(new File(outfile)));
         Transformer transformer = TransformerFactory.newInstance().newTransformer();
         transformer.transform(new DOMSource(doc), new StreamResult(bos));
         ret = true;
      } finally {
         if (bos != null) {
            try {
               bos.close();
            } catch (Exception var18) {
            }
         }

      }

      if (this.isValidateAllSignature) {
         boolean flag = UtilShared.verifySignatureDOM(outfile, sigPubCert.getPublicKey());
         synchronized(this.isValidationSuccess) {
            this.isValidationSuccess = this.isValidationSuccess & flag;
         }
      }

      this.logger.debug("<-- signFile()");
      return ret;
   }

   protected boolean wrapBinaryFileInXmlAndSign(String infile, String outfile, PrivateKey sigkey, X509Certificate sigPubCert, boolean isDOM) throws Exception {
      this.logger.debug("--> wrapBinaryFileInXmlAndSign(). infile=" + infile + ", outfile=" + outfile + ", isDOM=" + isDOM);
      boolean flag = false;
      String wrappedBase64BinaryFile = UtilShared.getTmpFileName(infile, "wrapped.base64.xml");
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(new File(wrappedBase64BinaryFile)));
      byte[][] tags = this.getWrapperTags();
      bos.write(tags[0]);
      this.writeBase64BinaryAndOptionallyCalcMsgDigest(infile, "\r\n", bos, false, (MessageDigest)null);
      bos.write(tags[1]);
      bos.close();
      if (isDOM) {
         flag = this.signFile(wrappedBase64BinaryFile, outfile, sigkey, sigPubCert, FATCAXmlSigner.SigDocType.WRAPPEDXML, FATCAXmlSigner.SigXmlTransform.None);
      } else {
         flag = this.signFileStreaming(wrappedBase64BinaryFile, outfile, sigkey, sigPubCert, FATCAXmlSigner.SigDocType.WRAPPEDXML, FATCAXmlSigner.SigXmlTransform.None);
      }

      File f = new File(wrappedBase64BinaryFile);
      if (f.exists() && !f.delete()) {
         f.deleteOnExit();
      }

      this.logger.debug("<-- wrapBinaryFileInXmlAndSign()");
      return flag;
   }

   protected boolean wrapTextFileInXmlAndSign(String infile, String outfile, PrivateKey sigkey, X509Certificate sigPubCert, boolean isDOM) throws Exception {
      this.logger.debug("--> wrapTextFileInXmlAndSign(). infile=" + infile + ", outfile=" + outfile + ", isDOM=" + isDOM);
      boolean flag = false;
      byte[] tmpBuf = new byte[this.myThreadSafeData.getBufSize()];
      String wrappedTextFile = UtilShared.getTmpFileName(infile, "wrapped.txt.xml");
      BufferedInputStream bis = new BufferedInputStream(new FileInputStream(new File(infile)));
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(new File(wrappedTextFile)));
      byte[][] tags = this.getWrapperTags();
      bos.write(tags[0]);

      int len;
      while((len = bis.read(tmpBuf)) != -1) {
         bos.write(tmpBuf, 0, len);
      }

      bis.close();
      bos.write(tags[1]);
      bos.close();
      if (isDOM) {
         flag = this.signFile(wrappedTextFile, outfile, sigkey, sigPubCert, FATCAXmlSigner.SigDocType.WRAPPEDXML, FATCAXmlSigner.SigXmlTransform.None);
      } else {
         flag = this.signFileStreaming(wrappedTextFile, outfile, sigkey, sigPubCert, FATCAXmlSigner.SigDocType.WRAPPEDXML, FATCAXmlSigner.SigXmlTransform.None);
      }

      File f = new File(wrappedTextFile);
      if (f.exists() && !f.delete()) {
         f.deleteOnExit();
      }

      this.logger.debug("<-- wrapTextFileInXmlAndSign()");
      return flag;
   }

   protected boolean signFileNoWrap(String infile, String outfile, PrivateKey sigkey, X509Certificate sugPubCert, boolean isDom, FATCAXmlSigner.SigDocType sigDocType) throws Exception {
      return this.signFileNoWrap(infile, outfile, sigkey, sugPubCert, isDom, sigDocType, this.myThreadSafeData.getSigXmlTransform());
   }

   protected boolean signFileNoWrap(String infile, String outfile, PrivateKey sigkey, X509Certificate sugPubCert, boolean isDom, FATCAXmlSigner.SigDocType sigDocType, FATCAXmlSigner.SigXmlTransform sigXmlTransform) throws Exception {
      this.logger.debug("--> signFileNoWrap(). infile=" + infile + ", outfile=" + outfile + ", isDom=" + isDom + ", sigDocType=" + sigDocType + ", sigXmlTransform=" + sigXmlTransform);
      boolean flag = false;
      if (isDom) {
         flag = this.signFile(infile, outfile, sigkey, sugPubCert, sigDocType, sigXmlTransform);
      } else {
         flag = this.signFileStreaming(infile, outfile, sigkey, sugPubCert, sigDocType, sigXmlTransform);
      }

      this.logger.debug("<-- signFileNoWrap()");
      return flag;
   }

   public String getSignaturePrefix() {
      return this.myThreadSafeData.getSignaturePrefix();
   }

   public void setSignaturePrefix(String prefix) {
      this.myThreadSafeData.setSignaturePrefix(prefix);
   }

   public String getWrapperXsiSchemaLoc() {
      return this.myThreadSafeData.getWrapperXsiSchemaLoc();
   }

   public void setWrapperXsiSchemaLoc(String val) {
      this.myThreadSafeData.setWrapperXsiSchemaLoc(val);
   }

   public boolean isWrapperXsiSchemaLoc() {
      return this.myThreadSafeData.isWrapperXsiSchemaLoc();
   }

   public void setWrapperXsiSchemaLoc(boolean val) {
      this.myThreadSafeData.setWrapperXsiSchemaLoc(val);
   }

   public boolean isWrapperXsi() {
      return this.myThreadSafeData.isWrapperXsi();
   }

   public void setWrapperXsi(boolean val) {
      this.myThreadSafeData.setWrapperXsi(val);
   }

   public String getWrapperPrefix() {
      return this.myThreadSafeData.getWrapperPrefix();
   }

   public void setWrapperPrefix(String prefix) {
      this.myThreadSafeData.setWrapperPrefix(prefix);
   }

   public String getWrapperNS() {
      return this.myThreadSafeData.getWrapperNS();
   }

   public void setWrapperNS(String ns) {
      this.myThreadSafeData.setWrapperNS(ns);
   }

   public void setBufSize(int val) {
      this.myThreadSafeData.setBufSize(val);
   }

   public boolean signXmlFileStreaming(String infile, String outfile, PrivateKey sigkey, X509Certificate sugPubCert) throws Exception {
      boolean isDom = false;
      return this.signFileNoWrap(infile, outfile, sigkey, sugPubCert, isDom, FATCAXmlSigner.SigDocType.XML, this.myThreadSafeData.getSigXmlTransform());
   }

   public boolean wrapBinaryFileInXmlAndSignStreaming(String infile, String outfile, PrivateKey sigkey, X509Certificate sugPubCert) throws Exception {
      boolean isDom = false;
      return this.wrapBinaryFileInXmlAndSign(infile, outfile, sigkey, sugPubCert, isDom);
   }

   public boolean wrapTextFileInXmlAndSignStreaming(String infile, String outfile, PrivateKey sigkey, X509Certificate sugPubCert) throws Exception {
      boolean isDom = false;
      return this.wrapTextFileInXmlAndSign(infile, outfile, sigkey, sugPubCert, isDom);
   }

   public boolean signXmlFile(String infile, String outfile, PrivateKey sigkey, X509Certificate sugPubCert) throws Exception {
      return this.signFileNoWrap(infile, outfile, sigkey, sugPubCert, true, FATCAXmlSigner.SigDocType.XML);
   }

   public boolean wrapTextFileInXmlAndSign(String infile, String outfile, PrivateKey sigkey, X509Certificate sugPubCert) throws Exception {
      boolean isDom = true;
      return this.wrapTextFileInXmlAndSign(infile, outfile, sigkey, sugPubCert, isDom);
   }

   public boolean wrapBinaryFileInXmlAndSign(String infile, String outfile, PrivateKey sigkey, X509Certificate sugPubCert) throws Exception {
      boolean isDom = true;
      return this.wrapBinaryFileInXmlAndSign(infile, outfile, sigkey, sugPubCert, isDom);
   }

   public String getSigRefIdPos() {
      FATCAXmlSigner.SigRefIdPos sigRefIdPos = this.myThreadSafeData.getSigRefIdPos();
      switch($SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigRefIdPos()[sigRefIdPos.ordinal()]) {
      case 1:
         return "Object";
      case 2:
         return "SignatureProperty";
      case 3:
         return "SignatureProperties";
      default:
         return null;
      }
   }

   public void setSigRefIdPos(String sigRefIdPos) throws Exception {
      if ("Object".equalsIgnoreCase(sigRefIdPos)) {
         this.myThreadSafeData.setSigRefIdPos(FATCAXmlSigner.SigRefIdPos.Object);
      } else if ("SignatureProperty".equalsIgnoreCase(sigRefIdPos)) {
         this.myThreadSafeData.setSigRefIdPos(FATCAXmlSigner.SigRefIdPos.SignatureProperty);
      } else {
         if (!"SignatureProperties".equalsIgnoreCase(sigRefIdPos)) {
            throw new Exception("invalid sigRefIdPos=" + sigRefIdPos + ". Valid values are Object|SignatureProperty|SignatureProperties");
         }

         this.myThreadSafeData.setSigRefIdPos(FATCAXmlSigner.SigRefIdPos.SignatureProperties);
      }

   }

   public String getSigXmlTransform() {
      FATCAXmlSigner.SigXmlTransform sigXmlTransform = this.myThreadSafeData.getSigXmlTransform();
      switch($SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigXmlTransform()[sigXmlTransform.ordinal()]) {
      case 1:
         return "Inclusive";
      case 2:
         return "InclusiveWithComments";
      case 3:
         return "Exclusive";
      case 4:
         return "ExclusiveWithComments";
      case 5:
         return "None";
      default:
         return null;
      }
   }

   public void setSigXmlTransform(String sigXmlTransform) throws Exception {
      if ("Inclusive".equalsIgnoreCase(sigXmlTransform)) {
         this.myThreadSafeData.setSigXmlTransform(FATCAXmlSigner.SigXmlTransform.Inclusive);
      } else if ("InclusiveWithComments".equalsIgnoreCase(sigXmlTransform)) {
         this.myThreadSafeData.setSigXmlTransform(FATCAXmlSigner.SigXmlTransform.InclusiveWithComments);
      } else if ("Exclusive".equalsIgnoreCase(sigXmlTransform)) {
         this.myThreadSafeData.setSigXmlTransform(FATCAXmlSigner.SigXmlTransform.Exclusive);
      } else if ("ExclusiveWithComments".equalsIgnoreCase(sigXmlTransform)) {
         this.myThreadSafeData.setSigXmlTransform(FATCAXmlSigner.SigXmlTransform.ExclusiveWithComments);
      } else {
         if (!"None".equalsIgnoreCase(sigXmlTransform)) {
            throw new Exception("invalid sigXmlTransform=" + sigXmlTransform + ". Valid values are Inclusive|InclusiveWithComments|Exclusive|ExclusiveWithComments|None");
         }

         this.myThreadSafeData.setSigXmlTransform(FATCAXmlSigner.SigXmlTransform.None);
      }

   }

   public void setXmlChunkStreaming(boolean val) {
      this.myThreadSafeData.setXmlChunkStreaming(val);
   }

   public boolean isXmlChunkStreaming() {
      return this.myThreadSafeData.isXmlChunkStreaming();
   }

   public int getXmlChunkStreamingSize() {
      return this.myThreadSafeData.getXmlChunkStreamingSize();
   }

   public void setXmlChunkStreamingSize(int val) {
      this.myThreadSafeData.setXmlChunkStreamingSize(val);
   }

   public StringBuilder getDigestBuf() {
      return this.digestBuf;
   }

   public void setDigestBuf(StringBuilder digestBuf) {
      this.digestBuf = digestBuf;
   }

   public boolean isValidateAllSignature() {
      return this.isValidateAllSignature;
   }

   public void setValidateAllSignature(boolean isValidateAllSignature) {
      this.isValidateAllSignature = isValidateAllSignature;
   }

   public Boolean isValidationSuccess() {
      return this.isValidationSuccess;
   }

   public void setValidationSuccess(Boolean isValidationSuccess) {
      this.isValidationSuccess = isValidationSuccess;
   }

   public boolean signTextFile(String infile, String outfile, PrivateKey sigkey, X509Certificate sugPubCert) throws Exception {
      return this.signFileNoWrap(infile, outfile, sigkey, sugPubCert, true, FATCAXmlSigner.SigDocType.TEXT, FATCAXmlSigner.SigXmlTransform.None);
   }

   public boolean signBinaryFile(String infile, String outfile, PrivateKey sigkey, X509Certificate sugPubCert) throws Exception {
      return this.signFileNoWrap(infile, outfile, sigkey, sugPubCert, true, FATCAXmlSigner.SigDocType.BINARY, FATCAXmlSigner.SigXmlTransform.None);
   }

   public boolean signTextFileStreaming(String infile, String outfile, PrivateKey sigkey, X509Certificate sugPubCert) throws Exception {
      boolean isDom = false;
      return this.signFileNoWrap(infile, outfile, sigkey, sugPubCert, isDom, FATCAXmlSigner.SigDocType.TEXT, FATCAXmlSigner.SigXmlTransform.None);
   }

   public boolean signBinaryFileStreaming(String infile, String outfile, PrivateKey sigkey, X509Certificate sugPubCert) throws Exception {
      boolean isDom = false;
      return this.signFileNoWrap(infile, outfile, sigkey, sugPubCert, isDom, FATCAXmlSigner.SigDocType.BINARY, FATCAXmlSigner.SigXmlTransform.None);
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigXmlTransform() {
      int[] var10000 = $SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigXmlTransform;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[FATCAXmlSigner.SigXmlTransform.values().length];

         try {
            var0[FATCAXmlSigner.SigXmlTransform.Exclusive.ordinal()] = 3;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[FATCAXmlSigner.SigXmlTransform.ExclusiveWithComments.ordinal()] = 4;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[FATCAXmlSigner.SigXmlTransform.Inclusive.ordinal()] = 1;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[FATCAXmlSigner.SigXmlTransform.InclusiveWithComments.ordinal()] = 2;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[FATCAXmlSigner.SigXmlTransform.None.ordinal()] = 5;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigXmlTransform = var0;
         return var0;
      }
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigRefIdPos() {
      int[] var10000 = $SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigRefIdPos;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[FATCAXmlSigner.SigRefIdPos.values().length];

         try {
            var0[FATCAXmlSigner.SigRefIdPos.Object.ordinal()] = 1;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[FATCAXmlSigner.SigRefIdPos.SignatureProperties.ordinal()] = 3;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[FATCAXmlSigner.SigRefIdPos.SignatureProperty.ordinal()] = 2;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigRefIdPos = var0;
         return var0;
      }
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigDocType() {
      int[] var10000 = $SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigDocType;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[FATCAXmlSigner.SigDocType.values().length];

         try {
            var0[FATCAXmlSigner.SigDocType.BINARY.ordinal()] = 4;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[FATCAXmlSigner.SigDocType.TEXT.ordinal()] = 3;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[FATCAXmlSigner.SigDocType.WRAPPEDXML.ordinal()] = 2;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[FATCAXmlSigner.SigDocType.XML.ordinal()] = 1;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$fatca$impl$FATCAXmlSigner$SigDocType = var0;
         return var0;
      }
   }

   private class MyThreadSafeData {
      private String signaturePrefix;
      private String wrapperPrefix;
      private String wrapperNS;
      private String wrapperXsi;
      private String wrapperXsiSchemaLoc;
      private Boolean useWrapperXsi;
      private Boolean useWrapperXsiSchemaLoc;
      private Boolean useXmlChunkStreaming;
      private Integer bufSize;
      private Integer xmlChunkStreamingSize;
      private FATCAXmlSigner.SigRefIdPos sigRefIdPos;
      private FATCAXmlSigner.SigXmlTransform sigXmlTransform;
      private final String genericLock;
      private final String sigElemLock;
      private final String wrapperLock;

      private MyThreadSafeData() {
         this.signaturePrefix = "";
         this.wrapperPrefix = "";
         this.wrapperNS = "urn:xmpp:xml-element";
         this.wrapperXsi = "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"";
         this.wrapperXsiSchemaLoc = "xsi:schemaLocation=\"urn:xmpp:xml-element FATCA-IDES-FileWrapper-1.1.xsd\"";
         this.useWrapperXsi = false;
         this.useWrapperXsiSchemaLoc = false;
         this.useXmlChunkStreaming = true;
         this.bufSize = FATCAXmlSigner.this.defaultBufSize;
         this.xmlChunkStreamingSize = FATCAXmlSigner.this.defaultChunkStreamingSize;
         this.sigRefIdPos = FATCAXmlSigner.SigRefIdPos.Object;
         this.sigXmlTransform = FATCAXmlSigner.SigXmlTransform.Inclusive;
         this.genericLock = "genericLock";
         this.sigElemLock = "sigElemLock";
         this.wrapperLock = "wrapperLock";
      }

      public FATCAXmlSigner.SigRefIdPos getSigRefIdPos() {
         String var1 = "sigElemLock";
         synchronized("sigElemLock") {
            return this.sigRefIdPos;
         }
      }

      public void setSigRefIdPos(FATCAXmlSigner.SigRefIdPos sigRefIdPos) {
         String var2 = "sigElemLock";
         synchronized("sigElemLock") {
            this.sigRefIdPos = sigRefIdPos;
         }
      }

      public FATCAXmlSigner.SigXmlTransform getSigXmlTransform() {
         String var1 = "sigElemLock";
         synchronized("sigElemLock") {
            return this.sigXmlTransform;
         }
      }

      public void setSigXmlTransform(FATCAXmlSigner.SigXmlTransform sigXmlTransform) {
         String var2 = "sigElemLock";
         synchronized("sigElemLock") {
            this.sigXmlTransform = sigXmlTransform;
         }
      }

      public int getXmlChunkStreamingSize() {
         String var1 = "genericLock";
         synchronized("genericLock") {
            return this.xmlChunkStreamingSize;
         }
      }

      public void setXmlChunkStreamingSize(int val) {
         String var2 = "genericLock";
         synchronized("genericLock") {
            this.xmlChunkStreamingSize = val;
         }
      }

      public int getBufSize() {
         String var1 = "genericLock";
         synchronized("genericLock") {
            return this.bufSize;
         }
      }

      public void setBufSize(int val) {
         String var2 = "genericLock";
         synchronized("genericLock") {
            this.bufSize = val;
         }
      }

      protected boolean isXmlChunkStreaming() {
         String var1 = "genericLock";
         synchronized("genericLock") {
            return this.useXmlChunkStreaming;
         }
      }

      protected void setXmlChunkStreaming(boolean val) {
         String var2 = "genericLock";
         synchronized("genericLock") {
            this.useXmlChunkStreaming = val;
         }
      }

      protected void setSignaturePrefix(String prefix) {
         String var2 = "genericLock";
         synchronized("genericLock") {
            if (prefix == null) {
               this.signaturePrefix = "";
            } else {
               this.signaturePrefix = prefix;
            }

         }
      }

      protected String getSignaturePrefix() {
         String var1 = "genericLock";
         synchronized("genericLock") {
            return this.signaturePrefix;
         }
      }

      protected String getWrapperPrefix() {
         String var1 = "wrapperLock";
         synchronized("wrapperLock") {
            return this.wrapperPrefix;
         }
      }

      protected String getWrapperNS() {
         String var1 = "wrapperLock";
         synchronized("wrapperLock") {
            return this.wrapperNS;
         }
      }

      protected String getWrapperXsi() {
         String var1 = "wrapperLock";
         synchronized("wrapperLock") {
            return this.wrapperXsi;
         }
      }

      protected String getWrapperXsiSchemaLoc() {
         String var1 = "wrapperLock";
         synchronized("wrapperLock") {
            return this.wrapperXsiSchemaLoc;
         }
      }

      protected boolean isWrapperXsiSchemaLoc() {
         String var1 = "wrapperLock";
         synchronized("wrapperLock") {
            return this.useWrapperXsiSchemaLoc;
         }
      }

      protected boolean isWrapperXsi() {
         String var1 = "wrapperLock";
         synchronized("wrapperLock") {
            return this.useWrapperXsi;
         }
      }

      protected void setWrapperXsiSchemaLoc(String val) {
         String var2 = "wrapperLock";
         synchronized("wrapperLock") {
            this.wrapperXsiSchemaLoc = "xsi:schemaLocation=\"" + val + "\"";
         }
      }

      protected void setWrapperXsiSchemaLoc(boolean val) {
         String var2 = "wrapperLock";
         synchronized("wrapperLock") {
            this.useWrapperXsiSchemaLoc = val;
         }
      }

      protected void setWrapperXsi(boolean val) {
         String var2 = "wrapperLock";
         synchronized("wrapperLock") {
            this.useWrapperXsi = val;
         }
      }

      protected void setWrapperPrefix(String prefix) {
         String var2 = "wrapperLock";
         synchronized("wrapperLock") {
            if (prefix == null) {
               this.wrapperPrefix = "";
            } else {
               this.wrapperPrefix = prefix;
            }

         }
      }

      protected void setWrapperNS(String ns) {
         String var2 = "wrapperLock";
         synchronized("wrapperLock") {
            if (ns == null) {
               this.wrapperNS = "";
            } else {
               this.wrapperNS = ns;
            }

         }
      }

      // $FF: synthetic method
      MyThreadSafeData(FATCAXmlSigner.MyThreadSafeData var2) {
         this();
      }
   }

   private class ParseXmlReturn {
      public String encoding;
      public String version;
      public String endXml;

      private ParseXmlReturn() {
         this.encoding = "UTF-8";
         this.version = "1.0";
         this.endXml = null;
      }

      // $FF: synthetic method
      ParseXmlReturn(FATCAXmlSigner.ParseXmlReturn var2) {
         this();
      }
   }

   public static enum SigDocType {
      XML,
      WRAPPEDXML,
      TEXT,
      BINARY;
   }

   public static enum SigRefIdPos {
      Object,
      SignatureProperty,
      SignatureProperties;
   }

   public static enum SigXmlTransform {
      Inclusive,
      InclusiveWithComments,
      Exclusive,
      ExclusiveWithComments,
      None;
   }
}
