/** @type {import('next').NextConfig} */

const nextConfig = {
  reactStrictMode: false,
  output: 'export',
  // env: require('./public/config/config.json'),
  // async rewrites() {
  //   return [
  //     {
  //       source: '/fatca-api/:path*',
  //       destination: (process.env.NODE_ENV === 'production' ? process.env.NEXT_PUBLIC_ENDPOINT_API : 'https://fatca-dev.se.scb.co.th') + '/fatca-api/:path*',
  //     },
  //   ]
  // },
};

module.exports = nextConfig;
