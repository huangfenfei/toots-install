import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { PublicClientApplication, Configuration } from '@azure/msal-browser';
import { MsalProvider } from '@azure/msal-react';

interface AuthContextType {
    msalInstance: PublicClientApplication | null;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [msalInstance, setMsalInstance] = useState<PublicClientApplication | null>(null);

    useEffect(() => {
        const fetchConfig = async () => {
            const response = await fetch('/config/authConifg.json');
            const resJson = await response.json();
            console.log("AuthProvider.resJson ==>", resJson);
            const config: Configuration = resJson;
            const instance = new PublicClientApplication(config);
            setMsalInstance(instance);
        };

        fetchConfig();
    }, []);

    if (!msalInstance) return <div>Loading...</div>;

    return (
        <AuthContext.Provider value={{ msalInstance }}>
            <MsalProvider instance={msalInstance}>{children}</MsalProvider>
        </AuthContext.Provider>
    );
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};