import axios, { AxiosRequestConfig } from "axios";
import { getTokenStorage } from "../../storages/tokenStorage";

export const saveJuristic = async (body: any): Promise<any> => {
    try {
        // const config = {
        //     headers: {
        //         Authorization: "Bearer " + getTokenStorage()
        //     }
        // } as AxiosRequestConfig;
        // const res = await axios.post<any>("/fatca-api/fatcacrs/v1/addJuristic", body, config);
        console.log("saveJuristic.body ==>", body);
        const res = {
            respCode: "0000",
            respDesc: "success",
        }
        return res;
    } catch (error) {
        console.error(error)
    }
}

export const updateJuristic = async (body: any): Promise<any> => {
    try {
        const config = {
            headers: {
                Authorization: "Bearer " + getTokenStorage()
            }
        } as AxiosRequestConfig;
        const res = await axios.post<any>("/fatca-api/fatcacrs/v1/updateJuristic", body, config);
        return res?.data;
    } catch (error) {
        console.error(error)
    }
}
