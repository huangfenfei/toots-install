import axios, { AxiosRequestConfig } from "axios";
import { getTokenStorage } from "../../storages/tokenStorage";

export const saveIndivedual = async (body: any): Promise<any> => {
    try {
        // const config = {
        //     headers: {
        //         Authorization: "Bearer " + getTokenStorage()
        //     }
        // } as AxiosRequestConfig;
        // const res = await axios.post<any>("/fatca-api/fatcacrs/v1/addIndividual", body, config);
        // return res?.data;
        console.log("saveJuristic.body ==>", body);
        const res = {
            respCode: "0000",
            respDesc: "success",
        }
        return res;
    } catch (error) {
        console.error(error)
    }
}

export const updateIndivedual = async (body: any): Promise<any> => {
    try {
        const config = {
            headers: {
                Authorization: "Bearer " + getTokenStorage()
            }
        } as AxiosRequestConfig;
        const res = await axios.post<any>("/fatca-api/fatcacrs/v1/updateIndividual", body, config);
        return res?.data;
    } catch (error) {
        console.error(error)
    }
}

export const deleteIndivedual = async (body: any): Promise<any> => {
    try {
        const config = {
            headers: {
                Authorization: "Bearer " + getTokenStorage()
            }
        } as AxiosRequestConfig;
        const res = await axios.post<any>("/fatca-api/fatcacrs/v1/deleteFATCACRS", body, config);
        return res?.data;
    } catch (error) {
        console.error(error)
    }
}