import axios, { AxiosRequestConfig } from "axios";
import { ResonseBodyType } from "../../interface/masterType";
import ResonseBodyBranchType from "../../interface/branchType";
import { getTokenStorage } from "../../storages/tokenStorage";

export const fetchMasterData = async (): Promise<ResonseBodyType> => {
    try {
        const res = await axios.post<ResonseBodyType>("/fatca-api/master/v1/getIntData", null);
        return res?.data;
    } catch (error) {
        console.error(error);
    }
}

export const fetchAllBranch = async (token: string): Promise<ResonseBodyBranchType> => {
    try {
        // const config = {
        //     headers: {
        //         Authorization: "Bearer " + getTokenStorage()
        //     }
        // } as AxiosRequestConfig;

        // const res = await axios.post<ResonseBodyBranchType>("/fatca-api/master/v1/getAllBranch", null, config);
        const response = await fetch('/datas/all-branch.json');
        const resJson = await response.json();
        return resJson;
    } catch (error) {
        console.error(error);
    }
}