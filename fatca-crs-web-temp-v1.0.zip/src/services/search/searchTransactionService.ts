import axios, { AxiosRequestConfig } from "axios";
import { ResonseBodyType } from "../../interface/searchType";
import { getTokenStorage } from "../../storages/tokenStorage";

export const fetchSearchTransaction = async (body: any): Promise<ResonseBodyType> => {
    try {
        const config = {
            headers: {
                Authorization: "Bearer " + getTokenStorage()
            }
        } as AxiosRequestConfig;
        //const res = await axios.post("/fatca-api/report/v1/searchByTran", body, config);
        //console.log(body);
        const res = await axios.post<ResonseBodyType>("/fatca-api/report/v1/searchByTran", body, config);
        console.log(res?.status);
        return res?.data;

        /*const res = '{"respCode":"0000","respDesc":"success","body":{"currentPage":"1","totalPage":"1","totalRecord":"2","isLastPage":"Yes","custList":[{"idNum":"111111111111","idType":"เลขที่บัตรประชาชน","customerName":"นางสาวทดสอบ1 ทดสอบ1","lastUpdateDate":"2024-04-22","customerType":"-","fatcaStatus":"Indicia","IRSDoc":"W8-BEN","docSupport":"บัตรประชาชนไทย","transactionStatus":"บัตรประชาชน","userEntry":"OBJU","branch":"0111","sendDocDate":"2024-04-22","HOReceiveDate":"-","HORemark":"Mockup"},{"idNum":"2222222222222","idType":"เลขที่บัตรประชาชน","customerName":"นางสาวทดสอบ2 ทดสอบ2","lastUpdateDate":"2024-04-22","customerType":"-","fatcaStatus":"Indicia","IRSDoc":"W8-BEN","docSupport":"บัตรประชาชนไทย","transactionStatus":"บัตรประชาชน","userEntry":"OBJU","branch":"0111","sendDocDate":"2024-04-22","HOReceiveDate":"-","HORemark":"Mockup2"}]}}';
        const cus: ResonseBodyType = JSON.parse(res);
        console.log("Customer:"+cus);
        return cus;*/
    } catch (error) {
        console.log(error);

    }
}