import axios, { AxiosRequestConfig } from "axios";
import { ResonseBodyType } from "../../interface/searchType";
import { getTokenStorage } from "../../storages/tokenStorage";

export const fetchSearchCustomer = async (body: any): Promise<ResonseBodyType> => {
    try {
        const config = {
            headers: {
                Authorization: "Bearer " + getTokenStorage()
            }
        } as AxiosRequestConfig;
        const res = await axios.post<ResonseBodyType>("/fatca-api/report/v1/searchByCust", body, config);
        return res?.data;
    } catch (error) {

    }
}