import axios, { AxiosRequestConfig } from "axios";
import { graphConfig } from "../../configs/authConfig";
import { ResonseBodyType } from "../../interface/masterType";
import { getAccessTokenStorage } from "../../storages/accessTokenStorage";

export const loginWithAzureAD = async (): Promise<[ResonseBodyType, string]> => {
    try {
        // const config = {
        //     headers: {
        //         Authorization: "Bearer " + token
        //     }
        // } as AxiosRequestConfig;

        // const res = await axios.post<ResonseBodyType>(`/fatca-api/authorization/v1/init`, {}, config);
        const response = await fetch('/datas/master.json');
        const resJson = await response.json();
        return [resJson, null]
    } catch (error) {
        console.error(error);
    }
}

export const logoutWithAzureAD = async () => {
    const accessToken = getAccessTokenStorage();
    try {
        const config = {
            headers: {
                Authorization: "Bearer " + accessToken
            }
        } as AxiosRequestConfig;
        const res = await axios.post(`/fatca-api/authorization/v1/logout`, null, config);
        return Promise.resolve(res.data);
    } catch (error) {
        console.error(error);
    }
}

export const callMsGraph = async (accessToken: string) => {
    const headers = new Headers();
    const bearer = `Bearer ${accessToken}`;

    headers.append("Authorization", bearer);

    const options = {
        method: "GET",
        headers: headers
    };

    return await fetch(graphConfig.graphMeEndpoint, options)
        .then(response => response.json())
        .catch(error => console.log(error));
}