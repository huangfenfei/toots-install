import { createSlice } from "@reduxjs/toolkit";
import { DropdownType } from "../../interface/masterType";

const initialState: DropdownType[] = [];
const CrsCountrySlice = createSlice({
    name: "crsCountry",
    initialState: initialState,
    reducers: {
        crsCountryReducer: (state, action) => {
            state = state.concat(action.payload);
            return state;
        },
    },
});

export const { crsCountryReducer } = CrsCountrySlice.actions;
export default CrsCountrySlice.reducer;
