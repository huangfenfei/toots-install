import { createSlice } from "@reduxjs/toolkit";
import { DropdownType } from "../../interface/masterType";

const initialState: DropdownType[] = [];
const IdTypeJuristicSlice = createSlice({
    name: "idTypeJuristic",
    initialState: initialState,
    reducers: {
        idTypeJuristicReducer: (state, action) => {
            state = state.concat(action.payload);
            return state;
        },
    },
});

export const { idTypeJuristicReducer } = IdTypeJuristicSlice.actions;
export default IdTypeJuristicSlice.reducer;
