import { createSlice } from "@reduxjs/toolkit";
import { DropdownType } from "../../interface/masterType";

const initialState: DropdownType[] = [];
const TaxClassificationSlice = createSlice({
    name: "taxClassification",
    initialState: initialState,
    reducers: {
        taxClassificationReducer: (state, action) => {
            state = state.concat(action.payload);
            return state;
        },
    },
});

export const { taxClassificationReducer } = TaxClassificationSlice.actions;
export default TaxClassificationSlice.reducer;
