import { createSlice } from "@reduxjs/toolkit";
import { DropdownType } from "../../interface/masterType";

const initialState: DropdownType[] = [];
const PayeeCodeSlice = createSlice({
  name: "payeeCode",
  initialState: initialState,
  reducers: {
    payeeCodeReducer: (state, action) => {
      state = state.concat(action.payload);
      return state;
    },
  },
});

export const { payeeCodeReducer } = PayeeCodeSlice.actions;
export default PayeeCodeSlice.reducer;
