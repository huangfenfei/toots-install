import { createSlice } from "@reduxjs/toolkit";
import { PersonType } from "../../interface/masterType";

const initialState: PersonType = {
  name: "",
  lastname: "",
  lastlogin: "",
  ocCode: "",
  auth: null
};

const PersonSlice = createSlice({
  name: "person",
  initialState: initialState,
  reducers: {
    personReducer: (state, action) => {
      return action.payload;
    },
  },
});

export const { personReducer } = PersonSlice.actions;
export default PersonSlice.reducer;
