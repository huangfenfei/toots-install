import { createSlice } from "@reduxjs/toolkit";
import { DropdownType } from "../../interface/masterType";

const initialState: DropdownType[] = [];
const DocSupportCodeSlice = createSlice({
  name: "docSupport",
  initialState: initialState,
  reducers: {
    docSupportReducer: (state, action) => {
      state = state.concat(action.payload);
      return state;
    },
  },
});

export const { docSupportReducer } = DocSupportCodeSlice.actions;
export default DocSupportCodeSlice.reducer;
