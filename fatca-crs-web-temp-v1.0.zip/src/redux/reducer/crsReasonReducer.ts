import { createSlice } from "@reduxjs/toolkit";
import { DropdownType } from "../../interface/masterType";

const initialState: DropdownType[] = [];
const crsReasonSlice = createSlice({
    name: "crsReason",
    initialState: initialState,
    reducers: {
        crsReasonReducer: (state, action) => {
            state = state.concat(action.payload);
            return state;
        },
    },
});

export const { crsReasonReducer } = crsReasonSlice.actions;
export default crsReasonSlice.reducer;
