import { createSlice } from "@reduxjs/toolkit";
import { DropdownType } from "../../interface/masterType";

const initialState: DropdownType[] = [];
const NationalitySlice = createSlice({
    name: "nationality",
    initialState: initialState,
    reducers: {
        nationalityReducer: (state, action) => {
            state = state.concat(action.payload);
            return state;
        },
    },
});

export const { nationalityReducer } = NationalitySlice.actions;
export default NationalitySlice.reducer;
