import { createSlice } from "@reduxjs/toolkit";
import { DropdownType } from "../../interface/masterType";

const initialState: DropdownType[] = [];
const CountryOfBirthSlice = createSlice({
    name: "countryOfBirth",
    initialState: initialState,
    reducers: {
        countryOfBirthReducer: (state, action) => {
            state = state.concat(action.payload);
            return state;
        },
    },
});

export const { countryOfBirthReducer } = CountryOfBirthSlice.actions;
export default CountryOfBirthSlice.reducer;
