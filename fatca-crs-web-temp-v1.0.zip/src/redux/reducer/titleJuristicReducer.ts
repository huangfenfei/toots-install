import { createSlice } from "@reduxjs/toolkit";
import { DropdownType } from "../../interface/masterType";

const initialState: DropdownType[] = [];
const TitleJuristicReducerSlice = createSlice({
    name: "titleJuristic",
    initialState: initialState,
    reducers: {
        titleJuristicReducer: (state, action) => {
            state = state.concat(action.payload);
            return state;
        },
    },
});

export const { titleJuristicReducer } = TitleJuristicReducerSlice.actions;
export default TitleJuristicReducerSlice.reducer;
