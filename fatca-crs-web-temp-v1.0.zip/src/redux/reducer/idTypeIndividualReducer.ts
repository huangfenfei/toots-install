import { createSlice } from "@reduxjs/toolkit";
import { DropdownType } from "../../interface/masterType";

const initialState: DropdownType[] = [];
const IdTypeIndividualSlice = createSlice({
    name: "idTypeIndividual",
    initialState: initialState,
    reducers: {
        idTypeIndividualReducer: (state, action) => {
            state = state.concat(action.payload);
            return state;
        },
    },
});

export const { idTypeIndividualReducer } = IdTypeIndividualSlice.actions;
export default IdTypeIndividualSlice.reducer;
