import { createSlice } from "@reduxjs/toolkit";
import { PermissionType } from "../../interface/masterType";

const initialState: PermissionType = {
  add: "N",
  update: "N",
  delete: "N",
  search: "N",
  searchAll: "N",
  print: "N",
  report: "N"
};

const PermissionSlice = createSlice({
  name: "userPermission",
  initialState: initialState,
  reducers: {
    permissionReducer: (state, action) => {
      return action.payload;
    },
  },
});

export const { permissionReducer } = PermissionSlice.actions;
export default PermissionSlice.reducer;
