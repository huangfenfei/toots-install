import { createSlice } from "@reduxjs/toolkit";
import { BrancheType } from "../../interface/branchType";

const initialState: BrancheType[] = [];
const AllBranchSlice = createSlice({
    name: "allBranch",
    initialState: initialState,
    reducers: {
        allBranchReducer: (state, action) => {
            state = state.concat(action.payload);
            return state;
        },
    },
});

export const { allBranchReducer } = AllBranchSlice.actions;
export default AllBranchSlice.reducer;
