import { combineReducers, configureStore } from "@reduxjs/toolkit";
import personReducer from "../reducer/personReducer";
import permissionReducer from "../reducer/permissionReducer";
import taxClassificationReducer from "../reducer/taxClassificationReducer";
import payeeCodeReducer from "../reducer/payeeCodeReducer";
import titleJuristicReducer from "../reducer/titleJuristicReducer";
import titleIndividualReducer from "../reducer/titleIndividualReducer";
import idTypeIndividualReducer from "../reducer/idTypeIndividualReducer";
import reportingCodeReducer from "../reducer/reportingCodeReducer";
import docSupportReducer from "../reducer/docSupportReducer";
import idTypeJuristicReducer from "../reducer/idTypeJuristicReducer";
import nationalityReducer from "../reducer/nationalityReducer";
import countryOfBirthReducer from "../reducer/countryOfBirthReducer";
import crsCountryReducer from "../reducer/crsCountryReducer";
import crsReasonReducer from "../reducer/crsReasonReducer";
import allBranchReducer from "../reducer/allBranchReducer";
import storage from "redux-persist/lib/storage";
import { persistReducer, persistStore } from "redux-persist";

const persistConfig = {
  key: "fatca",
  storage
}

const rootReducer = combineReducers({
  personReducer,
  permissionReducer,
  taxClassificationReducer,
  payeeCodeReducer,
  reportingCodeReducer,
  docSupportReducer,
  titleJuristicReducer,
  titleIndividualReducer,
  idTypeJuristicReducer,
  idTypeIndividualReducer,
  nationalityReducer,
  countryOfBirthReducer,
  crsCountryReducer,
  crsReasonReducer,
  allBranchReducer,
});

const persistedReducer = persistReducer(persistConfig, rootReducer);

export const store = configureStore({
  reducer: persistedReducer,
});

export const persistor = persistStore(store);
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;