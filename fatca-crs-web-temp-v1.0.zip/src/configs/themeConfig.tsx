// theme/themeConfig.ts
import type { ThemeConfig } from "antd";
import localFont from 'next/font/local'

const themeConfig: ThemeConfig = {
  token: {
    fontSize: 14,
    fontFamily: "NotoSansThai",
    colorPrimary: "#4F3793"
  },
  components: {
    // Button: {
    //   colorPrimary: '#00b96b',
    // },
    // Input: {
    //   lineHeight: 1
    // },
    // Select: {
    //   lineHeight: 1
    // }
  },
};

export default themeConfig;
