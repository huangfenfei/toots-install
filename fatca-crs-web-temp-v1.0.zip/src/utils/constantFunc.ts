
export const convertYNUndefined = (value: string) => {
    return value === undefined ? "N" : value
}

export const convertEmptyUndefined = (value: string) => {
    return value === undefined ? "" : value
}

export const validateThaiCitizenId = (id: string) => {
    if (!/^\d{13}$/.test(id)) {
        return false;
    }

    let sum = 0;
    for (let i = 0; i < 12; i++) {
        sum += parseInt(id.charAt(i)) * (13 - i);
    }
    const chkSum = (11 - sum % 11 % 10);
    return chkSum === parseInt(id.charAt(12));
}

export const validatePassport = (value: string, nation: string) => {
    return value.substring(0, 2) === nation;
}