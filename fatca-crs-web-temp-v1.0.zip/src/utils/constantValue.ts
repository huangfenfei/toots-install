import { DropdownType } from "../interface/masterType";

export const plaseSelectData = () => {
    return {
        value: "",
        code_cd: "",
        descTH: "",
        descEN: "",
        label: "-- Please Select --"
    };
}

export const plaseSelectAllBranchData = () => {
    return {
        ocCode: "",
        ocTypeCode: "",
        ocNameTH: "",
        ocNameEN: "",
        priorityOC: "",
        value: "",
        label: "-- Please Select --"
    };
}

export const tinReasonDataList = () => {
    const res: DropdownType[] = [];
    const reasonPlaseSelect: DropdownType = {
        code_cd: "",
        descTH: "",
        descEN: "",
        value: "",
        label: "-- Please Select --"
    };
    res.push(reasonPlaseSelect);

    const reasonA: DropdownType = {
        code_cd: "",
        descTH: "",
        descEN: "",
        value: "A",
        label: "A: Jurisdiction does not issue TIN"
    };
    res.push(reasonA);

    const reasonB: DropdownType = {
        code_cd: "",
        descTH: "",
        descEN: "",
        value: "B",
        label: "B: Account holder is unable to obtain TIN"
    };
    res.push(reasonB);

    const reasonC: DropdownType = {
        code_cd: "",
        descTH: "",
        descEN: "",
        value: "C",
        label: "C: TIN not required to be disclosed"
    };
    res.push(reasonC);
    
    return res;
}