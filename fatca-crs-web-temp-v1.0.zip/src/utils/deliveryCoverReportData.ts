import { CustomerType, HeaderType } from "../interface/reportType";

export const deliveryCoverReportData = () => {
    const custList: CustomerType[] = [];

    for (let i = 1; i <= 48; i++) {
        const data: CustomerType = {
            rowNumber: i,
            idNum: "1111111111" + String(i).padStart(3, "1"),
            idType: "เลขที่บัตรประชาชน",
            customerName: "นายร้านยา" + i + " กรุงเทพ" + i,
            lastUpdateDate: "19/06/2024",
            customerType: "",
            fatcaStatus: "Indicia",
            IRSDoc: (i % 7 == 0) ? "W9" : "W8-BEN-E",
            docSupport: "เลขที่บัตรประชาชนไทย",
            transactionStatus: (i % 3 == 0) ? "Add" : "Update",
            userEntry: "user" + i,
            branch: "0111",
            sendDocDate: "",
            HOReceiveDate: "",
            HORemark: "",
            HoReceiveStatus: "COMPLETE",
        }
        custList.push(data);
    }

    const data: HeaderType = {
        reportType: "Delivery Report",
        brancdCode: "0001",
        customerList: custList,
    }
    return data
}