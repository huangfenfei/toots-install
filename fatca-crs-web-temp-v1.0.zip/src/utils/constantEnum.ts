export enum PermissionEnum {
    ADD = "add",
    UPDATE = "update",
    DELETE = "delete",
    SEARCH = "search",
    SEARCH_ALL = "searchAll",
    PRINT = "print",
    REPORT = "report",
}

export enum ResponseCodeEnum {
    SUCCESS = "0000",
    FAIL = "9999",
    UNAUTHORIZE = "9801",
    DUPLICATE = "0001",
}

export enum SearchEnum {
    FIRST_PAGE = 1,
    LIMIT_RECORD = 50,
}

export enum StorageItemKeyEnum {
    USERNAME_ITEM = "username",
    OC_CODE_ITEM = "ocCode",
    IS_AUTH_AZURE_ITEM = "isAuthAzure",
    ACCESS_TOKEN_ITEM = "accessToken",
    REFRESH_TOKEN_ITEM = "refreshToken",
    TOKEN_ITEM = "token",
    MASTER_ITEM = "master",
    ALL_BRANCH = "allBranch",
}

export enum IdTypeEnum {
    TAX_ID = "M1",
    CITIZEN_ID = "P1",
    ALIEN_ID = "P7",
    PASSPORT = "P8",
    OTHER_REGT = "B6",
    BUS_REGT = "B8",
    SWIFT_ID = "B9",
    FINANCIAL_INSTITUTION_CODE = "FI",
}

export enum JuristicFormEnum {
    W8_BEN_E = 10,
}

export enum SuccessMessageEnum {
    
}

export enum WarningMessageEnum {

}

export enum ErrorMessageEnum {
    VALID_CITIZEN_ID_ERR = "The thai citizen id format incorrectly.",
    VALID_PASSPORT_ERR = "The first 2 digits number of passport not equal with nation.",
}

