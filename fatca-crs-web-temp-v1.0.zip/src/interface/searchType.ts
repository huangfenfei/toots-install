export interface ResonseBodyType {
    respCode: string;
    respDesc: string;
    body: BobyType;
}

export interface BobyType {
    currentPage: string;
    totalPage: string;
    totalRecord: string;
    isLastPage: string;
    custList: CustomerType[];
}

export interface CustomerType {
    rowNumber: number;
    idNum: string;
    idType: string;
    customerName: string;
    lastUpdateDate: string;
    customerType: string;
    fatcaStatus: string;
    IRSDoc: string;
    docSupport: string;
    transactionStatus: string;
    userEntry: string;
    branch: string;
    sendDocDate: string;
    HOReceiveDate: string;
    HOReceiveStatus: string;
    HORemark: string;
    HoReceiveStatus: string;
}