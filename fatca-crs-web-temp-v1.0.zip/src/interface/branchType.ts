export default interface ResonseBodyBranchType {
    respCode: string;
    respDesc: string;
    body: BobyType;
}

export interface BobyType {
    branches: BrancheType[];
}

export interface BrancheType{
    ocCode: string;
    ocTypeCode: string;
    ocNameTH: string;
    ocNameEN: string;
    priorityOC: string;
    value: string;
    label: string;
}