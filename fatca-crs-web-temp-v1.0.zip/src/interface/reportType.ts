import { CustomerType } from "./searchType";

export interface HeaderType {
    reportType: string;
    brancdCode: string;
    customerList: CustomerType[];
}

/*export interface CustomerType {
    rowNumber: number;
    idNum: string;
    idType: string;
    customerName: string;
    lastUpdateDate: string;
    customerType: string;
    fatcaStatus: string;
    IRSDoc: string;
    docSupport: string;
    transactionStatus: string;
    userEntry: string;
    branch: string;
    sendDocDate: string;
    HOReceiveDate: string;
    HORemark: string;
    HoReceiveStatus: string;
}*/