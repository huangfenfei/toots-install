export interface ResonseBodyType {
    respCode: string;
    respDesc: string;
    body: BobyType;
}

export interface BobyType {
    person: PersonType;
    master: MasterType;
}

export interface PersonType {
    name: string;
    lastname: string;
    lastlogin: string;
    ocCode: string;
    auth: AuthType;
}

export interface AuthType {
    level: string;
    functionId: PermissionType;
}

export interface PermissionType {
    add: string;
    update: string;
    delete: string;
    search: string;
    searchAll: string;
    print: string;
    report: string;
}

export interface MasterType {
    codes: CodeType;
    titles: TitleType;
    idType: IdType;
    nationality: DropdownType[];
    countryOfBirth: DropdownType[];
    crsCountry: DropdownType[];
    crsReason: DropdownType[];
}

export interface CodeType {
    taxClassification: DropdownType[];
    payeeCode: DropdownType[];
    reportingCode: DropdownType[];
    docSupport: DropdownType[];
}

export interface TitleType {
    juristic: DropdownType[];
    individual: DropdownType[];
}

export interface IdType {
    juristic: DropdownType[];
    individual: DropdownType[];
}

export interface DropdownType {
    code_cd: string;
    descTH: string;
    descEN: string;
    value: string;
    label: string;
}