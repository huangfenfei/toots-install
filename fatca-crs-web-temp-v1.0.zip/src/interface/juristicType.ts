export interface JuristicType {
    userEntry: string;
    entryBrNo: string;
    customerInfo: CustomerInfoType;
    CRSCkList: CRSCheckListType
}

export interface CustomerInfoType {
    idType_cd: string;
    idNum: string;
    title_cd: string;
    customerName: string;
    nationality_cd: string;
    brNo: string;
    FATCAChkList: FatcaCheckListType; 
}

export interface FatcaCheckListType {
    indicia: string;
    entity: EntityType;
    IRSDoc: IRSDocumentType;
}

export interface EntityType {
    entityStatus: string;
}

export interface IRSDocumentType {
    w8Ben_E: W8BenEType;
    w9: W9Type;
}

export interface W8BenEType {
    isW8BenEExisted: string;
    supportingPerson: SupportingPersonType[];
}

export interface SupportingPersonType {
    name: string;
    address: string;
    TIN: string;
}

export interface W9Type {
    businessName: string;
    taxClass_cd: string;
    exemptPayee_cd: string;
    exemptFromFatcaReport_cd: string;
    address: string;
    city: string;
    state: string;
    zip: string;
    TIN: TINType;
}

export interface TINType {
    EIN: string;
}

export interface CRSCheckListType {
    IENonPar: string;
    IEOther: string;
    FIUnderCrs: string;
    ANFECorporate: string;
    ANFEGovernment: string;
    ANFEInterOrg: string;
    ANFEOther: string;
    PassiveNFFE: string;
    ANFECorporateInfo: ANFECorporateInfoType;
    countryTax: CountryTaxType[];
    controllingPerson: ControllingPersonType[];
}

export interface ANFECorporateInfoType {
    stockMarketName: string;
    stockName: string;
}

export interface ControllingPersonType {
    title_cd: string;
    customerName: string;
    dob: string;
    cityOfBirth: string;
    countryOfBirth_cd: string;
    fullAddr: string;
    fullAddrCountry: string;
    mailingAddr: string;
    mailingAddrCountry: string;
    ctpCountryTax: CountryTaxType[];
}

export interface CountryTaxType {
    country_cd: string;
    TIN: string;
    reason_cd: string;
    reason: string;
}
