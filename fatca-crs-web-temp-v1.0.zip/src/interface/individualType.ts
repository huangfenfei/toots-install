export interface IndividualType {
    userEntry: string;
    entryBrNo: string;
    customerInfo: CustomerInfoType;
    CRSCkList
}

export interface CustomerInfoType {
    idType_cd: string;
    idNum: string;
    title_cd: string;
    firstName: string;
    lastName: string;
    middleName: string;
    nationality_cd: string;
    brNo: string;
    countryOfBirth_cd: string;
    cityOfBirth: string;
    FATCAChkList: FatcaCheckListType;
}

export interface FatcaCheckListType {
    indicia: string;
    USPerson: USPersonType;
    additionalQ: AdditionalQType;
    IRSDoc: IRSDocumentType;
}

export interface USPersonType {
    isCitizen: string;
    isGreenCard: string;
    isResident: string;
}

export interface AdditionalQType {
    surrendered: string;
    ftToUS: string;
    POA: string;
    holdMail: string;
    USAddress: string;
    USPhNo: string;
}

export interface IRSDocumentType {
    w8Ben: string;
    w9: W9Type;
}

export interface W9Type {
    name: string;
    taxClass_cd: string;
    exemptPayee_cd: string;
    exemptFromFatcaReport_cd: string;
    address: string;
    city: string;
    state: string;
    zip: string;
    SSN: string;
}

export interface CRSCheckListType {
    crs: string;
    countryTax: CountryTaxType[];
}

export interface CountryTaxType {
    country_cd: string;
    TIN: string;
    reason_cd: string;
    reason: string;
}

