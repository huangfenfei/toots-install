import { StorageItemKeyEnum } from "../utils/constantEnum";

export const getRefreshTokenStorage = (): string => {
    return sessionStorage.getItem(StorageItemKeyEnum.REFRESH_TOKEN_ITEM);
}

export const saveRefreshTokenStorage = (token: string) => {
    sessionStorage.setItem(StorageItemKeyEnum.REFRESH_TOKEN_ITEM, token);
}

export const clearRefreshTokenStorage = () => {
    sessionStorage.removeItem(StorageItemKeyEnum.REFRESH_TOKEN_ITEM);
}