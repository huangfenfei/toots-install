import { StorageItemKeyEnum } from "../utils/constantEnum";

export const getUsernameStorage = (): string => {
    return sessionStorage.getItem(StorageItemKeyEnum.USERNAME_ITEM);
}

export const saveUsernameStorage = (username: string) => {
    sessionStorage.setItem(StorageItemKeyEnum.USERNAME_ITEM, username);
}

export const clearUsernameStorage = () => {
    sessionStorage.removeItem(StorageItemKeyEnum.USERNAME_ITEM);
}