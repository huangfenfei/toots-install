import { StorageItemKeyEnum } from "../utils/constantEnum";

export const getAccessTokenStorage = (): string => {
    return sessionStorage.getItem(StorageItemKeyEnum.ACCESS_TOKEN_ITEM);
}

export const saveAccessTokenStorage = (token: string) => {
    sessionStorage.setItem(StorageItemKeyEnum.ACCESS_TOKEN_ITEM, token);
}

export const clearAccessTokenStorage = () => {
    sessionStorage.removeItem(StorageItemKeyEnum.ACCESS_TOKEN_ITEM);
}