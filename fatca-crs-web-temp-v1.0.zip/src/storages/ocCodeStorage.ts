import { StorageItemKeyEnum } from "../utils/constantEnum";

export const getOcCodeStorage = (): string => {
    return sessionStorage.getItem(StorageItemKeyEnum.OC_CODE_ITEM);
}

export const saveOcCodeStorage = (username: string) => {
    sessionStorage.setItem(StorageItemKeyEnum.OC_CODE_ITEM, username);
}

export const clearOcCodeStorage = () => {
    sessionStorage.removeItem(StorageItemKeyEnum.OC_CODE_ITEM);
}