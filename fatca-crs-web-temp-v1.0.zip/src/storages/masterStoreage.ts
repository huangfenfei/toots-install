import { StorageItemKeyEnum } from "../utils/constantEnum";

export const getMasterDataStorage = (): string => {
    return sessionStorage.getItem(StorageItemKeyEnum.MASTER_ITEM);
}

export const saveMasterDataStorage = (token: string) => {
    sessionStorage.setItem(StorageItemKeyEnum.MASTER_ITEM, token);
}

export const clearMasterData = () => {
    sessionStorage.removeItem(StorageItemKeyEnum.MASTER_ITEM);
}

export const getAllBranchStorage = (): string => {
    return sessionStorage.getItem(StorageItemKeyEnum.ALL_BRANCH);
}

export const saveAllBranchStorage = (token: string) => {
    sessionStorage.setItem(StorageItemKeyEnum.ALL_BRANCH, token);
}

export const clearAllBranchStorage = () => {
    sessionStorage.removeItem(StorageItemKeyEnum.ALL_BRANCH);
}