import { StorageItemKeyEnum } from "../utils/constantEnum";

export const getTokenStorage = (): string => {
    return sessionStorage.getItem(StorageItemKeyEnum.TOKEN_ITEM);
}

export const saveTokenStorage = (token: string) => {
    sessionStorage.setItem(StorageItemKeyEnum.TOKEN_ITEM, token);
}

export const clearTokenStorage = () => {
    sessionStorage.removeItem(StorageItemKeyEnum.TOKEN_ITEM);
}
