import { StorageItemKeyEnum } from "../utils/constantEnum";

export const getIsAuthAzureStorage = (): boolean => {
    return sessionStorage.getItem(StorageItemKeyEnum.IS_AUTH_AZURE_ITEM) == 'true'
}

export const saveIsAuthAzureStorage = () => {
    sessionStorage.setItem(StorageItemKeyEnum.IS_AUTH_AZURE_ITEM, 'true');
}

export const clearIsAuthAzureStorage = () => {
    sessionStorage.removeItem(StorageItemKeyEnum.IS_AUTH_AZURE_ITEM);
}