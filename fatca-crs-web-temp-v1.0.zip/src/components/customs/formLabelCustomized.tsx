import React from 'react';
import { Typography } from "antd";

const FormLabelCustomized = ({ label, required }: { label: string, required: boolean }) => {
    const { Text } = Typography;
    return (
        <div>
            {label}
            {required ? <Text style={{ color: "#ff4d4f", marginLeft: 5 }}>*</Text> : null}
        </div>
    );
}

export default FormLabelCustomized;