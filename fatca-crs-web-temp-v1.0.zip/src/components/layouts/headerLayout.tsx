import React, { useEffect, useState } from "react";
import { useMsal } from "@azure/msal-react";
import { Col, Layout, Row, Image } from "antd";
import { BiSolidErrorCircle, BiUser } from "react-icons/bi";
import { MdLogout } from "react-icons/md";
import dayjs from "dayjs";
import { LogoutModel } from "../modals/logoutModal";
import ConfirmModal from "../modals/confirmModal";
import { useMutation } from "@tanstack/react-query";
import { logoutWithAzureAD } from "../../services/auth/authService";
import { UserLogout } from "../auth/logout";
import { PersonType } from "../../interface/masterType";
import { useSelector } from "react-redux";
import { RootState } from "../../redux/store/store";
import TokenModel from "../modals/tokenModal";

const { Header, Content, Sider } = Layout;

const HeaderLayout = ({ name }: { name: string }) => {
    const [accountName, setAccountName] = useState("Unknown");
    const { instance, accounts } = useMsal();
    const { logout } = UserLogout();
    const isAuthenticated = accounts.length > 0;
    const [isDisplayLogoutModal, setIsDisplayLogoutModal] = useState(false);
    const [isDisplayTokenModal, setIsDisplayTokenModel] = useState(false);
    const person: PersonType = useSelector((state: RootState) => state.personReducer);

    useEffect(() => {
        if (isAuthenticated) {
            const accInfo = accounts[0];
            setAccountName(accInfo.name ?? 'Unknown');
        }
    }, []);

    const handleLogout = () => {
        setIsDisplayLogoutModal(true);
    }

    const logoutMutation = useMutation({
        mutationFn: (data: any) => logoutWithAzureAD(),
        onSuccess(data) {
            logout();
        }
    });

    const callbackLogout = () => {
        logoutMutation.mutate(null);
    }

    const handleTokenModal = () => {
        setIsDisplayTokenModel(true);
    }

    return (
        <Header style={{ background: '#4F3793', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 100 }}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
                <Image src="/assets/images/scb-logo2.png" width={220} alt="Logo" preview={false} />
                <span style={{ fontSize: 28, color: "#fff", fontWeight: "bold", marginLeft: 20 }}>FATCA & CRS SYSTEM</span>
            </div>
            <div style={{ marginRight: '8px' }}>
                <Row justify="end" style={{ textAlign: 'right', height: 28 }}>
                    <Col span={24}>
                        <span style={{ display: "ruby", color: "#fff", fontWeight: "bold" }}><BiUser size={20} style={{ marginTop: -3 }} /> {person.name + " " + person.lastname}</span>
                    </Col>
                </Row>
                <Row justify="end" style={{ textAlign: 'right', height: 28 }}>
                    <Col span={24}>
                        <span style={{ color: "#fff", fontWeight: "inherit" }}>{person.lastlogin}</span>
                    </Col>
                </Row>
                <Row justify="end" style={{ textAlign: 'right' }}>
                    <Col span={8}>
                        <a className="ant-dropdown-link" onClick={handleTokenModal}>
                            <span style={{ display: "ruby", color: "#fff", fontWeight: "bold" }}><BiSolidErrorCircle size={16} color="#EDA40C" />Token</span>
                        </a>
                    </Col>
                    <Col span={16}>
                        <a className="ant-dropdown-link" onClick={handleLogout}>
                            <span style={{ display: "ruby", color: "#fff", fontWeight: "bold" }}><MdLogout size={20} style={{ marginTop: -3 }} /> Logout</span>
                        </a>
                    </Col>

                </Row>
                <ConfirmModal
                    isModalOpen={isDisplayLogoutModal}
                    handleMessage={"Are you sure want to Logout?"}
                    handleOk={callbackLogout}
                    handleCancel={() => setIsDisplayLogoutModal(false)}
                />
                <TokenModel
                    isModalOpen={isDisplayTokenModal}
                    handleOk={() => setIsDisplayTokenModel(false)}
                />
            </div>
        </Header>
    );
}

export default HeaderLayout;