import React, { ReactElement } from "react";
import { Layout, theme } from "antd";
import BreadcrumbLayout from "./breadcrumLayout";

const ContentLayout = ({ children }: { children: ReactElement }) => {
    const {
        token: { colorBgContainer, borderRadiusLG },
    } = theme.useToken();


    return (
        <Layout>
            <Layout.Content
                style={{
                    paddingTop: 12,
                    paddingBottom: 36,
                    paddingLeft: 24,
                    paddingRight: 24,
                    // minHeight: "100vh",
                    background: colorBgContainer,
                    // borderRadius: borderRadiusLG,
                    overflow: "auto",
                }}
            >
                <BreadcrumbLayout />
                {children}
            </Layout.Content>
        </Layout>
    );
}

export default ContentLayout;