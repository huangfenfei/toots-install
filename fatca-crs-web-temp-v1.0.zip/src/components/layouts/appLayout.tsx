import React, { ReactElement, useState } from "react";
import { Layout } from "antd";
import HeaderLayout from "./headerLayout";
import MenuLayout from "./menuLayout";
import ContentLayout from "./contentLayout";

const AppLayout = ({ children }: { children: ReactElement }) => {
  return (
    <Layout className="h-screen fixed w-full">
      <HeaderLayout name="Somchai Marasri" />
      <Layout>
        <MenuLayout />
        <ContentLayout children={children} />
      </Layout>
    </Layout>
  );
};

export default AppLayout;
