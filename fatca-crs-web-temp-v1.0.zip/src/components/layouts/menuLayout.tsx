import React, { useState } from "react";
import { useRouter } from "next/router";
import { Layout, Menu, Row, Image, GetProp, MenuProps } from "antd";
import { UsbOutlined } from "@ant-design/icons";
import { BsPersonAdd } from "react-icons/bs";
import { PermissionReduxComponent } from "../reduxes/permission";
import { IoSearch } from "react-icons/io5";
import { RiContactsBookUploadLine } from "react-icons/ri";
import { PermissionEnum } from "../../utils/constantEnum";

const { Sider } = Layout;

const MenuLayout = () => {
  const { hasPermission } = PermissionReduxComponent();
  const router = useRouter();
  const [collapsed, setCollapsed] = useState(false);
  const items: MenuProps["items"] = [
    hasPermission(PermissionEnum.ADD)
      ? {
        label: "Add FATCA & CRS",
        key: "add",
        icon: <BsPersonAdd size={26} />,
        onClick: (e) => router.push("/add-fatca-crs"),
      }
      : null,
    {
      label: "Inquiry / Maintenance",
      key: "inquiry",
      icon: <IoSearch size={26} />,
      onClick: (e) => router.push("/inquiry"),
    },
    {
      label: "Batch Result",
      key: "batch",
      icon: <RiContactsBookUploadLine size={26} />,
      onClick: (e) => router.push("/batch-result"),
    },
  ];

  return (
    <Sider
      collapsedWidth={60}
      theme="light"
      width={300}
      breakpoint={"lg"}
      collapsible
      collapsed={collapsed}
      onCollapse={(value) => setCollapsed(value)}
      style={{backgroundColor:"#F3F3F3"}}
    >
      {!collapsed &&
        <Row justify="center" style={{ height: 120}}>
          <Image
            src="/assets/images/fatca-logo.png"
            width={250}
            alt="Logo"
            preview={false}
            style={{ marginTop: 24 }}
          />
        </Row>
      }
      <Menu
        mode="inline"
        defaultSelectedKeys={["2"]}
        style={{ height: "100%", borderRight: 0, backgroundColor: "#F3F3F3", marginTop: 24 }}
        items={items}
        
      />
    </Sider>
  );
};

export default MenuLayout;
