import { Breadcrumb } from "antd";
import { useRouter } from "next/router";


const BreadcrumbLayout = () => {
    const router = useRouter();
    const pathSnippets = router.asPath.split('/').filter(i => i);

    const breadcrumbNameMap = {
        '/add-fatca-crs': 'Add FATCA & CRS',
        '/inquiry': 'Inquiry / Maintenance',
        '/inquiry/customer': 'Search by Customer',
        '/inquiry/customer/view': 'View FATCA & CRS Detail',
        '/inquiry/transaction': 'Search by Transaction',
        '/inquiry/transaction/view/[id]': 'View FATCA & CRS Detail',
        '/batch-result' : 'Batch Result'
    }

    const extraBreadcrumbItems = pathSnippets.map((_, index) => {
        const url = `/${pathSnippets.slice(0, index + 1).join('/')}`;
        return (
            <Breadcrumb.Item key={url}>{breadcrumbNameMap[url]}</Breadcrumb.Item>
        );
    });

    const breadcrumbItems = [].concat(extraBreadcrumbItems);

    return (
        <Breadcrumb separator=">" style={{marginBottom: 12}}>{breadcrumbItems}</Breadcrumb>
    );
}

export default BreadcrumbLayout;