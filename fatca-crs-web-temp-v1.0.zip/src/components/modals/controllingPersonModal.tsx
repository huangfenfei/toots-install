import React, { useEffect, useState } from "react";
import { Button, Col, DatePicker, DatePickerProps, Form, FormInstance, Input, Modal, Row, Select } from "antd";
import ForeignTINTableForm from "../forms/add-fatca-crs/common/foreignTinTableForm";
import { RootState } from "../../redux/store/store";
import { DropdownType } from "../../interface/masterType";
import { useSelector } from "react-redux";
import { v4 as uuidv4 } from 'uuid';
import dayjs from "dayjs";
import FormLabelCustomized from "../customs/formLabelCustomized";

const ControllingPersonModel = ({ visibleOpen, handleCancel, ctrlPersonData, controllingPerson }: { visibleOpen: boolean, handleCancel: any, ctrlPersonData: any, controllingPerson: any }) => {
    const titleIndividualList: DropdownType[] = useSelector((state: RootState) => state.titleIndividualReducer);
    const countryOfBirthList: DropdownType[] = useSelector((state: RootState) => state.countryOfBirthReducer);

    const [form] = Form.useForm();
    const uuid = uuidv4();
    // const [countryTax, setCountryTax] = useState([]);
    // const [countryTaxUpdate, setCountryTaxUpdate] = useState([]);
    const [dateOfBirth, setDateOfBirth] = useState("");

    useEffect(() => {
        if (visibleOpen && ctrlPersonData) {
            console.log("ControllingPersonModel.useEffect ==>", visibleOpen, ctrlPersonData);
            let firstName = "";
            let middleName = "";
            let lastName = "";

            if (ctrlPersonData.customerName) {
                const nameArr = ctrlPersonData.customerName.split(" ");
                if (nameArr.length === 3) {
                    firstName = nameArr[0];
                    middleName = nameArr[1];
                    lastName = nameArr[2];
                } else if (nameArr.length === 2) {
                    firstName = nameArr[0];
                    lastName = nameArr[1];
                } else if (nameArr.length === 2) {
                    firstName = nameArr[0];
                }
            }

            const dobDayJs = dayjs(ctrlPersonData.dob, "DD-MM-YYYY");
            // form.setFieldsValue({
            //     ctrlPersonTitleCode: ctrlPersonData.title_cd,
            //     ctrlPersonFirstName: firstName,
            //     ctrlPersonMiddleName: middleName,
            //     ctrlPersonLastName: lastName,
            //     ctrlPersonDateOfBirth: dobDayJs,
            //     ctrlPersonCityOfBirth: ctrlPersonData.cityOfBirth,
            //     ctrlPersonCountryOfBirthCode: ctrlPersonData.countryOfBirth_cd,
            //     ctrlPersonFullAddress: ctrlPersonData.fullAddr,
            //     ctrlPersonFullAddrCountryCode: ctrlPersonData.fullAddrCountry,
            //     ctrlPersonMailAddress: ctrlPersonData.mailingAddr,
            //     ctrlPersonMailAddrCountryCode: ctrlPersonData.mailingAddrCountry,
            // });
            // setCountryTaxUpdate(ctrlPersonData.ctpCountryTax);
            form.setFieldsValue(ctrlPersonData);
        } else {
            form.resetFields();
        }
    }, [visibleOpen, ctrlPersonData]);

    const handleSubmit = () => {
        form.submit();
    }

    const handleFinish = (data: any) => {
        console.log("handleFinish ==>", data);
        let custName = "";
        if (data.ctrlPersonMiddleName) {
            custName = replaceSpace(data.ctrlPersonFirstName) + " " + replaceSpace(data.ctrlPersonMiddleName) + " " + replaceSpace(data.ctrlPersonLastName);
        } else {
            custName = replaceSpace(data.ctrlPersonFirstName) + " " + replaceSpace(data.ctrlPersonLastName);
        }

        const countryOfBirthName = countryOfBirthList.find((it) => it.code_cd === data.ctrlPersonCountryOfBirthCode);
        const fullAddrCountryName = countryOfBirthList.find((it) => it.code_cd === data.ctrlPersonFullAddrCountryCode);
        const mailAddrCountryName = countryOfBirthList.find((it) => it.code_cd === data.ctrlPersonMailAddrCountryCode);
        data.key = ctrlPersonData.key === "" ? uuid : ctrlPersonData.key;
        // const ctrlPerson = {
        //     key: ctrlPersonData.key === "" ? uuid : ctrlPersonData.key,
        //     title_cd: data.ctrlPersonTitleCode,
        //     customerName: custName,
        //     dob: dateOfBirth,
        //     cityOfBirth: data.ctrlPersonCityOfBirth,
        //     countryOfBirth_cd: data.ctrlPersonCountryOfBirthCode,
        //     fullAddr: data.ctrlPersonFullAddress,
        //     fullAddrCountry: data.ctrlPersonFullAddrCountryCode,
        //     mailingAddr: data.ctrlPersonMailAddress,
        //     mailingAddrCountry: data.ctrlPersonMailAddrCountryCode,
        //     countryOfBirthName: countryOfBirthName.label,
        //     customerFullName: data.ctrlPersonTitleCode + " " + custName,
        //     fullAddrCountryName: data.ctrlPersonFullAddress + ", " + fullAddrCountryName.label,
        //     mailingAddrCountryName: data.ctrlPersonMailAddress + ", " + mailAddrCountryName.label,
        //     numberOfCountry: data.taxResidencies.length,
        //     ctpCountryTax: data.taxResidencies,
        //     originData: data
        // };
        controllingPerson(data);
        handleCancel();
    }

    const handleDateOfBirthChange = (date: any, dateString: string) => {
        setDateOfBirth(dateString);
    };

    const replaceSpace = (value: string) => {
        return value.replace(/ /g, '');
    }

    return (
        <div>
            <Modal
                title="Controlling Person Information"
                closable={false}
                open={visibleOpen}
                onCancel={handleCancel}
                footer={
                    <div style={{ gap: 15 }}>
                        <Button type="default" onClick={handleCancel} style={{ width: 100, justifyContent: "center" }}>Cancel</Button>
                        <Button type="primary" htmlType="submit" onClick={handleSubmit} style={{ width: 100, justifyContent: "center", marginLeft: 15, }}>Save</Button>
                    </div>
                }
                width={1400}
            >
                <Form form={form} onFinish={handleFinish} labelCol={{ flex: '200px' }} labelAlign="left">
                    <Row gutter={24}>
                        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                            <Form.Item
                                name={["ctrlPersonTitleCode"]}
                                label={<FormLabelCustomized label={"Title"} required={true} />}
                                rules={[{ required: true, message: "Please select Title!" }]}
                                required={false}>
                                <Select
                                    showSearch
                                    placeholder="Please Select"
                                    optionFilterProp="children"
                                    filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                    options={titleIndividualList}
                                />
                            </Form.Item>
                        </Col>
                    </Row>
                    <Row gutter={24}>
                        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                            <Form.Item
                                name={["ctrlPersonFirstName"]}
                                label={<FormLabelCustomized label={"First Name"} required={true} />}
                                rules={[{ required: true, message: "Please input First Name!" }]}
                                required={false}
                            >
                                <Input maxLength={100}></Input>
                            </Form.Item>
                        </Col>
                    </Row>
                    <Row gutter={24}>
                        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                            <Form.Item
                                name={["ctrlPersonMiddleName"]}
                                label={<FormLabelCustomized label={"Middle Name"} required={false} />}
                            >
                                <Input maxLength={100}></Input>
                            </Form.Item>
                        </Col>
                    </Row>
                    <Row gutter={24}>
                        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                            <Form.Item
                                name={["ctrlPersonLastName"]}
                                label={<FormLabelCustomized label={"Last Name"} required={true} />}
                                rules={[{ required: true, message: "Please input Last Name!" }]}
                                required={false}
                            >
                                <Input maxLength={100}></Input>
                            </Form.Item>
                        </Col>
                        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                            <Form.Item
                                name={["ctrlPersonDateOfBirth"]}
                                label={<FormLabelCustomized label={"Date of Birth"} required={true} />}
                                rules={[{ required: true, message: "Please select Date of Birth!" }]}
                                required={false}
                            >
                                <DatePicker placeholder="DD-MM-YYYY" format={"DD-MM-YYYY"} style={{ width: '100%' }} onChange={handleDateOfBirthChange} />
                            </Form.Item>
                        </Col>
                    </Row>
                    <Row gutter={24}>
                        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                            <Form.Item
                                name={["ctrlPersonCityOfBirth"]}
                                label={<FormLabelCustomized label={"City of Birth"} required={false} />}
                            >
                                <Input maxLength={100}></Input>
                            </Form.Item>
                        </Col>
                        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                            <Form.Item
                                name={["ctrlPersonCountryOfBirthCode"]}
                                label={<FormLabelCustomized label={"Country of Birth"} required={true} />}
                                rules={[{ required: true, message: "Please select Country of Birth!" }]}
                                required={false}
                            >
                                <Select
                                    showSearch
                                    placeholder="Please Select"
                                    optionFilterProp="children"
                                    filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                    options={countryOfBirthList}
                                />
                            </Form.Item>
                        </Col>
                    </Row>
                    <Row gutter={24}>
                        <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                            <Form.Item
                                name={["ctrlPersonFullAddress"]}
                                label={<FormLabelCustomized label={"Full Address"} required={true} />}
                                rules={[{ required: true, message: "Please input Full Address!" }]}
                                required={false}
                            >
                                <Input maxLength={100}></Input>
                            </Form.Item>
                        </Col>
                    </Row>
                    <Row gutter={24}>
                        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                            <Form.Item
                                name={["ctrlPersonFullAddrCountryCode"]}
                                label={<FormLabelCustomized label={"Full Address Country"} required={true} />}
                                rules={[{ required: true, message: "Please select Full Address Country!" }]}
                                required={false}
                            >
                                <Select
                                    showSearch
                                    placeholder="Please Select"
                                    optionFilterProp="children"
                                    filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                    options={countryOfBirthList}
                                />
                            </Form.Item>
                        </Col>
                    </Row>
                    <Row gutter={24}>
                        <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                            <Form.Item
                                name={["ctrlPersonMailAddress"]}
                                label={<FormLabelCustomized label={"Mailing Address"} required={true} />}
                                rules={[{ required: true, message: "Please input Mailing Address!" }]}
                                required={false}
                            >
                                <Input maxLength={100}></Input>
                            </Form.Item>
                        </Col>
                    </Row>
                    <Row gutter={24}>
                        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                            <Form.Item
                                name={["ctrlPersonMailAddrCountryCode"]}
                                label={<FormLabelCustomized label={"Mailing Address Country"} required={true} />}
                                rules={[{ required: true, message: "Please select Mailing Address Country!" }]}
                                required={false}
                            >
                                <Select
                                    showSearch
                                    placeholder="Please Select"
                                    optionFilterProp="children"
                                    filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                    options={countryOfBirthList}
                                />
                            </Form.Item>
                        </Col>
                    </Row>
                    <ForeignTINTableForm form={form} onFinish={handleFinish} data={null} onCallback={null} titleName={"Declaration of Tax Residency and Taxpayer Identification Number (TIN)"} />
                </Form>
            </Modal>
        </div>
    );
}

export default ControllingPersonModel;