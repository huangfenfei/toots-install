import React, { useState } from "react";
import { Button, Col, Form, Input, Modal, Row, Select } from "antd";
import ForeignTINTableForm from "../forms/add-fatca-crs/common/foreignTinTableForm";
import { getAccessTokenStorage } from "../../storages/accessTokenStorage";
import { getRefreshTokenStorage } from "../../storages/refreshTokenStorage";
import { getTokenStorage } from "../../storages/tokenStorage";

const TokenModel = ({ isModalOpen, handleOk }) => {

    const accessToken = getAccessTokenStorage();
    const idToken = getRefreshTokenStorage();
    const token = getTokenStorage();

    return (
        <div>
            <Modal title="Token Key" open={isModalOpen} onOk={handleOk} width={1000} closable={false}
                footer={
                    <div style={{ display: 'flex', justifyContent: 'center', gap: 15 }}>
                        <Button type="primary" onClick={handleOk}>
                            OK
                        </Button>
                    </div>
                }
            >
                <Form
                    name="wrap"
                    labelCol={{ xxl: 8, xl: 8, lg: 24, md: 24, sm: 24, xs: 24 }}
                    labelAlign="left"
                    labelWrap
                    layout="vertical"
                >
                    <Row gutter={24}>
                        <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                            <Form.Item label={"Access Token"} >
                                <Input.TextArea rows={12} disabled={true} value={accessToken} />
                            </Form.Item>
                        </Col>
                    </Row>
                    <Row gutter={24}>
                        <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                            <Form.Item label={"Id Token"} >
                                <Input.TextArea rows={8} disabled={true} value={idToken} />
                            </Form.Item>
                        </Col>
                    </Row>
                    <Row gutter={24}>
                        <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                            <Form.Item label={"Token"} >
                                <Input.TextArea rows={4} disabled={true} value={token} />
                            </Form.Item>
                        </Col>
                    </Row>
                </Form>
            </Modal>
        </div>
    );
}

export default TokenModel;