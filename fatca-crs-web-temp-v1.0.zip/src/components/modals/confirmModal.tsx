import React, { useState } from "react";
import { Button, Modal, Row } from "antd";
import { BiSolidErrorCircle } from "react-icons/bi";

const ConfirmModal = ({ isModalOpen, handleMessage, handleOk, handleCancel }) => {
    return (
        <div>
            <Modal
                centered
                closable={false}
                open={isModalOpen}
                footer={
                    <div style={{ display: 'flex', justifyContent: 'center', gap: 15 }}>
                        <Button type="default" onClick={handleCancel}>
                            Cancel
                        </Button>
                        <Button type="primary" onClick={handleOk}>
                            OK
                        </Button>
                    </div>
                }
                width={400}
                style={{ textAlign: 'center' }}
            >
                <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 10 }}>
                    <Row>
                        <BiSolidErrorCircle size={50} color="#EDA40C" />
                    </Row>
                </div>
                <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 20 }}>
                    <Row>
                        <span>{handleMessage}</span>
                    </Row>
                </div>
            </Modal>
        </div>
    );
};

export default ConfirmModal;