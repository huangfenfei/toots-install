import React, { useState } from "react";
import { Button, Modal, Row } from "antd";
import { FaCheckCircle } from "react-icons/fa";

const SuccessModal = ({ isModalOpen, handleMessage, handleOk }) => {
    return (
        <div>
            <Modal
                centered
                closable={false}
                open={isModalOpen}
                footer={
                    <div style={{ display: 'flex', justifyContent: 'center', gap: 15 }}>
                        <Button type="primary" onClick={handleOk}>
                            OK
                        </Button>
                    </div>
                }
                width={400}
                style={{ textAlign: 'center' }}
            >
                <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 10 }}>
                    <Row>
                        <FaCheckCircle size={50} color="#008000" />
                    </Row>
                </div>
                <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 20 }}>
                    <Row>
                        <span>{handleMessage}</span>
                    </Row>
                </div>
            </Modal>
        </div>
    );
};

export default SuccessModal;