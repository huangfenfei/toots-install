import React,{ useEffect, useState } from "react";
import { Button, Col, DatePicker, DatePickerProps, Form, Input, Row, Select, Space, Spin} from "antd";
import TransectionTableForm from "./transectionTableForm";
import customParseFormat from "dayjs/plugin/customParseFormat";
import dayjs from "dayjs";
import { SearchEnum } from "../../../../utils/constantEnum";
import { useMutation } from "@tanstack/react-query";
import { CustomerType } from "../../../../interface/searchType";
import { fetchSearchTransaction } from "../../../../services/search/searchTransactionService";
import { DeliveryCustomerReportPage } from "../../../reports/deliveryCustomerReport";
import { DeliveryCoverReportPage } from "../../../reports/deliveryCoverReport";
import { useSelector } from "react-redux";
import { RootState } from "../../../../redux/store/store";
import { useDispatch } from "react-redux";
import { BrancheType } from "../../../../interface/branchType";
import { HeaderType } from "../../../../interface/reportType";

const SearchTransactionForm = () => {
    const [form] = Form.useForm();
    const allBranchList: BrancheType[] = useSelector((state: RootState) => state.allBranchReducer);
    const dispatch = useDispatch();
    const [branch, setBranch] = useState('');
    const [branchCover, setBranchCover] = useState('');
    const [transStatus, setTransStatus] = useState('A');
    const [sendDocument, setSendDocument] = useState('N');
    const [fatcaStatus, setFatcaStatus] = useState('Y');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    
    const [isDisableSearchBtn, setIsDisableSearchBtn] = useState(true);
    const [isDisablePrintCustomerBtn, setIsDisablePrintCustomerBtn] = useState(true);
    const [isDisablePrintCoverBtn, setIsDisablePrintCoverBtn] = useState(true);

    const [customerList, setCustomerList] = useState<CustomerType[]>([]);
    const [customerSelectedList, setCustomerSelectedList] = useState<CustomerType[]>([]);
    //const [headerType, setHeaderType] = useState<HeaderType>();
    const [loading, setLoading] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [currentRecord, setCurrentRecord] = useState(0);
    const [totalRecord, setTotalRecord] = useState(0);

    const [hasMore, setHasMore] = useState(true);
    const [lastRowNumber, setLastRowNumber] = useState(0);

    const { generatePDF } = DeliveryCustomerReportPage();
    const { generateCoverPDF } = DeliveryCoverReportPage();

    dayjs.extend(customParseFormat);
    const dateFormat = 'YYYY-MM-DD';
    const curr_Date = new Date();
    const min_Date = new Date(new Date().setDate(curr_Date.getDate() - 30));
    const back_Date = new Date(new Date().setDate(curr_Date.getDate() - 7));
    const dateMax = curr_Date.getFullYear()+'-'+('0' + (curr_Date.getMonth()+1)).slice(-2)+'-'+('0' + curr_Date.getDate()).slice(-2);
    const dateMin = min_Date.getFullYear()+'-'+('0' + (min_Date.getMonth()+1)).slice(-2)+'-'+('0' + min_Date.getDate()).slice(-2);
    const dateBack = back_Date.getFullYear()+'-'+('0' + (back_Date.getMonth()+1)).slice(-2)+'-'+('0' + back_Date.getDate()).slice(-2);
    
    const handleSearch = () => {
        fetchData(SearchEnum.FirstPage);
        setBranchCover(branch);
    };

    const handleLoadMore = () => {
        fetchData(currentPage + SearchEnum.FirstPage);
    };

    const fetchData = async (page) =>{
        setLoading(true);
        const body = {
            page: page,
            limit: SearchEnum.LimitRecord,
            branchNo: "",
            transactionStartDate: startDate,
            transactionEndDate: endDate,
            transactionStatus: transStatus,
            sendDocStatus: "N",
            fatcaStatus: "Y"
        }
        console.log("body:"+JSON.stringify(body));
        fetch.mutate(body); 
    };

    const fetch = useMutation({
        mutationFn: (data: any) => fetchSearchTransaction(data),
        onSuccess(data) {
            const page = Number(data.body.currentPage);
            if (page === SearchEnum.FirstPage) {
                setCustomerList([])
                setLastRowNumber(SearchEnum.LimitRecord);
            }
    
            const resMap = data.body.custList.map((data, index) => ({
                ...data,
                key: (page === SearchEnum.FirstPage ? 0 : lastRowNumber) + index + 1,
                rowNumber: (page === SearchEnum.FirstPage ? 0 : lastRowNumber) + index + 1
            }));
    
            if (page !== SearchEnum.FirstPage) {
                setLastRowNumber(lastRowNumber + resMap.length);
            }
            if (data.body.custList.length > 0) {
                setCustomerList((p) => [...p, ...resMap]);
                setCurrentPage(page);
    
                if (data.body.currentPage === data.body.totalPage) {
                    setHasMore(true);
                    setLoading(false);
                } else {
                    setHasMore(false);
                }
    
                setTotalRecord(Number(data.body.totalRecord));
            } else {
                setHasMore(false);
            }
            setLoading(false);
        }
    }); 

    useEffect(() => {
        console.log("setCurrentRecord");
        setCurrentRecord(customerList.length);
        //getAllbranch();
        setStartDate(dateBack);
        setEndDate(dateMax);
    }, [customerList]);



    const handleChangeBranch = (event: any) => {
        const isDisableBranchNo = event != "";
        //form.setFieldsValue({ breachCode: event });
        console.log(event);
        setIsDisableSearchBtn(event === "");
        setBranch(event);
    }

    const handleChangeTransStatus = (event: any) => {
        setTransStatus(event);
    }

    const handleChangeSendDocument = (event: any) => {
        setSendDocument(event);
    }

    const handleChangeFatcaStatus = (event: any) => {
        setFatcaStatus(event);
    }

    const handleChangeTransactionDate = (event: any) => {
        const start_Date = new Date(event[0].format());
        const end_Date = new Date(event[1].format());
        setStartDate(start_Date.getFullYear()+'-'+('0' + (start_Date.getMonth()+1)).slice(-2)+'-'+('0' + start_Date.getDate()).slice(-2));
        setEndDate(end_Date.getFullYear()+'-'+('0' + (end_Date.getMonth()+1)).slice(-2)+'-'+('0' + end_Date.getDate()).slice(-2));

    }

    const callbackCustomerSelected = (customerList: CustomerType[]) => {
        setCustomerSelectedList(customerList);

    }

    const handlePrintCustomer = async () => {
        generatePDF(customerSelectedList)
        
    }

    const handlePrintCoverPage = async () => {
        const headerType : HeaderType = {
            reportType: "",
            brancdCode: branchCover,
            customerList: customerSelectedList
        } 
        generateCoverPDF(headerType);
        
    }

    return (
        <div>
            <Form
                name="wrap"
                labelCol={{ flex: '200px' }}
                labelAlign="left"
            >
                <Row gutter={24}>
                    <Col span={12}>
                        <Form.Item name={"breachCode"} label={"Branch No./OC Code"} rules={[{ required: true }]}>
                        <Select
                                showSearch
                                placeholder="Please Select"
                                optionFilterProp="children"
                                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                options={allBranchList}
                                defaultValue={{key: branch,value: branch}}
                                onChange={(e) => handleChangeBranch(e)}
                            />
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={24}>
                    <Col span={12}>
                        <Form.Item label={"Transection Date"} rules={[{ required: true }]}>
                        <DatePicker.RangePicker defaultValue={[dayjs(dateBack, dateFormat), dayjs(dateMax, dateFormat)]} format="YYYY-MM-DD" style={{ width: '100%' }} maxDate={dayjs(dateMax,dateFormat)} minDate={dayjs(dateMin,dateFormat)} onChange={(e) => handleChangeTransactionDate(e)}/>
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item label={"Transection Status"} rules={[{ required: true }]}>
                            <Select defaultValue={{key: "0000",value: transStatus}} onChange={(e) => handleChangeTransStatus(e)}>
                                <Select.Option key={"9999"} value={""}>All</Select.Option>
                                <Select.Option key={"0000"} value={"A"}>Active</Select.Option>
                                <Select.Option key={"0001"} value={"D"}>Delete</Select.Option>
                            </Select>
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={24}>
                    <Col span={12}>
                        <Form.Item label={"Send Document Status"} rules={[{ required: true }]}>
                            <Select defaultValue={{key: "0001",value: sendDocument}} onChange={(e) => handleChangeSendDocument(e)}>
                                <Select.Option key={"0000"} value={"Y"}>Yes</Select.Option>
                                <Select.Option key={"0001"} value={"N"}>No</Select.Option>
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item label={"FATCA Status"} rules={[{ required: true }]}>
                            <Select defaultValue={{key: "0000",value: fatcaStatus}} onChange={(e) => handleChangeFatcaStatus(e)}>
                                <Select.Option key={"0000"} value={"Y"}>Indicia</Select.Option>
                                <Select.Option key={"0001"} value={"N"}>No Indicia</Select.Option>
                            </Select>
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={24}>
                    <Col span={24}>
                        <Space style={{ width: "100%", justifyContent: "right" }}>
                            <Row gutter={24}>
                                <Col span={24}>
                                <Button type="primary" htmlType="submit" disabled={isDisableSearchBtn} onClick={handleSearch} style={{ width: 100, justifyContent: "center" }}>Search</Button>
                                </Col>
                            </Row>
                        </Space>
                    </Col>
                </Row>
                <TransectionTableForm dataList={customerList} customerList={callbackCustomerSelected} />
                <Row gutter={24} style={{ marginTop: 16 }}>
                    <Col span={12}>
                        {loading && <Spin />}<Button type="primary" onClick={handleLoadMore} disabled={hasMore}> {loading ? 'Loading...' : 'Load More'} </Button>
                        <span style={{ marginLeft: 16 }}>{currentRecord} of {totalRecord} Records</span>
                    </Col>
                    <Col span={12}>
                        <Space style={{ width: "100%", justifyContent: "right" }}>
                            <Row gutter={24}>
                                <Col span={24} >
                                    <Button type="primary" htmlType="submit" onClick={handlePrintCustomer} style={{ marginRight: 5 }}>Print Customer</Button>
                                    <Button type="primary" htmlType="submit" onClick={handlePrintCoverPage} style={{ marginLeft: 5 }}>Print Cover Page</Button> 
                                </Col>
                            </Row>
                        </Space>
                    </Col>
                </Row>
            </Form>
        </div>
    );
}

export default SearchTransactionForm;