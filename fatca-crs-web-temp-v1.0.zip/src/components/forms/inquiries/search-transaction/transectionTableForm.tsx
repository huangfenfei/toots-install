import React, { useEffect, useState } from "react";
import { Button, Space, Table } from "antd";
import { ColumnsType } from "antd/es/table";
import { BiEdit, BiPrinter, BiSearch, BiTrash } from "react-icons/bi";
import { PermissionReduxComponent } from "../../../reduxes/permission";
import { DeliveryCustomerReportPage } from "../../../reports/deliveryCustomerReport";
import { CustomerType } from "../../../../interface/searchType";
import { PermissionEnum } from "../../../../utils/constantEnum";

const TransectionTableForm = ({ dataList, customerList }) => {
  const { hasPermission } = PermissionReduxComponent();
  const { generatePDF } = DeliveryCustomerReportPage();
  
  const [isDisableViewBtn, setIsDisableViewBtn] = useState(false);
  const [isDisableEditBtn, setIsDisableEditBtn] = useState(false);
  const [isDisableDeleteBtn, setIsDisableDeleteBtn] = useState(false);
  const [isDisablePrintBtn, setIsDisablePrintBtn] = useState(false);
  const [select, setSelect] = useState({
    selectedRowKeys: [],
    selectedRows: []
  });

  const { selectedRowKeys, selectedRows } = select;

  useEffect(() => {
    setIsDisableViewBtn(!hasPermission(PermissionEnum.Search));
    setIsDisableEditBtn(!hasPermission(PermissionEnum.Update));
    setIsDisableDeleteBtn(!hasPermission(PermissionEnum.Print));
    setIsDisablePrintBtn(!hasPermission(PermissionEnum.Print));
  }, []);

  const handleView = (data: CustomerType) => {

  };

  const handleEdit = (data: CustomerType) => {

  };

  const handleDelete = (data: CustomerType) => {

  };

  const handlePrint = async (data: any) => {
    await generatePDF([data]);
  }

  const rowSelection = {
    selectedRowKeys,
    onChange: (selectedRowKeys, selectedRows) => {

      setSelect({
        ...select,
        selectedRowKeys: selectedRowKeys,
        selectedRows: selectedRows
      });
    }
  };

  useEffect(() => {
    customerList(select.selectedRows);
    if (select.selectedRows.length > 1) {
      setIsDisableViewBtn(true);
      setIsDisableEditBtn(true);
      setIsDisableDeleteBtn(true);
      setIsDisablePrintBtn(true);
    } else {
      setIsDisableViewBtn(!hasPermission(PermissionEnum.Search));
      setIsDisableEditBtn(!hasPermission(PermissionEnum.Update));
      setIsDisableDeleteBtn(!hasPermission(PermissionEnum.Print));
      setIsDisablePrintBtn(!hasPermission(PermissionEnum.Print));
    }
  }, [select]);

  const defaultColumns: ColumnsType<any> = [
    {
      title: "No.",
      dataIndex: "rowNumber",
      align: "center",
      width: 80,
      fixed: "left",
    },
    {
      title: "ID Number",
      dataIndex: "idNum",
      align: "left",
      width: 200,
    },
    {
      title: "ID Type",
      dataIndex: "idType",
      align: "center",
      width: 200,
    },
    {
      title: "Customer Name",
      dataIndex: "customerName",
      align: "left",
      width: 200,
    },
    {
      title: "RM ID",
      dataIndex: "rmId",
      align: "center",
      width: 200,
    },
    {
      title: "Transaction Date",
      dataIndex: "lastUpdateDate",
      align: "center",
      width: 200,
    },
    {
      title: "Fatca Status",
      dataIndex: "fatcaStatus",
      align: "center",
      width: 200,
    },
    {
      title: "IRS Document",
      dataIndex: "IRSDoc",
      align: "center",
      width: 200,
    },
    {
      title: "Document Support",
      dataIndex: "docSupport",
      align: "center",
      width: 200,
    },
    {
      title: "Transaction Status",
      dataIndex: "transactionStatus",
      align: "center",
      width: 200,
    },
    {
      title: "User Entry",
      dataIndex: "userEntry",
      align: "center",
      width: 200,
    },
    {
      title: "Branch No./OC Code",
      dataIndex: "branch",
      align: "center",
      width: 200,
    },
    {
      title: "Send Doc Date",
      dataIndex: "sendDocDate",
      align: "center",
      width: 200,
    },
    {
      title: "HO Receive Status",
      dataIndex: "hoReceiveStatus",
      align: "center",
      width: 200,
    },
    {
      title: "Ho Receive Date",
      dataIndex: "HOReceiveDate",
      align: "center",
      width: 200,
    },
    {
      title: "Ho Remark",
      dataIndex: "HORemark",
      align: "center",
      width: 300,
    },
    {
      title: "Action",
      dataIndex: "operation",
      align: "center",
      width: 150,
      fixed: "right",
      render: (text, record: CustomerType) => (
        <div>
          <Space style={{ gap: 0 }}>
            <Button type="text" onClick={() => handleView(record)} disabled={isDisableViewBtn} style={{ paddingLeft: 3, paddingRight: 3 }}>
              <BiSearch size={20} />
            </Button>
            <Button type="text" onClick={() => handleEdit(record)} disabled={isDisableEditBtn} style={{ paddingLeft: 3, paddingRight: 3 }}>
              <BiEdit size={20} />
            </Button>
            <Button type="text" onClick={() => handleDelete(record)} disabled={isDisableDeleteBtn} style={{ paddingLeft: 3, paddingRight: 3 }}>
              <BiTrash size={20} />
            </Button>
            <Button type="text" onClick={() => handlePrint(record)} disabled={isDisablePrintBtn} style={{ paddingLeft: 3, paddingRight: 3 }} >
              <BiPrinter size={20} />
            </Button>
          </Space>
        </div>
      ),
    },
  ];

  return (
    <div>
      <Table
        rowSelection={rowSelection}
        pagination={false}
        dataSource={dataList}
        columns={defaultColumns}
        scroll={{ x: 3500, y: 'calc(100vh - 500px)' }}
      />
    </div>
  );
}

export default TransectionTableForm;