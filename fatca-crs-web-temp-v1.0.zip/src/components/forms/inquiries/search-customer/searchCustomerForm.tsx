import React, { useEffect, useState } from "react";
import { Button, Col, Form, Input, Row, Select, Space, Spin } from "antd";
import CustomerTableForm from "./customerTableForm";
import { useSelector } from "react-redux";
import { DropdownType } from "../../../../interface/masterType";
import { fetchSearchCustomer } from "../../../../services/search/searchCustomerService";
import { useMutation } from "@tanstack/react-query";
import { CustomerType } from "../../../../interface/searchType";
import { DeliveryCustomerReportPage } from "../../../reports/deliveryCustomerReport";
import { SearchEnum } from "../../../../utils/constantEnum";
import { RootState } from "../../../../redux/store/store";

const SearchCustomerForm = () => {
    const [form] = Form.useForm();
    const idTypeIndividualList: DropdownType[] = useSelector((state: RootState) => state.idTypeIndividualReducer);

    const [isDisableIdNumber, setIsDisableIdNumber] = useState(false);
    const [isDisableCustomerName, setIsDisableCustomerName] = useState(false);
    const [isDisableTinNumber, setIsDisableTinNumber] = useState(false);
    const [isDisableSearchBtn, setIsDisableSearchBtn] = useState(true);

    const [customerList, setCustomerList] = useState<CustomerType[]>([]);
    const [customerSelectedList, setCustomerSelectedList] = useState<CustomerType[]>([]);
    const [loading, setLoading] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [currentRecord, setCurrentRecord] = useState(0);
    const [totalRecord, setTotalRecord] = useState(0);

    const [hasMore, setHasMore] = useState(true);
    const [lastRowNumber, setLastRowNumber] = useState(0);

    const { generatePDF } = DeliveryCustomerReportPage();

    useEffect(() => {
        form.setFieldsValue({ idType: "" });
    }, []);

    const handleSearch = () => {
        fetchData(SearchEnum.FIRST_PAGE);
    };

    const handleLoadMore = () => {
        fetchData(currentPage + SearchEnum.FIRST_PAGE);
    };

    const fetchData = async (page) => {
        setLoading(true);
        const body = {
            page: page,
            limit: SearchEnum.LIMIT_RECORD,
            idType_cd: form.getFieldValue("idType"),
            idNo: form.getFieldValue("idNumber"),
            customerName: form.getFieldValue("customerName"),
            TIN: form.getFieldValue("tinNumber")
        }
        fetch.mutate(body);
    };

    const fetch = useMutation({
        mutationFn: (data: any) => fetchSearchCustomer(data),
        onSuccess(data) {
            const page = Number(data.body.currentPage);
            if (page === SearchEnum.FIRST_PAGE) {
                setCustomerList([])
                setLastRowNumber(SearchEnum.LIMIT_RECORD);
            }
    
            const resMap = data.body.custList.map((data, index) => ({
                ...data,
                key: (page === SearchEnum.FIRST_PAGE ? 0 : lastRowNumber) + index + 1,
                rowNumber: (page === SearchEnum.FIRST_PAGE ? 0 : lastRowNumber) + index + 1
            }));
    
            if (page !== SearchEnum.FIRST_PAGE) {
                setLastRowNumber(lastRowNumber + resMap.length);
            }
            if (data.body.custList.length > 0) {
                setCustomerList((p) => [...p, ...resMap]);
                setCurrentPage(page);
    
                if (data.body.currentPage === data.body.totalPage) {
                    setHasMore(true);
                    setLoading(false);
                } else {
                    setHasMore(false);
                }
    
                setTotalRecord(Number(data.body.totalRecord));
            } else {
                setHasMore(false);
            }
            setLoading(false);
        }
    });  

    useEffect(() => {
        setCurrentRecord(customerList.length);
    }, [customerList]);

    const handleChangeIdType = (event: any) => {
        const isDisableIdType = event != "";
        setIsDisableCustomerName(isDisableIdType);
        setIsDisableTinNumber(isDisableIdType);
        form.setFieldsValue({ customerName: "" });
        form.setFieldsValue({ tinNumber: "" });
    }

    const handleChangeIdNumber = (event: any) => {
        setIsDisableSearchBtn(event.target.value === "");
    }

    const handleChangeCustomerName = (event: any) => {
        setIsDisableSearchBtn(event.target.value === "" && form.getFieldValue("tinNumber") === "");
    }

    const handleChangeTinNumber = (event: any) => {
        setIsDisableSearchBtn(event.target.value === "" && form.getFieldValue("customerName") === "");
    }

    const callbackCustomerSelected = (customerList: CustomerType[]) => {
        setCustomerSelectedList(customerList);
    }

    const handlePrintCustomer = () => {
        generatePDF(customerSelectedList)
    }

    const handlePrintCoverPage = () => {

    }

    return (
        <div>
            <Form form={form} name="wrap" labelCol={{ flex: '200px' }} labelAlign="left">
                <Row gutter={24}>
                    <Col span={12}>
                        <Form.Item name={"idType"} label={"ID Type"}>
                            <Select
                                showSearch
                                placeholder="Please Select"
                                optionFilterProp="children"
                                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                options={idTypeIndividualList}
                                onChange={(e) => handleChangeIdType(e)}
                            />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item name={"idNumber"} label={"ID Number"} >
                            <Input maxLength={100} disabled={isDisableIdNumber} onChange={(e) => handleChangeIdNumber(e)}></Input>
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={24}>
                    <Col span={12}>
                        <Form.Item name={"customerName"} label={"Customer Name"}>
                            <Input maxLength={100} disabled={isDisableCustomerName} onChange={(e) => handleChangeCustomerName(e)}></Input>
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={24}>
                    <Col span={12}>
                        <Form.Item name={"tinNumber"} label={"TIN Number"}>
                            <Input maxLength={100} disabled={isDisableTinNumber} onChange={(e) => handleChangeTinNumber(e)}></Input>
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Space style={{ width: "100%", justifyContent: "right" }}>
                            <Row gutter={24}>
                                <Col span={24}>
                                    <Button type="primary" htmlType="submit" disabled={isDisableSearchBtn} onClick={handleSearch} style={{ width: 100, justifyContent: "center" }}>Search</Button>
                                </Col>
                            </Row>
                        </Space>
                    </Col>
                </Row>
                <CustomerTableForm dataList={customerList} customerList={callbackCustomerSelected} />
                <Row gutter={24} style={{ marginTop: 16 }}>
                    <Col span={12}>
                        {loading && <Spin />}<Button type="primary" onClick={handleLoadMore} disabled={hasMore}> {loading ? 'Loading...' : 'Load More'} </Button>
                        <span style={{ marginLeft: 16 }}>{currentRecord} of {totalRecord} Records</span>
                    </Col>
                    <Col span={12}>
                        <Space style={{ width: "100%", justifyContent: "right" }}>
                            <Row gutter={24}>
                                <Col span={24} >
                                    <Button type="primary" htmlType="submit" onClick={handlePrintCustomer} style={{ marginRight: 5 }}>Print Customer</Button>
                                    {/* <Button type="primary" htmlType="submit" onClick={handlePrintCoverPage} style={{ marginLeft: 5 }}>Print Cover Page</Button> */}
                                </Col>
                            </Row>
                        </Space>
                    </Col>
                </Row>

            </Form>
        </div>
    );
}

export default SearchCustomerForm;
