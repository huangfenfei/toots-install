import React, { useEffect, useState } from "react";
import { Button, Col, Form, Row, Space, Spin } from "antd";
import IndividualCustomerInfoForm from "./indiCustomerInfoForm";
import IndividualFatcaCheckListForm from "./indiFatcaChecklistForm";
import IndividualCRSCheckListForm from "./indiCrsChecklistForm";
import IRSDocumentW9Form from "../common/irsDocumentW9Form";
import IRSDocumentW8Form from "../common/irsDocumentW8Form";
import ForeignTINTableForm from "../common/foreignTinTableForm";
import IndividualStatusOfCustomerForm from "./indiStatusOfCustomerForm";
import { useMutation } from "@tanstack/react-query";
import { saveIndivedual } from "../../../../services/fatca-crs/individual";
import { convertEmptyUndefined, convertYNUndefined } from "../../../../utils/constantFunc";
import WarningModal from "../../../modals/warningModal";
import SuccessModal from "../../../modals/successModal";
import { getUsernameStorage } from "../../../../storages/usernameStorage";
import { getOcCodeStorage } from "../../../../storages/ocCodeStorage";
import { ResponseCodeEnum } from "../../../../utils/constantEnum";
import { AdditionalQType, CountryTaxType, CRSCheckListType, CustomerInfoType, FatcaCheckListType, IndividualType, IRSDocumentType, USPersonType, W9Type } from "../../../../interface/individualType";

const IndividualTabForm = ({ tab }: { tab: string }) => {
  const [form] = Form.useForm();
  const [fatcaStatus, setFatcaStatus] = useState("");
  const [crsStatus, setCrsStatus] = useState("");
  const [stateOfCustomer, setStateOfCustomer] = useState("0");
  const [countryTax, setCountryTax] = useState([]);
  const [isOpenWarningModal, setIsOpenWarningModal] = useState(false);
  const [isOpenSuccessModal, setIsOpenSuccessModal] = useState(false);
  const [msgWarningModal, setMsgWarningModal] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    form.resetFields();
    setAllFieldsEmpty();
  }, [tab]);

  const setAllFieldsEmpty = () => {
    const fields = form.getFieldsValue();
    const emptyFields = Object.keys(fields).reduce((acc, key) => {
      acc[key] = '';
      return acc;
    }, {});
    form.setFieldsValue(emptyFields);
  };

  const callbackFatcaStatue = (status: string) => {
    setFatcaStatus(status);
    setStateOfCustomer("0");
  }

  const callbackCrsStatus = (status: string) => {
    setCrsStatus(status);
  }

  const callbackStateOfCustomer = (state: string) => {
    setStateOfCustomer(state);
  }

  const callbackSave = (data: any) => {
    console.log("callbackSave.fatcaStatus ==>", fatcaStatus);
    console.log("callbackSave.crsStatus ==>", crsStatus);
    if (fatcaStatus === "") {
      setIsOpenWarningModal(true);
      setMsgWarningModal("Plase select Fatca Checklist");
      return;
    }

    if (crsStatus === "") {
      setIsOpenWarningModal(true);
      setMsgWarningModal("Plase select CRS Checklist");
      return;
    }

    // const body = {
    //   userEntry: getUsernameStorage(),
    //   entryBrNo: getOcCodeStorage(),
    //   customerInfo: {
    //     idType_cd: convertEmptyUndefined(data.custInfoIdTypeCode),
    //     idNum: convertEmptyUndefined(data.custInfoIdNumber),
    //     title_cd: convertEmptyUndefined(data.custInfoTitleCode),
    //     firstName: convertEmptyUndefined(data.custInfoFirstName),
    //     lastName: convertEmptyUndefined(data.custInfoLastName),
    //     middleName: convertEmptyUndefined(data.custInfoMiddleName),
    //     nationality_cd: convertEmptyUndefined(data.custInfoNationalityCode),
    //     brNo: convertEmptyUndefined(data.custInfoBranchNo),
    //     countryOfBirth_cd: convertEmptyUndefined(data.custInfoCountryOfBirthCode),
    //     cityOfBirth: convertEmptyUndefined(data.custInfoCityOfBirth),
    //     FATCAChkList: {
    //       indicia: convertEmptyUndefined(data.indiciaStatus),
    //       USPerson: {
    //         isCitizen: convertYNUndefined(data.usPersonIsCitizen),
    //         isGreenCard: convertYNUndefined(data.usPersonIsGreenCard),
    //         isResident: convertYNUndefined(data.usPersonIsResident),
    //       },
    //       additionalQ: {
    //         surrendered: convertYNUndefined(data.additionalQSurrendered),
    //         ftToUS: convertYNUndefined(data.additionalQFtToUS),
    //         POA: convertYNUndefined(data.additionalQPOA),
    //         holdMail: convertYNUndefined(data.additionalQHoldMail),
    //         USAddress: convertYNUndefined(data.additionalQusAddress),
    //         USPhNo: convertYNUndefined(data.additionalQusPhoneNumber),
    //       },
    //       IRSDoc: {
    //         w8Ben: convertEmptyUndefined(data.irsDocw8Ben),
    //         w9: {
    //           name: convertEmptyUndefined(data.irsDocW9Name),
    //           taxClass_cd: convertEmptyUndefined(data.irsDocW9TaxClassCode),
    //           exemptPayee_cd: convertEmptyUndefined(data.irsDocW9ExemptPayeeCode),
    //           exemptFromFatcaReport_cd: convertEmptyUndefined(data.irsDocW9ReportingCode),
    //           address: convertEmptyUndefined(data.irsDocW9Address),
    //           city: convertEmptyUndefined(data.irsDocW9City),
    //           state: convertEmptyUndefined(data.indiciaStatus),
    //           zip: convertEmptyUndefined(data.irsDocW9ZipCode),
    //           SSN: convertEmptyUndefined(data.irsDocW9SSN1) + "-" + convertEmptyUndefined(data.irsDocW9SSN2) + "-" + convertEmptyUndefined(data.irsDocW9SSN3),
    //         }
    //       }
    //     }
    //   },
    //   CRSCkList: {
    //     crs: data.crsStatus,
    //     countryTax: countryTax
    //   }
    // }

    let countryTaxModelList: CountryTaxType[] = [];
    countryTax.forEach((it2) => {
      const ctpModel: CountryTaxType = {
        country_cd: it2.country_cd,
        TIN: it2.TIN,
        reason_cd: it2.reason_cd,
        reason: it2.reasonDetail
      }
      countryTaxModelList.push(ctpModel);
    });

    const crsCheckList: CRSCheckListType = {
      crs: data.crsStatus,
      countryTax: countryTaxModelList,
    }

    const w9Model: W9Type = {
      name: convertEmptyUndefined(data.irsDocW9Name),
      taxClass_cd: convertEmptyUndefined(data.irsDocW9TaxClassCode),
      exemptPayee_cd: convertEmptyUndefined(data.irsDocW9ExemptPayeeCode),
      exemptFromFatcaReport_cd: convertEmptyUndefined(data.irsDocW9ReportingCode),
      address: convertEmptyUndefined(data.irsDocW9Address),
      city: convertEmptyUndefined(data.irsDocW9City),
      state: convertEmptyUndefined(data.indiciaStatus),
      zip: convertEmptyUndefined(data.irsDocW9ZipCode),
      SSN: convertEmptyUndefined(data.irsDocW9SSN1) + convertEmptyUndefined(data.irsDocW9SSN2) + convertEmptyUndefined(data.irsDocW9SSN3),
    }

    const irsDocModel: IRSDocumentType = {
      w8Ben: data.indiciaStatus === "Y" && stateOfCustomer === "1" ? convertEmptyUndefined(data.irsDocw8Ben) : null,
      w9: data.indiciaStatus === "Y" && stateOfCustomer === "2" ? w9Model : null,
    }

    const additionalQModel: AdditionalQType = {
      surrendered: convertYNUndefined(data.additionalQSurrendered),
      ftToUS: convertYNUndefined(data.additionalQFtToUS),
      POA: convertYNUndefined(data.additionalQPOA),
      holdMail: convertYNUndefined(data.additionalQHoldMail),
      USAddress: convertYNUndefined(data.additionalQusAddress),
      USPhNo: convertYNUndefined(data.additionalQusPhoneNumber),
    }

    const usPersonModel: USPersonType = {
      isCitizen: convertYNUndefined(data.usPersonIsCitizen),
      isGreenCard: convertYNUndefined(data.usPersonIsGreenCard),
      isResident: convertYNUndefined(data.usPersonIsResident),
    }

    const fatcaCheckListModel: FatcaCheckListType = {
      indicia: convertEmptyUndefined(data.indiciaStatus),
      USPerson: usPersonModel,
      additionalQ: additionalQModel,
      IRSDoc: data.indiciaStatus === "Y" ? irsDocModel : null,
    }

    const custInfoModel: CustomerInfoType = {
      idType_cd: convertEmptyUndefined(data.custInfoIdTypeCode),
      idNum: convertEmptyUndefined(data.custInfoIdNumber),
      title_cd: convertEmptyUndefined(data.custInfoTitleCode),
      firstName: convertEmptyUndefined(data.custInfoFirstName),
      lastName: convertEmptyUndefined(data.custInfoLastName),
      middleName: convertEmptyUndefined(data.custInfoMiddleName),
      nationality_cd: convertEmptyUndefined(data.custInfoNationalityCode),
      brNo: convertEmptyUndefined(data.custInfoBranchNo),
      countryOfBirth_cd: convertEmptyUndefined(data.custInfoCountryOfBirthCode),
      cityOfBirth: convertEmptyUndefined(data.custInfoCityOfBirth),
      FATCAChkList: fatcaCheckListModel
    }

    const bodys: IndividualType = {
      userEntry: getUsernameStorage(),
      entryBrNo: getOcCodeStorage(),
      customerInfo: custInfoModel,
      CRSCkList: crsCheckList
    }

    setLoading(true);
    console.log("callbackSave.body ==>", bodys);
    saveIndivedualMutation.mutate(bodys);
  }

  const handleSave = () => {
    form.submit();
  }

  const saveIndivedualMutation = useMutation({
    mutationFn: (data: any) => saveIndivedual(data),
    onSuccess(res) {
      console.log("saveIndivedualMutation ==>", res);
      setLoading(false);
      if (res.respCode === ResponseCodeEnum.SUCCESS) {
        setIsOpenSuccessModal(true);
      } else {
        setIsOpenWarningModal(true);
        setMsgWarningModal(res.respCode + " : " + res.respDesc);
      }
    }
  });

  const handleWarningModalOK = () => {
    setIsOpenWarningModal(false);
  }

  const handleSuccessModalOK = () => {
    setIsOpenSuccessModal(false);
  }

  return (
    <div>
      <Spin spinning={loading}>
        <IndividualCustomerInfoForm form={form} onFinish={callbackSave} />
        <IndividualFatcaCheckListForm form={form} onFinish={callbackSave} onIndiciaStatus={callbackFatcaStatue} />
        {fatcaStatus === "Y" ? <IndividualStatusOfCustomerForm form={form} onFinish={callbackSave} stateOfCustomer={callbackStateOfCustomer} /> : null}
        {stateOfCustomer === "1" ? <IRSDocumentW8Form form={form} onFinish={callbackSave} formName={"W-8 BEN"} /> : null}
        {stateOfCustomer === "2" ? <IRSDocumentW9Form form={form} onFinish={callbackSave} isVisible={stateOfCustomer} customerType={"individual"} /> : null}
        <IndividualCRSCheckListForm form={form} onFinish={callbackSave} crsStatus={callbackCrsStatus} />
        {crsStatus === "Y" ? <ForeignTINTableForm form={form} onFinish={callbackSave} data={countryTax} onCallback={setCountryTax} titleName={"Part2 - CRS Individual Self - Certification"} /> : null}
        <WarningModal isModalOpen={isOpenWarningModal} handleMessage={msgWarningModal} handleOk={handleWarningModalOK} />
        <SuccessModal isModalOpen={isOpenSuccessModal} handleMessage={"Save Fatca & CRS Success!"} handleOk={handleSuccessModalOK} />

        <Space style={{ marginTop: 20, marginBottom: 30, width: "100%", justifyContent: "right" }}>
          <Row gutter={24}>
            <Col span={24}>
              <Button type="default" style={{ width: 100, justifyContent: "center", marginRight: 15 }}>Cancel</Button>
              <Button type="primary" onClick={handleSave} htmlType="submit" style={{ width: 100, justifyContent: "center" }}>Save</Button>
            </Col>
          </Row>
        </Space>
      </Spin>
    </div>
  );
};

export default IndividualTabForm;
