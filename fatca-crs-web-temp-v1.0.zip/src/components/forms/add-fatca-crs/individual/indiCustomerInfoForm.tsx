import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import { Col, Form, Row, Select, Input, FormInstance } from "antd";
import { DropdownType } from "../../../../interface/masterType";
import { RootState } from "../../../../redux/store/store";
import { BrancheType } from "../../../../interface/branchType";
import { validateThaiCitizenId, validatePassport } from "../../../../utils/constantFunc";
import { ErrorMessageEnum, IdTypeEnum } from "../../../../utils/constantEnum";
import FormLabelCustomized from "../../../customs/formLabelCustomized";

const validateIdNumber = (form: FormInstance) => ({
  validator(_: any, value: string) {
    const idType = form.getFieldValue("custInfoIdTypeCode");
    if (idType === IdTypeEnum.CITIZEN_ID) {
      const isCitizenId = validateThaiCitizenId(value);
      if (isCitizenId) {
        Promise.resolve();
      } else {
        return Promise.reject(new Error(ErrorMessageEnum.VALID_CITIZEN_ID_ERR));
      }
    } else if (idType === IdTypeEnum.PASSPORT) {
      const isPassport = validatePassport(value, form.getFieldValue("custInfoNationalityCode"));
      if (isPassport) {
        Promise.resolve();
      } else {
        return Promise.reject(new Error(ErrorMessageEnum.VALID_PASSPORT_ERR));
      }
    }
    return Promise.resolve();
  }
});

const IndividualCustomerInfoForm = ({ form, onFinish }: { form: FormInstance, onFinish: any }) => {
  const idTypeIndividualList: DropdownType[] = useSelector((state: RootState) => state.idTypeIndividualReducer);
  const titleIndividualList: DropdownType[] = useSelector((state: RootState) => state.titleIndividualReducer);
  const allBranchList: BrancheType[] = useSelector((state: RootState) => state.allBranchReducer);
  const nationalityList: DropdownType[] = useSelector((state: RootState) => state.nationalityReducer);
  const countryOfBirthList: DropdownType[] = useSelector((state: RootState) => state.countryOfBirthReducer);

  useEffect(() => {
    form.setFieldsValue({
      custInfoIdTypeCode: "",
      custInfoTitleCode: "",
      custInfoNationalityCode: "",
      custInfoBranchNo: "",
      custInfoCountryOfBirthCode: "",
    });
  }, []);

  const onFinishFail = (e: any) => {
    console.log("onFinishFail ==>", e);
  }

  return (
    <div style={{ marginTop: 0, marginBottom: 0 }}>
      <Form form={form} onFinish={onFinish} onFinishFailed={onFinishFail} labelCol={{ flex: '200px' }} labelAlign="left">
        <Row gutter={24}>
          <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
            {/* <Form.Item name={["custInfoIdTypeCode"]} label={"Identification Type"} rules={[{ required: true }]}> */}
            <Form.Item
              name={["custInfoIdTypeCode"]}
              label={<FormLabelCustomized label={"Identification Type"} required={true} />}
              rules={[{ required: true, message: "Please select Identification Type!" }]}
              required={false}
            >
              <Select
                showSearch
                placeholder="Please Select"
                optionFilterProp="children"
                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                options={idTypeIndividualList}
              />
            </Form.Item>
          </Col>
          <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
            {/* <Form.Item name={["custInfoIdNumber"]} label={"Identification Number"} dependencies={["custInfoIdTypeCode"]} rules={[
              {
                required: true,
              },
              validateIdNumber(form)
            ]}> */}
            <Form.Item
              name={["custInfoIdNumber"]}
              label={<FormLabelCustomized label={"Identification Number"} required={true} />}
              rules={[{ required: true, message: "" }, validateIdNumber(form)]}
              required={false}
            >
              <Input maxLength={50}></Input>
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={24}>
          <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
            {/* <Form.Item name={["custInfoTitleCode"]} label={"Title"} rules={[{ required: true }]}> */}
            <Form.Item
              name={["custInfoTitleCode"]}
              label={<FormLabelCustomized label={"Title"} required={true} />}
              rules={[{ required: true, message: "Please select Title!" }]}
              required={false}
            >
              <Select
                showSearch
                placeholder="Please Select"
                optionFilterProp="children"
                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                options={titleIndividualList}
              />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={24}>
          <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
            {/* <Form.Item name={["custInfoFirstName"]} label={"First Name"} rules={[{ required: true }]}> */}
            <Form.Item
              name={["custInfoFirstName"]}
              label={<FormLabelCustomized label={"First Name"} required={true} />}
              rules={[{ required: true, message: "Please input First Name!" }]}
              required={false}
            >
              <Input maxLength={50}></Input>
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={24}>
          <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
            {/* <Form.Item name={["custInfoMiddleName"]} label={"Middle Name"} > */}
            <Form.Item
              name={["custInfoMiddleName"]}
              label={<FormLabelCustomized label={"Middle Name"} required={false} />}
              required={false}
            >
              <Input maxLength={50}></Input>
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={24}>
          <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
            {/* <Form.Item name={["custInfoLastName"]} label={"Last Name"} rules={[{ required: true }]}> */}
            <Form.Item
              name={["custInfoLastName"]}
              label={<FormLabelCustomized label={"Last Name"} required={true} />}
              rules={[{ required: true, message: "Please input Last Name!" }]}
              required={false}
            >
              <Input maxLength={50}></Input>
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={24}>
          <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
            {/* <Form.Item name={["custInfoNationalityCode"]} label={"Nationality"} rules={[{ required: true }]}> */}
            <Form.Item
              name={["custInfoNationalityCode"]}
              label={<FormLabelCustomized label={"Nationality"} required={true} />}
              rules={[{ required: true, message: "Please select Nationality!" }]}
              required={false}
            >
              <Select
                showSearch
                placeholder="Please Select"
                optionFilterProp="children"
                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                options={nationalityList}
              />
            </Form.Item>
          </Col>
          <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
            {/* <Form.Item name={["custInfoBranchNo"]} label={"Branch No./OC Code"} rules={[{ required: true }]}> */}
            <Form.Item
              name={["custInfoBranchNo"]}
              label={<FormLabelCustomized label={"Branch No./OC Code"} required={true} />}
              rules={[{ required: true, message: "Please select Branch No./OC Code!" }]}
              required={false}
            >
              <Select
                showSearch
                placeholder="Please Select"
                optionFilterProp="children"
                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                options={allBranchList}
              />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={24}>
          <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
            {/* <Form.Item name={["custInfoCountryOfBirthCode"]} label={"Country of Birth"} rules={[{ required: true }]}> */}
            <Form.Item
              name={["custInfoCountryOfBirthCode"]}
              label={<FormLabelCustomized label={"Country of Birth"} required={true} />}
              rules={[{ required: true, message: "Please select Country of Birth!" }]}
              required={false}
            >
              <Select
                showSearch
                placeholder="Please Select"
                optionFilterProp="children"
                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                options={countryOfBirthList}
              />
            </Form.Item>
          </Col>
          <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
            {/* <Form.Item name={["custInfoCityOfBirth"]} label={"City of Birth"}> */}
            <Form.Item
              name={["custInfoCityOfBirth"]}
              label={<FormLabelCustomized label={"City of Birth"} required={false} />}
              required={false}
            >
              <Input maxLength={100}></Input>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </div>
  );
};
export default IndividualCustomerInfoForm;
