import React, { useState } from "react";
import { Card, Col, Form, FormInstance, Radio, Row } from "antd";

const IndividualFatcaCheckListForm = ({ form, onFinish, onIndiciaStatus }: { form: FormInstance, onFinish: any, onIndiciaStatus: any }) => {

  const [indiciaStatus, setIndiciaStatus] = useState("");

  const handleCrsStatusChange = (indicia: string) => {
    onIndiciaStatus(indicia);
    setIndiciaStatus(indicia);
  }

  form.setFieldsValue({
    indiciaStatus: indiciaStatus
  });

  return (
    <div style={{ marginTop: 0, marginBottom: 0 }}>
      <span>
        <b>FATCA Checklist</b>
      </span>{" "}
      <span style={{ color: "#4F3793" }}>Natural Person</span>
      <Card>
        <Form form={form} onFinish={onFinish} labelCol={{ flex: '200px' }} labelAlign="left">
          <Form.Item name={["indiciaStatus"]} noStyle>
            <Radio.Group style={{ width: "100%" }}>
              <Row gutter={[8, 32]}>
                <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                  <Radio value={"Y"} onChange={() => handleCrsStatusChange("Y")}>Indicia (ลูกค้าตอบใช่ / Yes ข้อใดข้อหนึ่ง)</Radio>
                </Col>
                <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                  <Radio value={"N"} onChange={() => handleCrsStatusChange("N")}>No Indicia (ลูกค้าตอบไม่ใช่ / No ทุกข้อ)</Radio>
                </Col>
              </Row>
            </Radio.Group>
          </Form.Item>
        </Form>
      </Card>
    </div>
  );
};

export default IndividualFatcaCheckListForm;
