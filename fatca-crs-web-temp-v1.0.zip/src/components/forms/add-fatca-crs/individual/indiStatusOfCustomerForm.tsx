import React, { useEffect, useState } from "react";
import { Card, Checkbox, Col, Form, FormInstance, Radio, Row, Space } from "antd";

const IndividualStatusOfCustomerForm = ({ form, onFinish, stateOfCustomer }: { form: FormInstance, onFinish: any, stateOfCustomer: any }) => {

    const [customerStates, setCustomerStates] = useState("");
    const [isCheckUS1, setIsCheckUS1] = useState(false);
    const [isCheckUS2, setIsCheckUS2] = useState(false);
    const [isCheckUS3, setIsCheckUS3] = useState(false);
    const [isDisableUS1, setIsDisableUS1] = useState(true);
    const [isDisableUS2, setIsDisableUS2] = useState(true);
    const [isDisableUS3, setIsDisableUS3] = useState(true);

    const [isCheckAdd1, setIsCheckAdd1] = useState(false);
    const [isCheckAdd2, setIsCheckAdd2] = useState(false);
    const [isCheckAdd3, setIsCheckAdd3] = useState(false);
    const [isCheckAdd4, setIsCheckAdd4] = useState(false);
    const [isCheckAdd5, setIsCheckAdd5] = useState(false);
    const [isCheckAdd6, setIsCheckAdd6] = useState(false);
    const [isDisableAdd1, setIsDisableAdd1] = useState(true);
    const [isDisableAdd2, setIsDisableAdd2] = useState(true);
    const [isDisableAdd3, setIsDisableAdd3] = useState(true);
    const [isDisableAdd4, setIsDisableAdd4] = useState(true);
    const [isDisableAdd5, setIsDisableAdd5] = useState(true);
    const [isDisableAdd6, setIsDisableAdd6] = useState(true);

    const handleCustomerStateChange = (state: string) => {
        setCustomerStates(state);
        stateOfCustomer(state);
        setIsDisableUS1(state !== "1");
        setIsDisableUS2(state !== "1");
        setIsDisableUS3(state !== "1");
        setIsCheckUS1(false);
        setIsCheckUS2(false);
        setIsCheckUS3(false);

        setIsDisableAdd1(state !== "2");
        setIsDisableAdd2(state !== "2");
        setIsDisableAdd3(state !== "2");
        setIsDisableAdd4(state !== "2");
        setIsDisableAdd5(state !== "2");
        setIsDisableAdd6(state !== "2");
        setIsCheckAdd1(false);
        setIsCheckAdd2(false);
        setIsCheckAdd3(false);
        setIsCheckAdd4(false);
        setIsCheckAdd5(false);
        setIsCheckAdd6(false);
    }

    const handleUS1CheckboxChange = (e: any) => {
        setIsCheckUS1(e.target.checked);
    }

    const handleUS2CheckboxChange = (e: any) => {
        setIsCheckUS2(e.target.checked);
    }

    const handleUS3CheckboxChange = (e: any) => {
        setIsCheckUS3(e.target.checked);
    }

    const handleAdd1CheckboxChange = (e: any) => {
        setIsCheckAdd1(e.target.checked);
    }

    const handleAdd2CheckboxChange = (e: any) => {
        setIsCheckAdd2(e.target.checked);
    }

    const handleAdd3CheckboxChange = (e: any) => {
        setIsCheckAdd3(e.target.checked);
    }

    const handleAdd4CheckboxChange = (e: any) => {
        setIsCheckAdd4(e.target.checked);
    }

    const handleAdd5CheckboxChange = (e: any) => {
        setIsCheckAdd5(e.target.checked);
    }

    const handleAdd6CheckboxChange = (e: any) => {
        setIsCheckAdd6(e.target.checked);
    }

    form.setFieldsValue({
        customerState: customerStates,
        usPerson1: isCheckUS1 ? "Y" : "N",
        usPerson2: isCheckUS2 ? "Y" : "N",
        usPerson3: isCheckUS2 ? "Y" : "N",

        additionalQ1: isCheckAdd1 ? "Y" : "N",
        additionalQ2: isCheckAdd2 ? "Y" : "N",
        additionalQ3: isCheckAdd3 ? "Y" : "N",
        additionalQ4: isCheckAdd4 ? "Y" : "N",
        additionalQ5: isCheckAdd5 ? "Y" : "N",
        additionalQ6: isCheckAdd6 ? "Y" : "N",
        customerInfo: {
            FATCAChkList: {
                USPerson: {
                    isCitizen: isCheckUS1 ? "Y" : "N",
                    isGreenCard: isCheckUS2 ? "Y" : "N",
                    isResident: isCheckUS2 ? "Y" : "N",
                },
                additionalQ: {
                    surrendered: isCheckAdd1 ? "Y" : "N",
                    ftToUS: isCheckAdd2 ? "Y" : "N",
                    POA: isCheckAdd3 ? "Y" : "N",
                    holdMail: isCheckAdd4 ? "Y" : "N",
                    USAddress: isCheckAdd5 ? "Y" : "N",
                    USPhNo: isCheckAdd6 ? "Y" : "N",
                },
            }
        }
    });



    return (
        <div style={{ marginTop: 20, marginBottom: 20 }}>
            <span>
                <b>Part 1 - Status of Customer</b>
            </span>
            <br />
            <span style={{ fontSize: 12 }}>
                Please Check only the question that answer
                &quot;Yes&quot;/โปรดเลือกหัวข้อที่ลูกค้าตอบ &quot;ใช่&quot;
            </span>
            <Card>
                <Form form={form} onFinish={onFinish} labelCol={{ flex: '200px' }} labelAlign="left">
                    <Form.Item name={"customerState"} noStyle>
                        <Radio.Group style={{ width: "100%" }}>
                            <Row gutter={[8, 32]}>
                                <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                                    <Space direction="vertical">
                                        <Radio value={"1"} onChange={() => handleCustomerStateChange("1")}>US Person</Radio>
                                        <Form.Item name={["usPersonIsCitizen"]} noStyle>
                                            <Checkbox checked={isCheckUS1} disabled={isDisableUS1} onChange={handleUS1CheckboxChange} style={{ marginLeft: 30 }}>
                                                1) US Citizen / US Birth
                                            </Checkbox>
                                        </Form.Item>
                                        <Form.Item name={["usPersonIsGreenCard"]} noStyle>
                                            <Checkbox checked={isCheckUS2} disabled={isDisableUS2} onChange={handleUS2CheckboxChange} style={{ marginLeft: 30 }}>
                                                2) US Green Card
                                            </Checkbox>
                                        </Form.Item>
                                        <Form.Item name={["usPersonIsResident"]} noStyle>
                                            <Checkbox checked={isCheckUS3} disabled={isDisableUS3} onChange={handleUS3CheckboxChange} style={{ marginLeft: 30 }}>
                                                3) US Resident
                                            </Checkbox>
                                        </Form.Item>
                                    </Space>
                                </Col>
                                <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                                    <Space direction="vertical">
                                        <Radio value={"2"} onChange={() => handleCustomerStateChange("2")}>Additional Questions</Radio>
                                        <Form.Item name={["additionalQSurrendered"]} noStyle>
                                            <Checkbox checked={isCheckAdd1} disabled={isDisableAdd1} onChange={handleAdd1CheckboxChange} style={{ marginLeft: 30 }}>
                                                1) Born US but legally surrendered
                                            </Checkbox>
                                        </Form.Item>
                                        <Form.Item name={["additionalQFtToUS"]} noStyle>
                                            <Checkbox checked={isCheckAdd2} disabled={isDisableAdd2} onChange={handleAdd2CheckboxChange} style={{ marginLeft: 30 }}>
                                                2) Fund Transfer to US
                                            </Checkbox>
                                        </Form.Item>
                                        <Form.Item name={["additionalQPOA"]} noStyle>
                                            <Checkbox checked={isCheckAdd3} disabled={isDisableAdd3} onChange={handleAdd3CheckboxChange} style={{ marginLeft: 30 }}>
                                                3) POA
                                            </Checkbox>
                                        </Form.Item>
                                        <Form.Item name={["additionalQHoldMail"]} noStyle>
                                            <Checkbox checked={isCheckAdd4} disabled={isDisableAdd4} onChange={handleAdd4CheckboxChange} style={{ marginLeft: 30 }}>
                                                4) Hold mail
                                            </Checkbox>
                                        </Form.Item>
                                        <Form.Item name={["additionalQusAddress"]} noStyle>
                                            <Checkbox checked={isCheckAdd5} disabled={isDisableAdd5} onChange={handleAdd5CheckboxChange} style={{ marginLeft: 30 }}>
                                                5) US Address
                                            </Checkbox>
                                        </Form.Item>
                                        <Form.Item name={["additionalQusPhoneNumber"]} noStyle>
                                            <Checkbox checked={isCheckAdd6} disabled={isDisableAdd6} onChange={handleAdd6CheckboxChange} style={{ marginLeft: 30 }}>
                                                6) US Phone Number
                                            </Checkbox>
                                        </Form.Item>
                                    </Space>
                                </Col>
                            </Row>
                        </Radio.Group>
                    </Form.Item>
                </Form>
            </Card>
        </div>
    );
};

export default IndividualStatusOfCustomerForm;
