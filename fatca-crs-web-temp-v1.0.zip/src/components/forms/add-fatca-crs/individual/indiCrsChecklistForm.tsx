import React, { useState } from "react";
import { Card, Col, Form, FormInstance, Radio, Row } from "antd";

const IndividualCRSCheckListForm = ({ form, onFinish, crsStatus }: { form: FormInstance, onFinish: any, crsStatus: any }) => {
    const [status, setStatus] = useState("");

    const handleCrsStatusChange = (status: string) => {
        crsStatus(status);
        setStatus(status);
    }

    form.setFieldsValue({
        crsStatus: status
    });
    
    return (
        <div style={{ marginTop: 10, marginBottom: 40 }}>
            <span>
                <b>CRS Checklist</b>
            </span>
            <Card>
                <Form form={form} onFinish={onFinish} labelCol={{ flex: '200px' }} labelAlign="left">
                    <Radio.Group style={{ width: "100%" }}>
                        <Form.Item name={["crsStatus"]} noStyle>
                            <Row gutter={[8, 32]} >
                                <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                                    <span>Tax residency other than the U.S. (มีถิ่นที่อยู่ทางภาษีนอกเหนือจากสหรัฐ)</span>
                                </Col>
                                <Col xxl={4} xl={4} lg={4} md={24} sm={24} xs={24}>
                                    <Radio value={"Y"} onChange={() => handleCrsStatusChange("Y")}>Yes</Radio>
                                </Col>
                                <Col xxl={4} xl={4} lg={4} md={24} sm={24} xs={24}>
                                    <Radio value={"N"} onChange={() => handleCrsStatusChange("N")}>No</Radio>
                                </Col>
                            </Row>
                        </Form.Item>
                    </Radio.Group>
                </Form>
            </Card>
        </div>
    );
}

export default IndividualCRSCheckListForm;