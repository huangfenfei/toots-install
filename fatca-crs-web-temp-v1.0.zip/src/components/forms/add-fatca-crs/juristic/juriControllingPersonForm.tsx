import React, { useContext, useEffect, useRef, useState } from 'react';
import { Button, Col, Form, FormInstance, Input, Modal, Popconfirm, Row, Select, Space, Table } from 'antd';
import { DeleteFilled, DeleteOutlined, FormOutlined, PlusOutlined, SearchOutlined } from '@ant-design/icons';
import { ValueType } from 'rc-input/lib/interface';
import { ColumnsType } from 'antd/es/table';
import ForeignTINTableForm from '../common/foreignTinTableForm';
import { BiEdit, BiTrash } from 'react-icons/bi';
import ControllingPersonModel from '../../../modals/controllingPersonModal';
import dayjs from 'dayjs';
import { DropdownType } from '../../../../interface/masterType';
import { RootState } from '../../../../redux/store/store';
import { useSelector } from 'react-redux';

const JuriControllingPersonForm = ({ form, onFinish, callback }: { form: FormInstance, onFinish: any, callback: any }) => {

    const now = dayjs().format("DD-MM-YYYY");
    const countryOfBirthList: DropdownType[] = useSelector((state: RootState) => state.countryOfBirthReducer);


    const [isModalOpen, setIsModalOpen] = useState(false);
    const [ctrlPersonData, setCtrlPersonData] = useState({});
    const [ctrlPersonDataList, setCtrlPersonDataList] = useState([]);
    const [dataSource, setDataSource] = useState([]);
   
    

    const showModal = () => {
        setIsModalOpen(true);
        const ctrlPersonData = {
            key: "",
            ctrlPersonTitleCode: "",
            ctrlPersonFirstName: "",
            ctrlPersonMiddleName: "",
            ctrlPersonLastName: "",
            ctrlPersonDateOfBirth: "",
            ctrlPersonCityOfBirth: "",
            ctrlPersonCountryOfBirthCode: "",
            ctrlPersonFullAddress: "",
            ctrlPersonFullAddrCountryCode: "",
            ctrlPersonMailAddress: "",
            ctrlPersonMailAddrCountryCode: "",
            taxResidencies: [],
        }
        setCtrlPersonData(ctrlPersonData);
    };

    const handleEdit = (data: any) => {
        setIsModalOpen(true);
        const sss = ctrlPersonDataList.find((it) => it.key === data.key);
        setCtrlPersonData(sss);
    };

    const handleCancel = () => {
        setIsModalOpen(false);
    };

    const handleDelete = (data: any) => {
        const newData = ctrlPersonDataList.filter((item) => item.key !== data.key);
        setCtrlPersonDataList(newData);
    };

    const callbackControllingPerson = (data: any) => {
        const findCtrlPerson = ctrlPersonDataList.find((it) => it.key === data.key);
        if (findCtrlPerson) {
            // dataSourceTemp.map((value, index) => {
            //     if (value.key === data.key) {
            //         value.title_cd = data.title_cd;
            //         value.customerName = data.customerName;
            //         value.dob = data.dob;
            //         value.cityOfBirth = data.cityOfBirth;
            //         value.countryOfBirth_cd = data.countryOfBirth_cd;
            //         value.fullAddr = data.fullAddr;
            //         value.fullAddrCountry = data.fullAddrCountry;
            //         value.mailingAddr = data.mailingAddr;
            //         value.mailingAddrCountry = data.mailingAddrCountry;
            //         value.countryOfBirthName = data.countryOfBirthName;
            //         value.customerFullName = data.customerFullName;
            //         value.fullAddrCountryName = data.fullAddrCountryName;
            //         value.mailingAddrCountryName = data.mailingAddrCountryName;
            //         value.numberOfCountry = data.numberOfCountry;
            //         value.ctpCountryTax = data.ctpCountryTax;
            //         value.originData = data.;
            //     }
            //     return value;
            // });
            const mapDataSource = ctrlPersonDataList.map((value, index) => {
                if (value.key === data.key) {
                    value = data;
                }
                return value;
            });
            setCtrlPersonDataList(mapDataSource);
        } else {
            setCtrlPersonDataList((it) => [...it, ...[data]]);
        }
    }

    useEffect(() => {
        console.log("dataSource ==>", ctrlPersonDataList);
        const mapPersonDataList = ctrlPersonDataList.map((data) => {
            let custName = "";
            if (data.ctrlPersonMiddleName) {
                custName = replaceSpace(data.ctrlPersonFirstName) + " " + replaceSpace(data.ctrlPersonMiddleName) + " " + replaceSpace(data.ctrlPersonLastName);
            } else {
                custName = replaceSpace(data.ctrlPersonFirstName) + " " + replaceSpace(data.ctrlPersonLastName);
            }
    
            const countryOfBirthName = countryOfBirthList.find((it) => it.code_cd === data.ctrlPersonCountryOfBirthCode);
            const fullAddrCountryName = countryOfBirthList.find((it) => it.code_cd === data.ctrlPersonFullAddrCountryCode);
            const mailAddrCountryName = countryOfBirthList.find((it) => it.code_cd === data.ctrlPersonMailAddrCountryCode);
            const dobDayJs = dayjs(data.ctrlPersonDateOfBirth).format("DD-MM-YYYY");
            console.log(dobDayJs);
            const model = {
                key: data.key,
                customerFullName: custName,
                dateOfBirth: dobDayJs,
                cityOfBirth: data.ctrlPersonCityOfBirth,
                countryOfBirth: countryOfBirthName.label,
                fullAddress: data.ctrlPersonFullAddress + ", " + fullAddrCountryName.label,
                mailingAddress: data.ctrlPersonMailAddress + ", " + mailAddrCountryName.label,
                numberOfCountry: data.taxResidencies.length
                
            };
            return model;
        });
        setDataSource(mapPersonDataList);
    }, [ctrlPersonDataList]);

    const replaceSpace = (value: string) => {
        return value.replace(/ /g, '');
    }

    const defaultColumns: ColumnsType<any> = [
        {
            title: 'No',
            dataIndex: 'no',
            width: 80,
            align: 'center',
            fixed: 'left',
            render: (_, __, index) => index + 1,
        },
        {
            title: 'Name',
            dataIndex: 'customerFullName',
            width: 200,
            align: 'center',
        },
        {
            title: 'Date of Birth',
            dataIndex: 'dateOfBirth',
            width: 180,
            align: 'center',
        },
        {
            title: 'City of Birth',
            dataIndex: 'cityOfBirth',
            width: 180,
            align: 'center',
        },
        {
            title: 'Country of Birth',
            dataIndex: 'countryOfBirth',
            width: 200,
            align: 'center',
        },
        {
            title: 'Full Address',
            dataIndex: 'fullAddress',
            width: 400,
            align: 'left',
        },
        {
            title: 'Mailing Address',
            dataIndex: 'mailingAddress',
            width: 400,
            align: 'left',
        },
        {
            title: 'Number of Country Declaration',
            dataIndex: 'numberOfCountry',
            width: 200,
            align: 'center',
        },

        {
            title: 'Action',
            dataIndex: 'operation',
            width: 120,
            align: 'center',
            fixed: 'right',
            render: (text: ValueType, record: any) => (
                <div>
                    <Space style={{ gap: 0 }}>
                        {/* <Button type="text" onClick={() => handleView(record)} disabled={isDisableViewBtn} style={{ paddingLeft: 3, paddingRight: 3 }}>
                            <BiSearch size={20} />
                        </Button> */}
                        <Button type="text" onClick={() => handleEdit(record)} style={{ paddingLeft: 3, paddingRight: 3 }}>
                            <BiEdit size={20} />
                        </Button>
                        <Button type="text" onClick={() => handleDelete(record)} style={{ paddingLeft: 3, paddingRight: 3 }}>
                            <BiTrash size={20} />
                        </Button>

                    </Space>
                </div>
            ),
        },
    ];

    return (
        <div style={{ marginTop: 10, marginBottom: 10 }}>
            <span>
                <b>CRS - Controlling Person tax residency self-certificate</b>
                <Button type="primary" shape="circle" style={{ marginLeft: 15 }} onClick={showModal} icon={<PlusOutlined />} />
            </span>
            <Table dataSource={dataSource} columns={defaultColumns} pagination={false} scroll={{ x: 1960, y: 300 }} />
            <ControllingPersonModel visibleOpen={isModalOpen} handleCancel={handleCancel} ctrlPersonData={ctrlPersonData} controllingPerson={callbackControllingPerson} />
        </div >
    );
}

export default JuriControllingPersonForm;