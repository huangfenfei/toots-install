import { DeleteOutlined, PlusOutlined } from "@ant-design/icons";
import { Button, Card, Checkbox, Col, Form, FormInstance, Input, Popconfirm, Radio, Row, Space, Table } from "antd";
import React, { useEffect, useState } from "react";
import { ValueType } from 'rc-input/lib/interface';
import { ColumnsType } from "antd/es/table";
import { BiTrash } from "react-icons/bi";
import { JuristicFormEnum } from "../../../../utils/constantEnum";
import { v4 as uuidv4 } from 'uuid';

const JuristicIRSDocumentW8BenEForm = ({ form, onFinish, callback, callbackSupportPerson }: { form: FormInstance, onFinish: any, callback: any, callbackSupportPerson: any }) => {

    const [w8BenEStatus, setW8BenEStatus] = useState("");
    const [dataSource, setDataSource] = useState([]);
    const [dataSourceTemp, setDataSourceTemp] = useState([]);
    const uuid = uuidv4();

    const handleStatusChange = (status: string) => {
        setW8BenEStatus(status);
        callback(status);
    }

    const handleAddW8BenE = () => {
        const data = [{
            key: uuid,
            person: 0,
            name: '',
            address: '',
            tin: '',
        }]
        setDataSourceTemp((it) => [...it, ...data]);
    }

    useEffect(() => {
        const dataMap = dataSourceTemp.map((data, index) => ({
            ...data,
            person: index + 1,
        }));
        setDataSource(dataMap);
        callbackSupportPerson(dataMap);
    }, [dataSourceTemp]);

    const handleNameChange = (key: string, newText: string) => {
        const newData = [...dataSource];
        const index = newData.findIndex((item) => key === item.key);
        if (index > -1) {
            newData[index].name = newText;
            setDataSource(newData);
        }
    };

    const handleAddressChange = (key: string, newText: string) => {
        const newData = [...dataSource];
        const index = newData.findIndex((item) => key === item.key);
        if (index > -1) {
            newData[index].address = newText;
            setDataSource(newData);
        }
    };

    const handleForeignTINChange = (key: string, newText: string) => {
        const newData = [...dataSource];
        const index = newData.findIndex((item) => key === item.key);
        if (index > -1) {
            newData[index].tin = newText;
            setDataSource(newData);
        }
    };

    const handleDelete = (key: React.Key) => {
        const dataTemp = dataSourceTemp.filter((item) => item.key !== key);
        const dataMapTemp = dataTemp.map((data, index) => ({
            ...data,
            no: index + 1,
        }));
        setDataSourceTemp(dataMapTemp)
    };

    const defaultColumns: ColumnsType<any> = [
        {
            title: 'Person',
            dataIndex: 'person',
            width: '10%',
            align: 'center',
            render: (text: ValueType, record: { key: string; }) => (
                <div>{text}</div>
            ),
        },
        {
            title: 'Name',
            dataIndex: 'name',
            width: '25%',
            align: 'center',
            render: (text: ValueType, record: { key: string; }, index) => (
                <Form.Item name={[index, "name"]} rules={[{ required: true }]} noStyle>
                    <Input max={10}/>
                </Form.Item>

            ),
        },
        {
            title: 'Address',
            dataIndex: 'address',
            width: '35%',
            align: 'center',
            render: (text: ValueType, record: { key: string; }) => (
                <Input
                    value={text}
                    onChange={(e) => handleAddressChange(record.key, e.target.value)}
                />
            ),
        },
        {
            title: 'TIN',
            dataIndex: 'tin',
            width: '20%',
            align: 'center',
            render: (text: ValueType, record: { key: string; }) => (
                <Input
                    value={text}
                    onChange={(e) => handleForeignTINChange(record.key, e.target.value)}
                />
            ),
        },
        {
            title: 'Action',
            dataIndex: 'operation',
            width: '10%',
            align: 'center',
            render: (text: ValueType, record: { key: string; }) => (
                <Button type="text" onClick={() => handleDelete(record.key)} style={{ paddingLeft: 3, paddingRight: 3 }}>
                    <BiTrash size={20} />
                </Button>
            ),
        },
    ];

    return (
        <div style={{ marginTop: 10, marginBottom: 20 }}>
            <span><b>IRS Document</b></span>
            <Card>
                <Form form={form} onFinish={onFinish} labelCol={{ flex: '200px' }} labelAlign="left">
                    <Row gutter={24}>
                        <Col span={24}>
                            <span><b>W-8 BEN-E</b></span>
                        </Col>
                    </Row>
                    <Radio.Group style={{ width: "100%" }}>
                        <Row gutter={24} >
                            <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24} style={{ marginBottom: 10 }}>
                                <Radio value={"Y"} onChange={() => handleStatusChange("Y")}>มี (กรุณากรอกข้อมูลในตาราง Substantial U.S. Owners)</Radio>
                            </Col>
                            <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24} style={{ marginBottom: 10 }}>
                                <Radio value={"N"} onChange={() => handleStatusChange("N")}>ไม่มี</Radio>
                            </Col>
                        </Row>
                    </Radio.Group>
                    {w8BenEStatus === "Y" ?
                        <div>
                            <Row gutter={24} style={{ marginTop: 15 }}>
                                <Col span={12}>
                                    <span>
                                        <b>W-8 BEN-E</b>
                                        <Button type="primary" shape="circle" style={{ marginLeft: 15 }} icon={<PlusOutlined />} onClick={handleAddW8BenE} />
                                    </span>
                                </Col>
                            </Row>
                            <Row gutter={24} style={{ marginTop: 10 }}>
                                <Col span={24}>
                                    <Table dataSource={dataSource} columns={defaultColumns} pagination={false} />
                                </Col>
                            </Row>
                        </div> : null
                    }
                </Form>
            </Card>
        </div>
    );
}

export default JuristicIRSDocumentW8BenEForm;