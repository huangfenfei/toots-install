import { DeleteOutlined } from "@ant-design/icons";
import { Card, Checkbox, Col, Form, FormInstance, Input, Popconfirm, Radio, Row, Space, Table, Typography } from "antd";
import React, { useEffect, useState } from "react";
import { ValueType } from 'rc-input/lib/interface';

const JuriICrsChecklistForm = ({ form, onFinish, customerStatus, callbackIsVisibleCtrlPerson }: { form: FormInstance, onFinish: any, customerStatus: string, callbackIsVisibleCtrlPerson: any }) => {
    const { Text } = Typography;

    const [typOfEntity, setTypeOfEnitiy] = useState(null);
    const [financial, setFinancial] = useState(null);
    const [nonFinancial, setNonFinancial] = useState(null);

    const [chkDisable21, setChkDisable21] = useState(false);
    const [chkDisable211, setChkDisable211] = useState(false);
    const [chkDisable212, setChkDisable212] = useState(false);
    const [chkDisable213, setChkDisable213] = useState(false);
    const [chkDisable22, setChkDisable22] = useState(false);
    const [chkDisable221, setChkDisable221] = useState(false);
    const [chkDisable222, setChkDisable222] = useState(false);
    const [chkDisable223, setChkDisable223] = useState(false);
    const [chkDisable224, setChkDisable224] = useState(false);
    const [chkDisable23, setChkDisable23] = useState(false);

    const handleTypeOfEntityChange = (evt: any) => {
        const value = evt.target.value;
        setTypeOfEnitiy(value);
        switch (value) {
            case 1:
                setFinancial(11);
                setNonFinancial(null);
                break;
            case 2:
                setFinancial(null);
                setNonFinancial(21);
                break;
            case 3:
                callbackIsVisibleCtrlPerson(true);
                setFinancial(null);
                setNonFinancial(null);
                break;
        }

    }

    useEffect(() => {
        if (typOfEntity) {
            callbackIsVisibleCtrlPerson(typOfEntity === 3);
        }
    }, [typOfEntity]);

    const handelFinancialChange = (evt: any) => {
        const value = evt.target.value;
        setFinancial(value);
        setNonFinancial(null);
        callbackIsVisibleCtrlPerson(value === 11);
    }

    useEffect(() => {
        if (financial) {
            setTypeOfEnitiy(1);
            callbackIsVisibleCtrlPerson(financial === 11);
        }
    }, [financial]);

    const handelNonFinancialChange = (evt: any) => {
        const value = evt.target.value;
        setNonFinancial(value)
        setFinancial(null);
    }

    useEffect(() => {
        if (nonFinancial) {
            setTypeOfEnitiy(2);
        }
    }, [nonFinancial]);

    useEffect(() => {
        if (customerStatus === "1") {
            setFinancial(null);
            setNonFinancial(null);
            setChkDisable21(false);
            setChkDisable211(false);
            setChkDisable212(false);
            setChkDisable213(false);
            setChkDisable22(false);
            setChkDisable221(false);
            setChkDisable222(false);
            setChkDisable223(false);
            setChkDisable224(false);
            setChkDisable23(false);
        } else if (customerStatus === "2") {
            setFinancial(null);
            setNonFinancial(null);
            setTypeOfEnitiy(1);
            setChkDisable21(false);
            setChkDisable211(false);
            setChkDisable212(false);
            setChkDisable213(false);
            setChkDisable22(true);
            setChkDisable221(true);
            setChkDisable222(true);
            setChkDisable223(true);
            setChkDisable224(true);
            setChkDisable23(true);
        } else if (customerStatus === "3") {
            setFinancial(null);
            setNonFinancial(null);
            setTypeOfEnitiy(3);
            setChkDisable21(true);
            setChkDisable211(true);
            setChkDisable212(true);
            setChkDisable213(true);
            setChkDisable22(true);
            setChkDisable221(true);
            setChkDisable222(true);
            setChkDisable223(true);
            setChkDisable224(true);
            setChkDisable23(true);
        }
    }, [customerStatus]);


    form.setFieldsValue({
        juriCrsCheckListIENonPar: financial === 11 ? "Y" : "N",
        juriCrsCheckListIEOther: financial === 12 ? "Y" : "N",
        juriCrsCheckListFIUnderCrs: financial === 13 ? "Y" : "N",
        juriCrsCheckListANFECorporate: nonFinancial === 21 ? "Y" : "N",
        juriCrsCheckListANFEGovernment: nonFinancial === 22 ? "Y" : "N",
        juriCrsCheckListANFEInterOrg: nonFinancial === 23 ? "Y" : "N",
        juriCrsCheckListANFEOther: nonFinancial === 24 ? "Y" : "N",
        juriCrsCheckListPassiveNFFE: typOfEntity === 3 ? "Y" : "N",
    });

    return (
        <div style={{ marginTop: 10, marginBottom: 20 }}>
            <Space direction="vertical">
                <Text><b>CRS Checklist</b></Text>
                <Text><b>Part2- CRS Declaration of Tax Residency</b></Text>
            </Space>
            <Card>
                <Form form={form} onFinish={onFinish} labelCol={{ flex: '200px' }} labelAlign="left">
                    <Row gutter={24}>
                        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24} style={{ marginBottom: 10 }}>
                            <Text><b>Select type of Entity (เลือกประเภทนิติบุคคล)</b></Text>
                        </Col>
                    </Row>
                    <Form.Item name={["juriCrsCheckListIENonPar"]} noStyle></Form.Item>
                    <Form.Item name={["juriCrsCheckListIEOther"]} noStyle></Form.Item>
                    <Form.Item name={["juriCrsCheckListFIUnderCrs"]} noStyle></Form.Item>
                    <Form.Item name={["juriCrsCheckListANFECorporate"]} noStyle></Form.Item>
                    <Form.Item name={["juriCrsCheckListANFEGovernment"]} noStyle></Form.Item>
                    <Form.Item name={["juriCrsCheckListANFEInterOrg"]} noStyle></Form.Item>
                    <Form.Item name={["juriCrsCheckListANFEOther"]} noStyle></Form.Item>
                    <Form.Item name={["juriCrsCheckListPassiveNFFE"]} noStyle></Form.Item>
                    <Radio.Group value={typOfEntity} onChange={handleTypeOfEntityChange} style={{ width: "100%" }}>
                        <Space direction="vertical">
                            <Row gutter={24} >
                                <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                                    <Radio value={1} disabled={chkDisable21}>2.1 Financial Institution (FI)(สถาบันการเงิน)</Radio>
                                    <Radio.Group onChange={handelFinancialChange} value={financial} style={{ width: "100%" }}>
                                        <Space direction="vertical">
                                            <Radio value={11} disabled={chkDisable211} style={{ marginLeft: 30 }}>2.1.1 Investment Entity in a Non-Participating Jurisdiction and managed by another FI (นิติบุคคลเพื่อการลงทุนที่บริหารโดย FI อื่น และไม่ได้อยู่ในประเทศภาคี)</Radio>
                                            <Radio value={12} disabled={chkDisable212} style={{ marginLeft: 30 }}>2.1.2 Other Investment Entity other than 2.1.1 (นิติบุคคลเพื่อการลงทุนอื่นๆนอกเหนือจากข้อ 2.1.1)</Radio>
                                            <Radio value={13} disabled={chkDisable213} style={{ marginLeft: 30 }}>2.1.3 Depository / Custodial Institution / Specified Insurance Company (สถาบันรับฝากเงิน รับฝากหลักทรัพย์ บริษัทประกันที่กำหนด)</Radio>
                                        </Space>
                                    </Radio.Group>
                                </Col>
                            </Row>
                            <Row gutter={24} >
                                <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                                    <Radio value={2} disabled={chkDisable22}>2.2 Active Non-Financial Entity (Active NFE) (นิติบุคคลที่ไม่ใช่สถาบันการเงิน)</Radio>
                                    <Radio.Group onChange={handelNonFinancialChange} value={nonFinancial} style={{ width: "100%" }}>
                                        <Space direction="vertical">
                                            <Radio value={21} disabled={chkDisable221} style={{ marginLeft: 30 }}>2.2.1 A corporation the stock of which is regularly traded on an established securities market or a corporation which is a related entity of such corporation (บริษัทที่หุ้นมีการซื้อขายเป็นประจำในตลาดหลักทรัพย์ หรือ เป็นบริษัทในเครือของบริษัทที่หุ้นมีการซื้อขายเป็นประจำในตลาดหลักทรัพย์)</Radio>
                                            {nonFinancial === 21 ?
                                                <Space direction="vertical" style={{ marginLeft: 60 }}>
                                                    <Text>The name of the established securities market on which the corporation is regularly traded (ชื่อตลาดหลักทรัพย์ที่ซื้อขายหุ้น) <Text style={{ color: "#ff4d4f", marginLeft: 5 }}>*</Text></Text>
                                                    <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
                                                        <Form.Item name={["juriCrsCheckListstockMarketName"]} rules={[{ required: nonFinancial === 21, message: "Please input the name of the established securities market!" }]} >
                                                            <Input maxLength={100}></Input>
                                                        </Form.Item>
                                                    </Col>
                                                    <Text>If you are a Related Entity of a regularly traded corporation, please provide the name of such corporation (หากท่านเป็นบริษัทในเครือของบริษัท ที่หุ้นมีการซื้อขายเป็นประจำในตลาดหลักทรัพย์ โปรดระบุชื่อบริษัทในเครือของท่านที่หุ้นมีการซื้อขายเป็นประจำในตลาดหลักทรัพย์)</Text>
                                                    <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
                                                        <Form.Item name={["juriCrsCheckListstockName"]} >
                                                            <Input maxLength={100}></Input>
                                                        </Form.Item>
                                                    </Col>
                                                </Space> : null
                                            }
                                            <Radio value={22} disabled={chkDisable222} style={{ marginLeft: 30 }}>2.2.2 Goverment Entity or Central Bank (หน่วยงานราชการ หรือ ธนาคารกลาง)</Radio>
                                            <Radio value={23} disabled={chkDisable223} style={{ marginLeft: 30 }}>2.2.3 International Organiztion (องค์กรระหว่างประเทศ)</Radio>
                                            <Radio value={24} disabled={chkDisable224} style={{ marginLeft: 30 }}>2.2.4 Active NFE-other than 2.2.1-2.2.3 (อื่นๆนอกเหนือจากข้อ 2.2.1-2.2.3)</Radio>
                                        </Space>
                                    </Radio.Group>
                                </Col>
                            </Row>
                            <Row gutter={24} >
                                <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                                    <Radio value={3} disabled={chkDisable23}>2.3 Passive Non-Financial Entity (Passive NFE)(นิติบุคคลที่มีรายได้หลักจากการลงทุน)</Radio>
                                </Col>
                            </Row>
                        </Space>
                    </Radio.Group>

                </Form>
            </Card>
        </div>
    );
}

export default JuriICrsChecklistForm;