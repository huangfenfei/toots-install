import { Card, Checkbox, Col, Form, FormInstance, Radio, Row, Space } from "antd";
import React from "react";

const JuristicStatusOfCustomerForm = ({ form, onFinish, stateOfCustomer }: { form: FormInstance, onFinish: any, stateOfCustomer: any }) => {

    const handleCustomerStatusChange = (status: string) => {
        stateOfCustomer(status);
    }

    return (
        <div style={{ marginTop: 10, marginBottom: 20 }}>
            <div>
                <span><b>Part 1 - Status of Customer</b></span><br />
                <span style={{ fontSize: 12 }}>Please Check only the question that answer &quot;Yes&quot;/โปรดเลือกหัวข้อที่ลูกค้าตอบ &quot;ใช่&quot;</span>
            </div>
            <Card>
                <Form form={form} onFinish={onFinish} labelCol={{ flex: '200px' }} labelAlign="left">
                    <Form.Item name={"customerStatus"} noStyle>
                        <Radio.Group style={{ width: "100%" }}>
                            <Row gutter={24} >
                                <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24} style={{ marginBottom: 10 }}>
                                    <Radio value={"1"} onChange={() => handleCustomerStatusChange("1")}>1) US Entity (นิติบุคคลอเมริกัน)</Radio>
                                </Col>
                            </Row>
                            <Row gutter={24}>
                                <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24} style={{ marginBottom: 10 }}>
                                    <Radio value={"2"} onChange={() => handleCustomerStatusChange("2")}>2) FI under FATCA (สถาบันการเงินภายใต้ FATCA)</Radio>
                                </Col>
                            </Row>
                            <Row gutter={24} >
                                <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24} style={{ marginBottom: 10 }}>
                                    <Radio value={"3"} onChange={() => handleCustomerStatusChange("3")}>3) Passive NFFE (นิติบุคคลที่มีรายได้หลักจากการลงทุน)</Radio>
                                </Col>
                            </Row>
                        </Radio.Group>
                    </Form.Item>
                </Form>
            </Card>
        </div>
    );
}

export default JuristicStatusOfCustomerForm;