import { Col, Form, Row, Select, FormInstance, Input } from "antd";
import React, { useEffect, useState } from "react";
import { DropdownType } from "../../../../interface/masterType";
import { useSelector } from "react-redux";
import { RootState } from "../../../../redux/store/store";
import { BrancheType } from "../../../../interface/branchType";

const JuristicCustomerInfoForm = ({ form, onFinish }: { form: FormInstance, onFinish: any }) => {

    const idTypeJuristicList: DropdownType[] = useSelector((state: RootState) => state.idTypeJuristicReducer);
    const titleJuristicList: DropdownType[] = useSelector((state: RootState) => state.titleJuristicReducer);
    const nationalityList: DropdownType[] = useSelector((state: RootState) => state.nationalityReducer);
    const allBranchList: BrancheType[] = useSelector((state: RootState) => state.allBranchReducer);

    useEffect(() => {
        form.setFieldsValue({
            juriInfoIdTypeCode: "",
            juriInfoTitleCode: "",
            juriInfoNationalityCode: "",
            juriInfoBranchNo: "",
        });
    }, []);



    return (
        <div style={{ marginTop: 10, marginBottom: 10 }}>
            <Form form={form} onFinish={onFinish} labelCol={{ flex: '200px' }} labelAlign="left">
                <Row gutter={24}>
                    <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
                        <Form.Item name={["juriInfoIdTypeCode"]} label={"Identification Type"} rules={[{ required: true }]}>
                            <Select
                                showSearch
                                placeholder="Please Select"
                                optionFilterProp="children"
                                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                options={idTypeJuristicList}
                            />
                        </Form.Item>
                    </Col>
                    <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
                        <Form.Item name={["juriInfoIdNumber"]}  label={"Identification Number"} rules={[{ required: true }]}>
                            <Input maxLength={20}></Input>
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={24}>
                    <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
                        <Form.Item name={["juriInfoTitleCode"]} label={"Title"} rules={[{ required: true }]}>
                            <Select
                                showSearch
                                placeholder="Please Select"
                                optionFilterProp="children"
                                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                options={titleJuristicList}
                            />
                        </Form.Item>
                    </Col>
                    <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
                        <Form.Item name={["juriInfoCustName"]}  label={"Customer Name"} rules={[{ required: true }]}>
                            <Input maxLength={170}></Input>
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={24}>
                    <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
                        <Form.Item name={["juriInfoNationalityCode"]} label={"Nationality"} rules={[{ required: true }]}>
                            <Select
                                showSearch
                                placeholder="Please Select"
                                optionFilterProp="children"
                                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                options={nationalityList}
                            />
                        </Form.Item>
                    </Col>
                    <Col xxl={12} xl={12} lg={12} md={12} sm={24} xs={24}>
                        <Form.Item name={["juriInfoBranchNo"]} label={"Branch No./OC Code"} rules={[{ required: true }]}>
                            <Select
                                showSearch
                                placeholder="Please Select"
                                optionFilterProp="children"
                                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                options={allBranchList}
                            />
                        </Form.Item>
                    </Col>
                </Row>
            </Form>
        </div >
    );
}
export default JuristicCustomerInfoForm;