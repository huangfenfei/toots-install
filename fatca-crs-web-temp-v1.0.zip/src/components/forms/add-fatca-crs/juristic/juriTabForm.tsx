import React, { useEffect, useState } from "react";
import { Button, Col, Form, Row, Space, Spin } from "antd";
import JuristicCustomerInfoForm from "./juriCustomerInfoForm";
import JuristicFatcaCheckListForm from "./juriFatcaChecklistForm";
import JuriICrsChecklistForm from "./juriCrsChecklistForm";
import ForeignTINTableForm from "../common/foreignTinTableForm";
import JuriControllingPersonForm from "./juriControllingPersonForm";
import JuristicStatusOfCustomerForm from "./juriStatusOfCustomerForm";
import IRSDocumentW9Form from "../common/irsDocumentW9Form";
import IRSDocumentW8Form from "../common/irsDocumentW8Form";
import JuristicIRSDocumentW8BenEForm from "./juriIrsDocumentW8BenEForm";
import { ANFECorporateInfoType, CRSCheckListType, ControllingPersonType, CountryTaxType, CustomerInfoType, EntityType, FatcaCheckListType, IRSDocumentType, JuristicType, SupportingPersonType, TINType, W8BenEType, W9Type } from "../../../../interface/juristicType";
import { getUsernameStorage } from "../../../../storages/usernameStorage";
import { getOcCodeStorage } from "../../../../storages/ocCodeStorage";
import { convertEmptyUndefined } from "../../../../utils/constantFunc";
import { useMutation } from "@tanstack/react-query";
import { saveJuristic } from "../../../../services/fatca-crs/juristic";
import { ResponseCodeEnum } from "../../../../utils/constantEnum";
import WarningModal from "../../../modals/warningModal";
import SuccessModal from "../../../modals/successModal";

const JuristicTabForm = ({ tab }: { tab: string }) => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [isOpenWarningModal, setIsOpenWarningModal] = useState(false);
  const [isOpenSuccessModal, setIsOpenSuccessModal] = useState(false);
  const [msgWarningModal, setMsgWarningModal] = useState("");
  const [indiciaStatus, setIndiciaStatus] = useState("");
  const [customerStatus, seCustomerStatus] = useState("0");
  const [w8BenEStatus, setW8BenEStatus] = useState("");
  const [supportPerson, setSupportPerson] = useState([]);
  const [countryTax, setCountryTax] = useState([]);
  const [ctrlPerson, setCtrlPerson] = useState([]);
  const [visibleCtrlPerson, setVisibleCtrlPerson] = useState(false);

  useEffect(() => {
    form.resetFields();
    setAllFieldsEmpty();
  }, [tab]);

  const setAllFieldsEmpty = () => {
    const fields = form.getFieldsValue();
    const emptyFields = Object.keys(fields).reduce((acc, key) => {
      acc[key] = '';
      return acc;
    }, {});
    form.setFieldsValue(emptyFields);
  };


  const callbackStateOfCustomer = (state: string) => {
    seCustomerStatus(state);
  }

  const handleSave = () => {
    form.submit();
  }

  const callbackSave = (data: any) => {
    console.log("callbackSave.data ==>", data);
    let ctrlPersonArr = [];
    ctrlPerson.forEach((it1) => {
      let ctpArr: CountryTaxType[] = [];
      it1.ctpCountryTax.forEach((it2) => {
        const ctpModel: CountryTaxType = {
          country_cd: it2.country_cd,
          TIN: it2.TIN,
          reason_cd: it2.reason_cd,
          reason: it2.reasonDetail
        }
        ctpArr.push(ctpModel);
      });

      const ctrlModel: ControllingPersonType = {
        title_cd: it1.title_cd,
        customerName: it1.customerName,
        dob: it1.dob,
        cityOfBirth: it1.cityOfBirth,
        countryOfBirth_cd: it1.countryOfBirth_cd,
        fullAddr: it1.fullAddr,
        fullAddrCountry: it1.fullAddrCountry,
        mailingAddr: it1.mailingAddr,
        mailingAddrCountry: it1.mailingAddrCountry,
        ctpCountryTax: ctpArr,
      }
      ctrlPersonArr.push(ctrlModel);
    });


    let countryTaxArr = [];
    countryTax.forEach((it) => {
      const model: CountryTaxType = {
        country_cd: it.country_cd,
        TIN: it.TIN,
        reason_cd: it.reason_cd,
        reason: it.reasonDetail
      }
      countryTaxArr.push(model);
    });

    let supportPersonArr = [];
    supportPerson.forEach((it) => {
      const model: SupportingPersonType = {
        name: convertEmptyUndefined(it.name),
        address: convertEmptyUndefined(it.address),
        TIN: convertEmptyUndefined(it.tin)
      }
      supportPersonArr.push(model);
    });

    const anfeCropModel: ANFECorporateInfoType = {
      stockMarketName: convertEmptyUndefined(data.juriCrsCheckListstockMarketName),
      stockName: convertEmptyUndefined(data.juriCrsCheckListstockName),
    }

    const crsCheckListModel: CRSCheckListType = {
      IENonPar: convertEmptyUndefined(data.juriCrsCheckListIENonPar),
      IEOther: convertEmptyUndefined(data.juriCrsCheckListIEOther),
      FIUnderCrs: convertEmptyUndefined(data.juriCrsCheckListFIUnderCrs),
      ANFECorporate: convertEmptyUndefined(data.juriCrsCheckListANFECorporate),
      ANFEGovernment: convertEmptyUndefined(data.juriCrsCheckListANFEGovernment),
      ANFEInterOrg: convertEmptyUndefined(data.juriCrsCheckListANFEInterOrg),
      ANFEOther: convertEmptyUndefined(data.juriCrsCheckListANFEOther),
      PassiveNFFE: convertEmptyUndefined(data.juriCrsCheckListPassiveNFFE),
      ANFECorporateInfo: anfeCropModel,
      countryTax: countryTaxArr,
      controllingPerson: ctrlPersonArr
    }

    const tinModel: TINType = {
      EIN: convertEmptyUndefined(data.empIdNum1) + convertEmptyUndefined(data.empIdNum2),
    }

    const w9Model: W9Type = {
      businessName: convertEmptyUndefined(data.irsDocW9Name),
      taxClass_cd: convertEmptyUndefined(data.irsDocW9TaxClassCode),
      exemptPayee_cd: convertEmptyUndefined(data.irsDocW9ExemptPayeeCode),
      exemptFromFatcaReport_cd: convertEmptyUndefined(data.irsDocW9ReportingCode),
      address: convertEmptyUndefined(data.irsDocW9Address),
      city: convertEmptyUndefined(data.irsDocW9City),
      state: convertEmptyUndefined(data.irsDocW9State),
      zip: convertEmptyUndefined(data.irsDocW9ZipCode),
      TIN: tinModel
    }

    const w8BenEModel: W8BenEType = {
      isW8BenEExisted: w8BenEStatus,
      supportingPerson: w8BenEStatus === "Y" ? supportPersonArr : null
    }

    const irsDocModel: IRSDocumentType = {
      w8Ben_E: customerStatus === "3" ? w8BenEModel : null,
      w9: customerStatus === "1" ? w9Model : null,
    }

    const entityModel: EntityType = {
      entityStatus: customerStatus
    }

    const fatcaCheckList: FatcaCheckListType = {
      indicia: indiciaStatus,
      entity: indiciaStatus === "Y" ? entityModel : null,
      IRSDoc: indiciaStatus === "Y" ? irsDocModel : null
    }

    const customerInfoModel: CustomerInfoType = {
      idType_cd: convertEmptyUndefined(data.juriInfoIdTypeCode),
      idNum: convertEmptyUndefined(data.juriInfoIdNumber),
      title_cd: convertEmptyUndefined(data.juriInfoTitleCode),
      customerName: convertEmptyUndefined(data.juriInfoCustName),
      nationality_cd: convertEmptyUndefined(data.juriInfoNationalityCode),
      brNo: convertEmptyUndefined(data.juriInfoBranchNo),
      FATCAChkList: fatcaCheckList,
    }

    const body: JuristicType = {
      userEntry: getUsernameStorage(),
      entryBrNo: getOcCodeStorage(),
      customerInfo: customerInfoModel,
      CRSCkList: crsCheckListModel
    }

    console.log("callbackSave.body ==>", body);

    setLoading(true);
    saveJuristicMutation.mutate(body);
  }

  const saveJuristicMutation = useMutation({
    mutationFn: (data: any) => saveJuristic(data),
    onSuccess(res) {
      console.log("saveJuristicMutation ==>", res);
      setLoading(false);
      if (res.respCode === ResponseCodeEnum.SUCCESS) {
        setIsOpenSuccessModal(true);
      } else {
        setIsOpenWarningModal(true);
        setMsgWarningModal(res.respCode + " : " + res.respDesc);
      }
    }
  });

  const handleWarningModalOK = () => {
    setIsOpenWarningModal(false);
  }

  const handleSuccessModalOK = () => {
    setIsOpenSuccessModal(false);
  }

  return (
    <div>
      <Spin spinning={loading}>
        <JuristicCustomerInfoForm form={form} onFinish={callbackSave} />
        <JuristicFatcaCheckListForm form={form} onFinish={callbackSave} onIndiciaStatus={setIndiciaStatus} />
        {indiciaStatus === "Y" ? <JuristicStatusOfCustomerForm form={form} onFinish={callbackSave} stateOfCustomer={callbackStateOfCustomer} /> : null}
        {(indiciaStatus === "Y" && customerStatus === "1") ? <IRSDocumentW9Form form={form} onFinish={callbackSave} isVisible={customerStatus} customerType={"juritic"} /> : null}
        {(indiciaStatus === "Y" && customerStatus === "2") ? <IRSDocumentW8Form form={form} onFinish={callbackSave} formName={"W-8 BEN-E"} /> : null}
        {(indiciaStatus === "Y" && customerStatus === "3") ? <JuristicIRSDocumentW8BenEForm form={form} onFinish={callbackSave} callback={setW8BenEStatus} callbackSupportPerson={setSupportPerson} /> : null}
        <JuriICrsChecklistForm form={form} onFinish={callbackSave} customerStatus={customerStatus} callbackIsVisibleCtrlPerson={setVisibleCtrlPerson} />
        <ForeignTINTableForm form={form} onFinish={callbackSave} data={[]} onCallback={setCountryTax} titleName={"Tax Residency and Taxpayer Identification Number (TIN)"} />
        {visibleCtrlPerson ? <JuriControllingPersonForm form={form} onFinish={callbackSave} callback={setCtrlPerson} /> : null}

        <WarningModal isModalOpen={isOpenWarningModal} handleMessage={msgWarningModal} handleOk={handleWarningModalOK} />
        <SuccessModal isModalOpen={isOpenSuccessModal} handleMessage={"Save Fatca & CRS Success!"} handleOk={handleSuccessModalOK} />

        <Space style={{ marginTop: 20, marginBottom: 30, width: "100%", justifyContent: "right", }}>
          <Row gutter={24} style={{ gap: 15 }}>
            <Col span={24}>
              <Button type="default" style={{ width: 100, justifyContent: "center" }}>
                Cancel
              </Button>
              <Button type="primary" onClick={handleSave} style={{ width: 100, justifyContent: "center", marginLeft: 15, }}>
                Save
              </Button>
            </Col>
          </Row>
        </Space>
      </Spin>
    </div>
  );
};

export default JuristicTabForm;
