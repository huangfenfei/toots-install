import React, { useContext, useEffect, useRef, useState } from 'react';
import { Button, Form, FormInstance, Input, Popconfirm, Select, Table, Typography } from 'antd';
import { DeleteFilled, DeleteOutlined, PlusOutlined } from '@ant-design/icons';
import { ColumnsType } from 'antd/es/table';
import { ValueType } from 'rc-input/lib/interface';
import { DropdownType } from '../../../../interface/masterType';
import { useSelector } from 'react-redux';
import { RootState } from '../../../../redux/store/store';
import { tinReasonDataList } from '../../../../utils/constantValue'
import { BiTrash } from 'react-icons/bi';
import { v4 as uuidv4 } from 'uuid';
import { Span } from 'next/dist/trace';

const ForeignTINTableForm = ({ form, onFinish, data, onCallback, titleName }: { form: FormInstance, onFinish: any, data: any, onCallback: any, titleName: string }) => {
    const { Text } = Typography;
    // const uuid = uuidv4();
    const countryOfBirthList: DropdownType[] = useSelector((state: RootState) => state.countryOfBirthReducer);
    const tinReasonList = tinReasonDataList();

    
    let initialValues = {
        taxResidencies: data,
    };

    const handleAddRow = () => {
        const model = {
            key: uuidv4(),
            no: 0,
            country_cd: "",
            TIN: "",
            reason_cd: "",
            reasonDetail: "",
            isReason: false,
            isReasonDetail: true,
        };

        const values = form.getFieldValue('taxResidencies') || [];
        form.setFieldsValue({
            taxResidencies: [...values, model],
        });
    }

    const handleForeignTINChange = (value: string, index: number) => {
        const taxResiden = form.getFieldValue('taxResidencies');
        if (value !== "") {
            taxResiden[index].reason_cd = "";
            taxResiden[index].isReason = true;
            taxResiden[index].reasonDetail = "";
        } else {
            taxResiden[index].isReason = false;
        }
        taxResiden[index].isReasonDetail = true;

        form.setFieldsValue({ taxResiden });
    };

    const handleReasonDropdownChange = (value: string, index: number) => {
        const taxResiden = form.getFieldValue('taxResidencies');
        taxResiden[index].isReasonDetail = value !== "B";
        form.setFieldsValue({ taxResiden });
    };

    const handleDeleteRow = (index: number) => {
        const values = form.getFieldValue('taxResidencies') || [];
        form.setFieldsValue({
            taxResidencies: values.filter((_, i) => i !== index),
        });
    };

    const defaultColumns: ColumnsType<any> = [
        {
            title: 'No',
            dataIndex: 'no',
            width: '5%',
            align: 'center',
            render: (_, __, index) => index + 1,
        },
        {
            title: (<Text>Country/Jurisdiction of Tax Residence <Text style={{ color: "#ff4d4f" }}>*</Text></Text>),
            dataIndex: 'country_cd',
            width: '20%',
            align: 'center',
            render: (option: any, record: { key: number; country_cd: string; }, index) => (
                <Form.Item name={[index, "country_cd"]} rules={[{ required: true }]} noStyle>
                    <Select
                        showSearch
                        placeholder="Please Select"
                        optionFilterProp="children"
                        filterOption={(input, option) => (option?.label ?? '').includes(input)}
                        options={countryOfBirthList}
                        style={{ width: "100%", textAlign: "left" }}
                    />
                </Form.Item>
            ),
        },
        {
            title: 'Foreign TIN',
            dataIndex: 'TIN',
            width: '20%',
            align: 'center',
            render: (text: ValueType, record: { key: number; }, index) => (
                <Form.Item name={[index, "TIN"]} noStyle>
                    <Input onChange={(e) => handleForeignTINChange(e.target.value, index)} />
                </Form.Item>
            ),
        },
        {
            title: 'If no TIN available enter reason (A), (B) or (C)-2',
            dataIndex: 'reason_cd',
            width: '20%',
            align: 'center',
            render: (text, record, index) => (
                <Form.Item name={[index, "reason_cd"]} noStyle>
                    <Select
                        showSearch
                        placeholder="Please Select"
                        optionFilterProp="children"
                        filterOption={(input, option) => (option?.label ?? '').includes(input)}
                        options={tinReasonList}
                        style={{ width: "100%", textAlign: "left" }}
                        onChange={(value) => handleReasonDropdownChange(value, index)}
                        disabled={record.isReason}
                    />
                </Form.Item>
            ),
        },
        {
            title: 'If you selected Reason(B)',
            dataIndex: 'reasonDetail',
            width: '25%',
            align: 'center',
            render: (text, record, index) => (
                <Form.Item name={[index, "reasonDetail"]} noStyle>
                    <Input disabled={record.isReasonDetail} />
                </Form.Item>
            ),
        },
        {
            title: 'Action',
            dataIndex: 'operation',
            width: '10%',
            align: 'center',
            render: (text: ValueType, record: { key: string; }, index) => (
                <Button type="text" onClick={() => handleDeleteRow(index)} style={{ paddingLeft: 3, paddingRight: 3 }}>
                    <BiTrash size={20} />
                </Button>
            ),
        },
    ];

    return (
        <div style={{ marginTop: 10, marginBottom: 20 }}>
            <span>
                <b>{titleName}</b>
                <Button type="primary" shape="circle" style={{ marginLeft: 15 }} icon={<PlusOutlined />} onClick={() => handleAddRow()} />
            </span>
            <Form form={form} onFinish={onFinish} labelCol={{ flex: '200px' }} labelAlign="left" initialValues={initialValues}>
                <Form.List name="taxResidencies">
                    {(fields) => (
                        <Table
                            dataSource={fields.map((field) => ({ ...field, ...form.getFieldValue(['taxResidencies', field.name]) }))}
                            columns={defaultColumns}
                            pagination={false}
                        />
                    )}
                </Form.List>
            </Form>
        </div>
    );
}

export default ForeignTINTableForm;