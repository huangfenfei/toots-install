import React, { useEffect, useState } from "react";
import { Card, Checkbox, Col, Form, Input, Row, Select } from "antd";
import { DropdownType } from "../../../../interface/masterType";
import { useSelector } from "react-redux";
import { RootState } from "../../../../redux/store/store";
import form, { FormInstance } from "antd/es/form";
import FormLabelCustomized from "../../../customs/formLabelCustomized";

const IRSDocumentW9Form = ({ form, onFinish, isVisible, customerType }: { form: FormInstance, onFinish: any, isVisible: any, customerType: string }) => {

    const payeeCodeList: DropdownType[] = useSelector((state: RootState) => state.payeeCodeReducer);
    const taxClassification: DropdownType[] = useSelector((state: RootState) => state.taxClassificationReducer);
    const reportingCodeList: DropdownType[] = useSelector((state: RootState) => state.reportingCodeReducer);

    const [isCheckSSN, setIsCheckSSN] = useState(false);
    const [isCheckEmpId, setIsCheckEmpId] = useState(false);
    const [isDisableSSNValue, setIsDisableSSNValue] = useState(false);
    const [isDisableEmpIdValue, setIsDisableEmpIdValue] = useState(false);

    const [SSN1, setSSN1] = useState("");
    const [SSN2, setSSN2] = useState("");
    const [SSN3, setSSN3] = useState("");

    useEffect(() => {
        form.setFieldsValue({
            irsDocW9TaxClassCode: "",
            irsDocW9ExemptPayeeCode: "",
            irsDocW9ReportingCode: ""
        });

        if (customerType === "individual") {
            setIsCheckSSN(true);
            setIsDisableSSNValue(false);
            setIsCheckEmpId(false);
            setIsDisableEmpIdValue(true);
        } else if (customerType === "juritic") {
            setIsCheckSSN(false);
            setIsDisableSSNValue(true);
            setIsCheckEmpId(true);
            setIsDisableEmpIdValue(false);
        }
    }, []);

    const handleSSNCheckboxChange = (e: any) => {
        setIsCheckSSN(e.target.checked);
        setIsDisableSSNValue(!e.target.checked);
    }

    const handleEmpIdCheckboxChange = (e: any) => {
        setIsCheckEmpId(e.target.checked);
        setIsDisableEmpIdValue(!e.target.checked)
    }

    const handleSSN1Change = (e: any) => {
        setSSN1(e.target.value);
    }

    const handleSSN2Change = (e: any) => {
        setSSN2(e.target.value);
    }

    const handleSSN3Change = (e: any) => {
        setSSN3(e.target.value);
    }

    form.setFieldsValue({
        customerInfo: {
            FATCAChkList: {
                IRSDoc: {
                    w9: {
                        SSN: SSN1 + "-" + SSN2 + "-" + SSN3
                    }
                }
            }
        }
    });

    return (
        <div style={{ marginTop: 10, marginBottom: 20 }}>
            <span><b>IRS Document</b></span>
            <Form form={form} onFinish={onFinish} labelCol={{ flex: '200px' }} labelAlign="left">
                <Row gutter={24}>
                    <Col span={24}>
                        <Card>
                            <Row gutter={24}>
                                <Col span={24}>
                                    <span><b>W-9</b></span>
                                </Col>
                            </Row>
                            <Row gutter={24}>
                                <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                                    {/* <Form.Item name={["irsDocW9Name"]} label={"Name / Business Name"} rules={[{ required: true }]}> */}
                                    <Form.Item
                                        name={["irsDocW9Name"]}
                                        label={<FormLabelCustomized label={"Name / Business Name"} required={true} />}
                                        rules={[{ required: true, message: "Please input Name / Business Name!" }]}
                                        required={false}
                                    >
                                        <Input maxLength={170}></Input>
                                    </Form.Item>
                                </Col>
                                <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                                    {/* <Form.Item name={["irsDocW9TaxClassCode"]} label={"Tax Classification"} rules={[{ required: true }]}> */}
                                    <Form.Item
                                        name={["irsDocW9TaxClassCode"]}
                                        label={<FormLabelCustomized label={"Tax Classification"} required={true} />}
                                        rules={[{ required: true, message: "Please select Tax Classification!" }]}
                                        required={false}
                                    >
                                        <Select
                                            showSearch
                                            placeholder="Please Select"
                                            optionFilterProp="children"
                                            filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                            options={taxClassification}
                                        />
                                    </Form.Item>
                                </Col>
                            </Row>
                            <Row gutter={24} style={{ marginBottom: 5 }}>
                                <Col span={24}>
                                    <span><b>Exemptions (If Any)</b></span>
                                </Col>
                            </Row>
                            <Row gutter={24}>
                                <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                                    <Form.Item name={["irsDocW9ExemptPayeeCode"]} label={"Exempt Payee Code"}>
                                        <Select
                                            showSearch
                                            placeholder="Please Select"
                                            optionFilterProp="children"
                                            filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                            options={payeeCodeList}
                                        />
                                    </Form.Item>
                                </Col>
                                <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                                    <Form.Item name={["irsDocW9ReportingCode"]} label={"Exemption from FATCA Reporting Code"}>
                                        <Select
                                            showSearch
                                            placeholder="Please Select"
                                            optionFilterProp="children"
                                            filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                            options={reportingCodeList}
                                        />
                                    </Form.Item>
                                </Col>
                            </Row>
                            <Row gutter={24}>
                                <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                                    {/* <Form.Item name={["irsDocW9Address"]} label={"Address"} rules={[{ required: true }]}> */}
                                    <Form.Item
                                        name={["irsDocW9Address"]}
                                        label={<FormLabelCustomized label={"Address"} required={true} />}
                                        rules={[{ required: true, message: "Please input Address!" }]}
                                        required={false}
                                    >
                                        <Input.TextArea rows={2} maxLength={100} />
                                    </Form.Item>
                                </Col>
                            </Row>
                            <Row gutter={24}>
                                <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                                    {/* <Form.Item name={["irsDocW9City"]} label={"City"} rules={[{ required: true }]}> */}
                                    <Form.Item
                                        name={["irsDocW9City"]}
                                        label={<FormLabelCustomized label={"City"} required={true} />}
                                        rules={[{ required: true, message: "Please input City!" }]}
                                        required={false}
                                    >
                                        <Input maxLength={30}></Input>
                                    </Form.Item>
                                </Col>
                                <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                                    {/* <Form.Item name={["irsDocW9State"]} label={"State"} rules={[{ required: true }]}> */}
                                    <Form.Item
                                        name={["irsDocW9State"]}
                                        label={<FormLabelCustomized label={"State"} required={true} />}
                                        rules={[{ required: true, message: "Please input State!" }]}
                                        required={false}
                                    >
                                        <Input maxLength={30}></Input>
                                    </Form.Item>
                                </Col>

                            </Row>
                            <Row gutter={24}>
                                <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                                    {/* <Form.Item name={["irsDocW9ZipCode"]} label={"Zip Code"} rules={[{ required: true }]}> */}
                                    <Form.Item
                                        name={["irsDocW9ZipCode"]}
                                        label={<FormLabelCustomized label={"Zip Code"} required={true} />}
                                        rules={[{ required: true, message: "Please input Zip Code!" }]}
                                        required={false}
                                    >
                                        <Input maxLength={20}></Input>
                                    </Form.Item>
                                </Col>
                            </Row>
                            <Row gutter={24} style={{ marginBottom: 5 }}>
                                <Col span={24}>
                                    <span><b>Taxpayer Identification Number (TIN)</b></span>
                                </Col>
                            </Row>
                            <Row gutter={24}>
                                <Col xxl={8} xl={8} lg={8} md={12} sm={24} xs={24}>
                                    <Form.Item name={["irsDocW9SSN"]}>
                                        <Checkbox checked={isCheckSSN} disabled={isDisableSSNValue}>Social Security Number</Checkbox>
                                    </Form.Item>
                                </Col>
                                <Col xxl={4} xl={3} lg={4} md={4} sm={4} xs={8}>
                                    {/* <Form.Item name={"irsDocW9SSN1"}> */}
                                    <Form.Item
                                        name={"irsDocW9SSN1"}
                                        rules={[{ required: isCheckSSN, message: "Please input 3 characters!" }, { min: 3, message: 'Please input 3 characters!', }]}
                                    >
                                        <Input min={3} maxLength={3} onChange={handleSSN1Change} disabled={isDisableSSNValue}></Input>
                                    </Form.Item>
                                </Col>
                                <Col xxl={4} xl={3} lg={4} md={4} sm={4} xs={8}>
                                    {/* <Form.Item name={"irsDocW9SSN2"}> */}
                                    <Form.Item
                                        name={"irsDocW9SSN2"}
                                        rules={[{ required: isCheckSSN, message: "Please input 2 characters!" }, { min: 2, message: 'Please input 2 characters!', }]}
                                    >
                                        <Input minLength={2} maxLength={2} onChange={handleSSN2Change} disabled={isDisableSSNValue}></Input>
                                    </Form.Item>
                                </Col>
                                <Col xxl={4} xl={3} lg={4} md={4} sm={4} xs={8}>
                                    {/* <Form.Item name={"irsDocW9SSN3"}> */}
                                    <Form.Item
                                        name={"irsDocW9SSN3"}
                                        rules={[{ required: isCheckSSN, message: "Please input 4 characters!" }, { min: 4, message: 'Please input 4 characters!', }]}
                                    >
                                        <Input maxLength={4} onChange={handleSSN3Change} disabled={isDisableSSNValue}></Input>
                                    </Form.Item>
                                </Col>
                            </Row>
                            <Row gutter={24}>
                                <Col xxl={8} xl={8} lg={8} md={12} sm={24} xs={24}>
                                    <Form.Item name={"empIdNum"}>
                                        <Checkbox checked={isCheckEmpId} disabled={isDisableEmpIdValue}>Employer Identification Number</Checkbox>
                                    </Form.Item>
                                </Col>
                                <Col xxl={4} xl={3} lg={4} md={4} sm={8} xs={8}>
                                    <Form.Item
                                        name={"empIdNum1"}
                                        rules={[{ required: isCheckEmpId, message: "Please input 2 characters!" }, { min: 2, message: 'Please input 2 characters!' }]}
                                    >
                                        <Input maxLength={2} disabled={isDisableEmpIdValue}></Input>
                                    </Form.Item>
                                </Col>
                                <Col xxl={8} xl={6} lg={8} md={8} sm={16} xs={16}>
                                    <Form.Item
                                        name={"empIdNum2"}
                                        rules={[{ required: isCheckEmpId, message: "Please input 7 characters!" }, { min: 7, message: 'Please input 7 characters!', }]}
                                    >
                                        <Input maxLength={7} disabled={isDisableEmpIdValue}></Input>
                                    </Form.Item>
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
            </Form>
        </div >
    );
}

export default IRSDocumentW9Form;