import React, { useEffect } from "react";
import { Card, Col, Form, FormInstance, Input, Row, Select } from "antd";
import { RootState } from "../../../../redux/store/store";
import { DropdownType } from "../../../../interface/masterType";
import { useSelector } from "react-redux";

const IRSDocumentW8Form = ({ form, onFinish, formName }: { form: FormInstance, onFinish: any, formName: string }) => {
    const docSupportList: DropdownType[] = useSelector((state: RootState) => state.docSupportReducer);

    return (
        <div style={{ marginTop: 10, marginBottom: 20 }}>
            <span><b>IRS Document</b></span>
            <Card>
                <Form form={form} onFinish={onFinish} labelCol={{ flex: '200px' }} labelAlign="left">
                    <Row gutter={24}>
                        <Col span={24}>
                            <span><b>{formName}</b></span>
                        </Col>
                    </Row>
                    <Row gutter={24}>
                        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                            <Form.Item name={["irsDocw8Ben"]} label={"Document Support"} rules={[{ required: true }]}>
                                <Select
                                    showSearch
                                    placeholder="Please Select"
                                    optionFilterProp="children"
                                    filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                    options={docSupportList}
                                />
                            </Form.Item>
                        </Col>
                    </Row>
                </Form>
            </Card>
        </div>
    );
}

export default IRSDocumentW8Form;