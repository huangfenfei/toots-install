import { useDispatch, useSelector } from "react-redux";
import { PermissionType, ResonseBodyType } from "../../interface/masterType";
import { PermissionEnum } from "../../utils/constantEnum";
import { useEffect, useState } from "react";
import { permissionReducer } from "../../redux/reducer/permissionReducer";
import { RootState } from "../../redux/store/store";

export const PermissionReduxComponent = () => {
  const dispatch = useDispatch();
  const permission: PermissionType = useSelector((state: RootState) => state.permissionReducer);
  const [permissionType, setPermissionType] = useState<PermissionType>();

  useEffect(() => {
    function disPatchData() {
      dispatch(permissionReducer(permissionType));
    }
    if (permissionType) {
      disPatchData();
    }
  }, [permissionType]);

  const asignPermissionRedux = async (resAuth: ResonseBodyType) => {
    setPermissionType(resAuth.body.person.auth.functionId);
  }

  const hasPermission = (functionName: string) => {
    switch (functionName) {
      case PermissionEnum.ADD:
        return permission.add === "Y";
      case PermissionEnum.UPDATE:
        return permission.update === "Y";
      case PermissionEnum.DELETE:
        return permission.delete === "Y";
      case PermissionEnum.SEARCH:
        return permission.search === "Y";
      case PermissionEnum.SEARCH_ALL:
        return permission.searchAll === "Y";
      case PermissionEnum.PRINT:
        return permission.print === "Y";
      case PermissionEnum.REPORT:
        return permission.report === "Y";
      default:
        return false;
    }
  };

  return { hasPermission, asignPermissionRedux };
};
