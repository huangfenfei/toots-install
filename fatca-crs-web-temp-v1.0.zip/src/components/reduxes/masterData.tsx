import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { titleIndividualReducer } from "../../redux/reducer/titleIndividualReducer";
import { DropdownType, PermissionType, PersonType, ResonseBodyType } from "../../interface/masterType";
import { personReducer } from "../../redux/reducer/personReducer";
import { permissionReducer } from "../../redux/reducer/permissionReducer";
import { taxClassificationReducer } from "../../redux/reducer/taxClassificationReducer";
import { idTypeIndividualReducer } from "../../redux/reducer/idTypeIndividualReducer";
import { payeeCodeReducer } from "../../redux/reducer/payeeCodeReducer";
import { reportingCodeReducer } from "../../redux/reducer/reportingCodeReducer";
import { docSupportReducer } from "../../redux/reducer/docSupportReducer";
import { titleJuristicReducer } from "../../redux/reducer/titleJuristicReducer";
import { idTypeJuristicReducer } from "../../redux/reducer/idTypeJuristicReducer";
import { nationalityReducer } from "../../redux/reducer/nationalityReducer";
import { countryOfBirthReducer } from "../../redux/reducer/countryOfBirthReducer";
import { crsCountryReducer } from "../../redux/reducer/crsCountryReducer";
import { crsReasonReducer } from "../../redux/reducer/crsReasonReducer";
import { allBranchReducer } from "../../redux/reducer/allBranchReducer";
import ResonseBodyBranchType, { BrancheType } from "../../interface/branchType";
import { plaseSelectAllBranchData, plaseSelectData } from "../../utils/constantValue";

export const MasterDataReduxCompoment = () => {
    const dispatch = useDispatch();
    const [person, setPerson] = useState<PersonType>();
    const [permission, setPermission] = useState<PermissionType>();
    const [taxClassification, setTaxClassification] = useState<DropdownType[]>();
    const [payeeCodeList, setPayeeCodeList] = useState<DropdownType[]>();
    const [reportingCodeList, setReportingCodeList] = useState<DropdownType[]>();
    const [docSupportList, setDocSupportList] = useState<DropdownType[]>();
    const [titleJuristicList, setTitleJuristicList] = useState<DropdownType[]>();
    const [titleIndividualList, setTitleIndividualList] = useState<DropdownType[]>();
    const [idTypeJuristicList, setIdTypeJuristicList] = useState<DropdownType[]>();
    const [idTypeIndividualList, setIdTypeIndividualList] = useState<DropdownType[]>();
    const [nationalityList, setNationalityList] = useState<DropdownType[]>();
    const [countryOfBirthList, setCountryOfBirthList] = useState<DropdownType[]>();
    const [crsCountryList, setCrsCountryList] = useState<DropdownType[]>();
    const [crsReasonList, setCrsReasonList] = useState<DropdownType[]>();
    const [allBranchList, setAllBranchList] = useState<BrancheType[]>();

    useEffect(() => {
        function disPatchData() {
            dispatch(personReducer(person));
        }
        if (person) {
            disPatchData();
        }
    }, [person]);

    useEffect(() => {
        function disPatchData() {
            dispatch(permissionReducer(permission));
        }
        if (permission) {
            disPatchData();
        }
    }, [permission]);

    useEffect(() => {
        function disPatchData() {
            dispatch(taxClassificationReducer(taxClassification));
        }
        if (taxClassification) {
            disPatchData();
        }
    }, [taxClassification]);

    useEffect(() => {
        function disPatchData() {
            dispatch(payeeCodeReducer(payeeCodeList));
        }
        if (payeeCodeList) {
            disPatchData();
        }
    }, [payeeCodeList]);

    useEffect(() => {
        function disPatchData() {
            dispatch(reportingCodeReducer(reportingCodeList));
        }
        if (reportingCodeList) {
            disPatchData();
        }
    }, [reportingCodeList]);

    useEffect(() => {
        function disPatchData() {
            dispatch(docSupportReducer(docSupportList));
        }
        if (docSupportList) {
            disPatchData();
        }
    }, [docSupportList]);

    useEffect(() => {
        function disPatchData() {
            dispatch(titleJuristicReducer(titleJuristicList));
        }
        if (titleJuristicList) {
            disPatchData();
        }
    }, [titleJuristicList]);

    useEffect(() => {
        function disPatchData() {
            dispatch(titleIndividualReducer(titleIndividualList));
        }
        if (titleIndividualList) {
            disPatchData();
        }
    }, [titleIndividualList]);

    useEffect(() => {
        console.log("useEffect.idTypeJuristicList", idTypeJuristicList);
        function disPatchData() {
            dispatch(idTypeJuristicReducer(idTypeJuristicList));
        }
        if (idTypeJuristicList) {
            disPatchData();
        }
    }, [idTypeJuristicList]);

    useEffect(() => {
        console.log("useEffect.idTypeIndividualList", idTypeIndividualList);
        function disPatchData() {
            dispatch(idTypeIndividualReducer(idTypeIndividualList));
        }
        if (idTypeIndividualList) {
            disPatchData();
        }
    }, [idTypeIndividualList]);

    useEffect(() => {
        function disPatchData() {
            dispatch(nationalityReducer(nationalityList));
        }
        if (nationalityList) {
            disPatchData();
        }
    }, [nationalityList]);

    useEffect(() => {
        function disPatchData() {
            dispatch(countryOfBirthReducer(countryOfBirthList));
        }
        if (countryOfBirthList) {
            disPatchData();
        }
    }, [countryOfBirthList]);

    useEffect(() => {
        function disPatchData() {
            dispatch(crsCountryReducer(crsCountryList));
        }
        if (crsCountryList) {
            disPatchData();
        }
    }, [crsCountryList]);

    useEffect(() => {
        function disPatchData() {
            dispatch(crsReasonReducer(crsReasonList));
        }
        if (crsReasonList) {
            disPatchData();
        }
    }, [crsReasonList]);

    useEffect(() => {
        function disPatchData() {
            dispatch(allBranchReducer(allBranchList));
        }
        if (allBranchList) {
            disPatchData();
        }
    }, [allBranchList]);

    const asignMasterDataRedux = async (resAuth: ResonseBodyType) => {

        if (resAuth.body.person) {
            setPerson(resAuth.body.person);
            setPermission(resAuth.body.person.auth.functionId);
        }

        if (resAuth.body.master.codes) {
            resAuth.body.master.codes.taxClassification.map(m => {
                m.value = m.code_cd;
                m.label = m.descEN;
                return m;
            });
            resAuth.body.master.codes.taxClassification.unshift(plaseSelectData());
            console.log(resAuth.body.master.codes.taxClassification);
            setTaxClassification(resAuth.body.master.codes.taxClassification);

            resAuth.body.master.codes.payeeCode.map(m => {
                m.value = m.code_cd;
                m.label = m.code_cd + " - " + m.descEN;
                return m;
            });
            resAuth.body.master.codes.payeeCode.unshift(plaseSelectData());
            setPayeeCodeList(resAuth.body.master.codes.payeeCode);

            resAuth.body.master.codes.reportingCode.map(m => {
                m.value = m.code_cd;
                m.label = m.code_cd + " - " + m.descEN;
                return m;
            });
            resAuth.body.master.codes.reportingCode.unshift(plaseSelectData());
            setReportingCodeList(resAuth.body.master.codes.reportingCode);

            resAuth.body.master.codes.docSupport.map(m => {
                m.value = m.code_cd;
                m.label = m.descTH + " / " + m.descEN;
                return m;
            });
            resAuth.body.master.codes.docSupport.unshift(plaseSelectData());
            setDocSupportList(resAuth.body.master.codes.docSupport);
        }

        if (resAuth.body.master.titles) {
            resAuth.body.master.titles.juristic.map(m => {
                m.value = m.code_cd;
                m.label = m.descTH + " / " + m.descEN;
                return m;
            });
            resAuth.body.master.titles.juristic.unshift(plaseSelectData());
            setTitleJuristicList(resAuth.body.master.titles.juristic);

            resAuth.body.master.titles.individual.map(m => {
                m.value = m.code_cd;
                m.label = m.descTH + " / " + m.descEN;
                return m;
            });
            resAuth.body.master.titles.individual.unshift(plaseSelectData());
            setTitleIndividualList(resAuth.body.master.titles.individual);
        }

        if (resAuth.body.master.idType) {
            resAuth.body.master.idType.juristic.map(m => {
                m.value = m.code_cd;
                m.label = m.descTH + " / " + m.descEN;
                return m;
            });
            resAuth.body.master.idType.juristic.unshift(plaseSelectData());
            setIdTypeJuristicList(resAuth.body.master.idType.juristic);

            resAuth.body.master.idType.individual.map(m => {
                m.value = m.code_cd;
                m.label = m.descTH + " / " + m.descEN;
                return m;
            });
            resAuth.body.master.idType.individual.unshift(plaseSelectData());
            setIdTypeIndividualList(resAuth.body.master.idType.individual);
        }

        if (resAuth.body.master.nationality) {
            resAuth.body.master.nationality.map(m => {
                m.value = m.code_cd;
                m.label = m.descTH + " / " + m.descEN;
                return m;
            });
            resAuth.body.master.nationality.unshift(plaseSelectData());
            setNationalityList(resAuth.body.master.nationality);
        }

        if (resAuth.body.master.countryOfBirth) {
            resAuth.body.master.countryOfBirth.map(m => {
                m.value = m.code_cd;
                m.label = m.descTH + " / " + m.descEN;
                return m;
            });
            resAuth.body.master.countryOfBirth.unshift(plaseSelectData());
            setCountryOfBirthList(resAuth.body.master.countryOfBirth);
        }

        if (resAuth.body.master.crsCountry) {
            resAuth.body.master.crsCountry.map(m => {
                m.value = m.code_cd;
                m.label = m.descTH + " / " + m.descEN;
                return m;
            });
            resAuth.body.master.crsCountry.unshift(plaseSelectData());
            setCrsCountryList(resAuth.body.master.crsCountry);
        }

        if (resAuth.body.master.crsReason) {
            resAuth.body.master.crsReason.map(m => {
                m.value = m.code_cd;
                m.label = m.descTH + " / " + m.descEN;
                return m;
            });
            resAuth.body.master.crsReason.unshift(plaseSelectData());
            setCrsReasonList(resAuth.body.master.crsReason);
        }
    }

    const asignAllBranchRedux = (res: ResonseBodyBranchType) => {
        res.body.branches.map(m => {
            m.value = m.ocCode;
            m.label = m.ocNameTH + " / " + m.ocNameEN;
            return m;
        });
        res.body.branches.unshift(plaseSelectAllBranchData());
        setAllBranchList(res.body.branches);
    }

    return { asignMasterDataRedux, asignAllBranchRedux }
}

export default MasterDataReduxCompoment;