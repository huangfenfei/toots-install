import React from "react";
import { CustomerType } from "../../interface/searchType";
import jsPDF from "jspdf";
import { notoSansThaiBase64 } from "./fonts/NotoSansThai/NotoSansThai";
import { fontTH } from "./fonts/THSarabunNew/font";
import autoTable from "jspdf-autotable";

export const DeliveryCustomerReportPage = () => {
   
    const generatePDF = (arrData: CustomerType[]) => {
        console.log("generatePDF.arrData", arrData);
        const doc = new jsPDF({
            orientation: 'l',
            unit: 'pt',
            format: 'a4'
        });

        // doc.addFileToVFS('NotoSansThai-Regular.ttf', notoSansThaiBase64);
        // doc.addFont('NotoSansThai-Regular.ttf', 'NotoSansThai', 'regular');
        // doc.setFont('NotoSansThai', "regular");

        doc.addFileToVFS('THSarabunNew.ttf', fontTH);
        doc.addFont('THSarabunNew.ttf', 'THSarabunNew', 'normal');
        doc.setFont("THSarabunNew", "normal");
        doc.setFontSize(16);

        arrData.forEach((data, index) => {
            if (index !== 0) {
                doc.addPage();
            }

            doc.text('Delivery Report by Customer', 30, 40);
            doc.text('ID Number: ', 30, 70);
            doc.text(data.idNum, 120, 70);
            doc.text("จัดเรียงข้อมูลตามฟิลด์ TRANSACTION DATE", 30, 100);
            doc.text("One item found. 1", 30, 130);

            autoTable(doc, {
                startY: 150,
                theme: "grid",
                margin: { left: 30, right: 30 },
                styles: {
                    font: "THSarabunNew",
                    fontSize: 14,
                },
                headStyles: {
                    fillColor: [79, 55, 147]
                },
                head: [["TRANSACTION DATE", "CUSTOMER NAME", "ID TYPE", "ID NUMBER", "FATCA STATUS", "IRS DOCUMENT", "DOCUMENT SUPPORT", "USER ENTRY", "BRANCH NO CHANNEL"]],
                body: [[data.transactionStatus, data.customerName, data.idType, data.idNum, data.fatcaStatus, data.IRSDoc, data.docSupport, data.userEntry, data.branch]]
            });

            doc.text("เอกสาร FATCA", 30, 290);
            autoTable(doc, {
                startY: 300,
                margin: { left: 30, right: 30 },
                theme: "grid",
                styles: {
                    font: "THSarabunNew",
                    fontSize: 14,
                },
                headStyles: {
                    fillColor: [79, 55, 147],
                    halign: 'center',
                },
                head: [[{ content: "ชื่อเอกสาร", colSpan: 7 }]],
                body: [
                    ["Type", "สำเนาแสดงตน", "FATCA Form", "W8BEN บุคคล", "W8BEN-E นิติบุคคล", "W9", "เอกสารหักล้าง"],
                    ["W8BEN-E นิติบุคคล", "X", "X", "-", "X", "-", "-"],
                ]
            });
        });

        const pdfBlob = doc.output('blob');
        const urlBlob = URL.createObjectURL(pdfBlob);
        window.open(urlBlob, '_blank');
    }

    return { generatePDF };
}
