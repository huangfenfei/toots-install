import React from "react";
import { CustomerType } from "../../interface/searchType";
import jsPDF from "jspdf";
import { notoSansThaiBase64 } from "./fonts/NotoSansThai/NotoSansThai";
import { fontTH } from "./fonts/THSarabunNew/font";
import autoTable from "jspdf-autotable";
import { HeaderType } from "../../interface/reportType";

export const DeliveryCoverReportPage = () => {

    const generateCoverPDF = (data: HeaderType) => {
        const dataList = [];
        if (data.customerList.length > 0) {
            data.customerList.forEach(it => {
                const arrData = [
                    it.rowNumber,
                    it.lastUpdateDate,
                    it.customerName,
                    it.idType,
                    it.idNum,
                    it.fatcaStatus,
                    it.IRSDoc,
                    it.docSupport,
                    it.transactionStatus,
                    it.userEntry,
                    it.branch,
                    it.HoReceiveStatus
                ]
                dataList.push(arrData);
            });
        }

        const doc = new jsPDF({
            orientation: 'portrait',
            unit: 'pt',
            format: 'a4'
        });

        // doc.addFileToVFS('NotoSansThai-Regular.ttf', notoSansThaiBase64);
        // doc.addFont('NotoSansThai-Regular.ttf', 'NotoSansThai', 'regular');
        // doc.setFont('NotoSansThai', "regular");

        doc.addFileToVFS('THSarabunNew.ttf', fontTH);
        doc.addFont('THSarabunNew.ttf', 'THSarabunNew', 'normal');
        doc.setFont("THSarabunNew", "normal");
        doc.setFontSize(14);

        doc.text('FATCA Report', 20, 20);
        doc.text('Report Type: ', 20, 40);
        doc.text(data.reportType, 120, 40);
        doc.text('Branch no/Channel: ', 20, 60);
        doc.text(data.brancdCode, 120, 60);
        doc.text("จัดเรียงข้อมูลตามฟิลด์ Transaction date, FATCA Status และ IRS Document ตามลำดับ", 30, 80);
        
        autoTable(doc, {
            startY: 100,
            theme: "grid",
            margin: { left: 20, right: 20 },
            styles: {
                font: "THSarabunNew",
                fontSize: 10,
            },
            headStyles: {
                fillColor: [79, 55, 147]
            },
            head: [["NO", "TRANSACTION DATE", "CUSTOMER NAME", "ID TYPE", "ID NUMBER", "FATCA STATUS", "IRS DOCUMENT", "DOCUMENT SUPPORT", "TRANSACTION TYPE", "USER ENTRY", "BRANCH NO/CHANNEL", "HO RECEIVE STATUS"]],
            body: dataList
        });



        const pdfBlob = doc.output('blob');
        const urlBlob = URL.createObjectURL(pdfBlob);
        window.open(urlBlob, '_blank');
    }

    return { generateCoverPDF };
}
