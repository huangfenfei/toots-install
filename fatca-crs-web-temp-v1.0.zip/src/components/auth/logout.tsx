import { useMsal } from "@azure/msal-react";
import { clearAccessTokenStorage } from "../../storages/accessTokenStorage";
import { clearRefreshTokenStorage } from "../../storages/refreshTokenStorage";
import { clearTokenStorage } from "../../storages/tokenStorage";
import { clearIsAuthAzureStorage } from "../../storages/isAuthAzureStorage";

export const UserLogout = () => {
    const { instance, accounts } = useMsal();

    const logout = () => {
        clearIsAuthAzureStorage();
        clearAccessTokenStorage();
        clearRefreshTokenStorage();
        clearTokenStorage();
        localStorage.clear();
        sessionStorage.clear();

        if (accounts.length !== 0) {
            instance.logoutRedirect({
                postLogoutRedirectUri: "/login"
            });
        }
    }

    return { logout };
};