import React, { useState } from "react";
import { Form, TabsProps, Tabs } from "antd";
import { useQuery, useMutation } from "@tanstack/react-query";
import AppLayout from "../../components/layouts/appLayout";
import IndividualTabForm from "../../components/forms/add-fatca-crs/individual/indiTabForm";
import JuristicTabForm from "../../components/forms/add-fatca-crs/juristic/juriTabForm";
import { PermissionReduxComponent } from "../../components/reduxes/permission";
import InquiryPage from "../inquiry";
import { useRouter } from "next/router";

const AddFatcaCrsPage = () => {

  const { hasPermission } = PermissionReduxComponent();
  const router = useRouter();
  const [addFatcaTab, setAddFatcaTab] = useState("");

  if (hasPermission("add")) {
    // return <InquiryPage />
    // router.push('/inquiry')
  }

  const items: TabsProps['items'] = [
    {
      key: 'individual',
      label: 'Individual (บุคคลธรรมดา)',
      children: <IndividualTabForm tab={addFatcaTab} />,
    },
    {
      key: 'juristic',
      label: 'Juristic (นิติบุคคล)',
      children: <JuristicTabForm tab={addFatcaTab} />,
    },
  ];

  const handleTabChange = (tabName: string) => {
    console.log(tabName);
    setAddFatcaTab(tabName);
  };

  return (
    <Tabs defaultActiveKey="1" items={items} onChange={handleTabChange} />
  );
}

export default AddFatcaCrsPage;
AddFatcaCrsPage.getLayout = function getLayout(page: React.ReactElement<any, string | React.JSXElementConstructor<any>>) {
  return <AppLayout>{page}</AppLayout>;
};

