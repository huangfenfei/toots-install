import React, { useState } from "react";
import { Form, TabsProps, Tabs } from "antd";
import { useQuery, useMutation } from "@tanstack/react-query";
import AppLayout from "../../components/layouts/appLayout";
import IndividualTabForm from "../../components/forms/add-fatca-crs/individual/indiTabForm";
import JuristicCustomerInfoForm from "../../components/forms/add-fatca-crs/juristic/juriCustomerInfoForm";

const AddFatcaCrsPage = () => {

  const form = Form.useForm;

  const items: TabsProps['items'] = [
    {
      key: '1',
      label: 'Individual (บุคคลธรรมดา)',
      children: <IndividualTabForm />,
    },
    {
      key: '2',
      label: 'Juristic (นิติบุคคล)',
      children: <JuristicCustomerInfoForm form={undefined} onFinish={undefined} />,
    },
  ];

  const onChange = (key: string) => {
    console.log(key);
  };

  return (
    <Tabs defaultActiveKey="1" items={items} onChange={onChange} />
  );
}

export default AddFatcaCrsPage;
AddFatcaCrsPage.getLayout = function getLayout(page: React.ReactElement<any, string | React.JSXElementConstructor<any>>) {
  return <AppLayout>{page}</AppLayout>;
};

