import React, { useEffect, useState } from "react";
import type { ReactElement, ReactNode } from "react";
import type { NextPage } from "next";
import type { AppProps } from "next/app";
import axios from "axios";
import Head from "next/head";
import { useRouter } from "next/router";
import { Provider } from "react-redux";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { MsalProvider, useIsAuthenticated, useMsal } from "@azure/msal-react";
import { PublicClientApplication } from "@azure/msal-browser";
import { ConfigProvider, Spin, message } from "antd";
import themeConfig from "../configs/themeConfig";
import { persistor, store } from "../redux/store/store";
import { msalConfig } from "../configs/authConfig";
import { ResponseCodeEnum } from "../utils/constantEnum";
import { getAccessTokenStorage } from "../storages/accessTokenStorage";
import { getTokenStorage } from "../storages/tokenStorage";
import { getRefreshTokenStorage } from "../storages/refreshTokenStorage";
import { getIsAuthAzureStorage } from "../storages/isAuthAzureStorage";
import { getAllBranchStorage, getMasterDataStorage } from "../storages/masterStoreage";
import "../styles/globals.css";
import "../styles/font.css";
import { PersistGate } from "redux-persist/integration/react";
import ErrorModal from "../components/modals/errorModal";
import { DemoModal } from "../components/modals/demoModal";
import { AuthProvider } from "../context/authProvider";

export type NextPageWithLayout<P = {}, IP = P> = NextPage<P, IP> & {
  getLayout?: (page: ReactElement) => ReactNode;
};

type AppPropsWithLayout = AppProps & {
  Component: NextPageWithLayout;
};

const QueryProvider = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false, // default: true
    },
  },
});

const msalInstance = new PublicClientApplication(msalConfig);

export default function MyApp({ Component, pageProps }: AppPropsWithLayout) {

  const getLayout = Component.getLayout ?? ((page) => page);
  const [loading, setLoading] = useState<boolean>(true);
  const router = useRouter();
  const { events } = router;
  const isAuthenticated = useIsAuthenticated();
  const { accounts } = useMsal();
  const [errorModalVisible, setErrorModalVisible] = useState(false);
  const [errorMsgModal, setErrorMsgModal] = useState("");
  const { errorAlertModal } = DemoModal();

  // axios.interceptors.request.use((request) => {
  //   const token = getTokenStorage();
  //   console.log("request.use.accounts", accounts, token, accounts.length !== 0 || token);
  //   if (accounts.length !== 0) {
  //     request.headers.Authorization = "Bearer " + token;
  //   }
  //   return request;
  // }, (error) => {
  //   return Promise.reject(error);
  // });

  axios.interceptors.response.use((response) => {
    // if (response.data.respCode === ResponseCodeEnum.SUCCESS) {
    //   return response;
    // } else {
    //   message.error("Error Code: " + response.data.respCode + " Error Detail: " + response.data.respDesc);

    // }
    // if (response.data.respCode === ResponseCodeEnum.UNAUTHORIZE) {
    //   router.push('/authen/logout');
    // }
    return response;
  }, (error) => {
    console.log(error);
    const { status } = error.response;
    setErrorModalVisible(true);
    setErrorMsgModal("Error Code : " + status);
    // errorAlertModal(true, "Error Code 1 : " + status, handleOkErrorModal);
  });

  async function handleRouteChangeStart() {
    setLoading(true);
  }

  async function setDelay(time?: number) {
    await new Promise((reslove) => setTimeout(reslove, time ?? 500));
  }

  async function handleRouteChangeComplete(url: string) {
    setLoading(false);
  }

  useEffect(() => {
    const accessToken = getAccessTokenStorage();
    const idToken = getRefreshTokenStorage();
    const isAuthAzure = getIsAuthAzureStorage();
    const token = getTokenStorage();
    const masterData = getMasterDataStorage();
    const allBranch = getAllBranchStorage();
    console.log("accessToken:", accessToken);
    console.log("idToken:", idToken);
    console.log("isAuthAzure:", isAuthAzure);
    console.log("token:", token);
    console.log("isAuthenticated:", isAuthenticated);
    console.log("masterData:", JSON.parse(masterData));
    console.log("allBranch:", JSON.parse(allBranch));
    console.log("accounts", accounts);

    if (masterData) {
      const res = JSON.parse(masterData);
      // asignMasterDataRedux(res);
    }

    if (!token) {
      router.push('/login');
    }
  }, []);

  useEffect(() => {
    return () => {
      events.off("routeChangeStart", handleRouteChangeStart);
      events.off("routeChangeComplete", handleRouteChangeComplete);
    };
  }, [events]);

  useEffect(() => {
    setDelay();
    setLoading(false);
    events.on("routeChangeStart", handleRouteChangeStart);
    events.on("routeChangeComplete", handleRouteChangeComplete);
  }, [events, router]);

  const handleOkErrorModal = () => {
    setErrorModalVisible(false)
    router.push('/authen/logout');
  }

  return (
    <>
      <Head>
        <link rel="icon" href="" />
        <title>FATCA & CRS SYSTEM</title>
      </Head>
      <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
          <AuthProvider>
            {/* <MsalProvider instance={msalInstance}> */}
            <QueryClientProvider client={QueryProvider}>
              <ConfigProvider theme={themeConfig}>
                {getLayout(
                  <Spin spinning={loading}>
                    <Component {...pageProps} />
                  </Spin>
                )}
                <ErrorModal isModalOpen={errorModalVisible} handleMessage={errorMsgModal} handleOk={handleOkErrorModal} />
              </ConfigProvider>
            </QueryClientProvider>
            {/* </MsalProvider> */}
          </AuthProvider>
        </PersistGate>
      </Provider>

    </>
  );
}
