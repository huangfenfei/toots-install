import { useRouter } from "next/router";
import { useEffect } from "react";

const CallBackPage = () => {

    const router = useRouter();
    useEffect(() => {
        // router.push('/login');
    }, []);

    return (
        <div></div>
    )
}

export default CallBackPage;