import { useEffect } from "react";
import { UserLogout } from "../../../components/auth/logout";

const CallBackPage = () => {
    const { logout } = UserLogout();
    useEffect(() => {
        logout();
    }, []);

    return (
        <div>Logouting...</div>
    )
}

export default CallBackPage;