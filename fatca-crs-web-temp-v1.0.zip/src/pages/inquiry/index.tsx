import React, { useEffect } from "react";
import { Tabs, TabsProps } from "antd";
import AppLayout from "../../components/layouts/appLayout";
import SearchCustomerForm from "../../components/forms/inquiries/search-customer/searchCustomerForm";
import SearchTransactionForm from "../../components/forms/inquiries/search-transaction/searchTransactionForm";

const InquiryPage = () => {

  const items: TabsProps["items"] = [
    {
      key: "1",
      label: "Search by Customer",
      children: <SearchCustomerForm />,
    },
    {
      key: "2",
      label: "Search by Transaction",
      children: <SearchTransactionForm />,
    },
  ];

  const onChange = (key: string) => {
    console.log(key);
  };

  return (
    <>
      <Tabs defaultActiveKey="1" items={items} onChange={onChange} />
    </>
  );
};

export default InquiryPage;
InquiryPage.getLayout = function getLayout(
  page: React.ReactElement<any, string | React.JSXElementConstructor<any>>
) {
  return <AppLayout>{page}</AppLayout>;
};
