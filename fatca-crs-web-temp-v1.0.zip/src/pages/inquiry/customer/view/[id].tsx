import React, { useState } from "react";
import { Form, TabsProps, Tabs } from "antd";

import { useRouter } from "next/router";
import { PermissionReduxComponent } from "../../../../components/reduxes/permission";
import AppLayout from "../../../../components/layouts/appLayout";
import IndividualTabForm from "../../../../components/forms/add-fatca-crs/individual/indiTabForm";

const ViewSearchCustomerPage = () => {

  const { hasPermission } = PermissionReduxComponent();
  const router = useRouter();
  
  if (hasPermission("add")) {
    // return <InquiryPage />
    // router.push('/inquiry')
  }

  const form = Form.useForm;

  const items: TabsProps['items'] = [
    {
      key: '1',
      label: 'Individual (บุคคลธรรมดา)',
      children: <IndividualTabForm />,
    },
  ];

  const onChange = (key: string) => {
    console.log(key);
  };

  return (
    <Tabs defaultActiveKey="1" items={items} onChange={onChange} />
  );
}

export default ViewSearchCustomerPage;
ViewSearchCustomerPage.getLayout = function getLayout(page: React.ReactElement<any, string | React.JSXElementConstructor<any>>) {
  return <AppLayout>{page}</AppLayout>;
};