import { Spin } from "antd";
import { useEffect } from "react";
import { useRouter } from "next/router";

export default function Home() {
  return <div className="h-screen flex justify-center items-center">
    <Spin spinning size="large"></Spin>
  </div>;
}
