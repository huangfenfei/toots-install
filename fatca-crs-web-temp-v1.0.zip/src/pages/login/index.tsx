import React, { useEffect, useState } from "react";
import { useMsal } from "@azure/msal-react";
import { Row, Image, Button, Form, Spin } from "antd";
import { loginRequest, msalConfig } from "../../configs/authConfig";
import { InteractionStatus, PublicClientApplication, SilentRequest } from "@azure/msal-browser";
import { useRouter } from "next/router";

import { callMsGraph, loginWithAzureAD } from "../../services/auth/authService";
import { fetchAllBranch, fetchMasterData } from "../../services/master/masterDataService";
import { PermissionEnum, ResponseCodeEnum } from "../../utils/constantEnum";

import { clearAccessTokenStorage, saveAccessTokenStorage } from "../../storages/accessTokenStorage";
import { clearRefreshTokenStorage, saveRefreshTokenStorage } from "../../storages/refreshTokenStorage";
import { clearTokenStorage, saveTokenStorage } from "../../storages/tokenStorage";
import { getIsAuthAzureStorage, saveIsAuthAzureStorage } from "../../storages/isAuthAzureStorage";
import { PermissionReduxComponent } from "../../components/reduxes/permission";
import { saveAllBranchStorage, saveMasterDataStorage } from "../../storages/masterStoreage";
import MasterDataReduxCompoment from "../../components/reduxes/masterData";
import { saveUsernameStorage } from "../../storages/usernameStorage";
import { saveOcCodeStorage } from "../../storages/ocCodeStorage";
import { useAuth } from "../../context/authProvider";

// const msalInstance = new PublicClientApplication(msalConfig);

const LoginPage = () => {
    const { instance, accounts, inProgress } = useMsal();
    const { msalInstance } = useAuth();

    const router = useRouter();
    const { asignPermissionRedux, hasPermission } = PermissionReduxComponent();
    const { asignMasterDataRedux, asignAllBranchRedux } = MasterDataReduxCompoment();
    const [graphData, setGraphData] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [goLogin, setGoLogin] = useState(false);
    

    const handleGetProfile = async () => {
        try {
            setIsLoading(true);
            // const account = instance.getActiveAccount() || accounts[0];
            const account = true;
            if (account) {
                console.log("handleGetProfile.account ==>", account);
                // const tokenReq = { ...loginRequest, account: account } as SilentRequest
                // const resAcquireToken = await instance.acquireTokenSilent(tokenReq);
                saveUsernameStorage("TEST TEST");
                // saveAccessTokenStorage(resAcquireToken.accessToken);
                // saveRefreshTokenStorage(resAcquireToken.idToken);

                const [resAuth, token] = await loginWithAzureAD();
                if (resAuth.respCode === ResponseCodeEnum.SUCCESS) {
                    saveOcCodeStorage(resAuth.body.person.ocCode);
                    saveTokenStorage(token);
                    asignPermissionRedux(resAuth);
                    asignMasterDataRedux(resAuth);
                    saveMasterDataStorage(JSON.stringify(resAuth));

                    const resAllBranch = await fetchAllBranch(token);
                    if (resAllBranch.respCode === ResponseCodeEnum.SUCCESS) {
                        asignAllBranchRedux(resAllBranch);
                        saveAllBranchStorage(JSON.stringify(resAllBranch));
                    }

                    if (hasPermission(PermissionEnum.REPORT)) {
                        router.push("/batch-result");
                    } else {
                        router.push("/inquiry");
                    }
                } else {
                    clearAccessTokenStorage();
                    clearRefreshTokenStorage();
                    clearTokenStorage();
                }
            }
            setIsLoading(false);
        } catch (error) {
            console.error("handleGetProfile", error)
            setIsLoading(false);
        }
    }

    useEffect(() => {
        const init = async () => {
            const isAuthAzure = getIsAuthAzureStorage();
            if (!graphData && inProgress == InteractionStatus.None && isAuthAzure) {
                handleGetProfile();
            }
        }

        init();
    }, [goLogin]);

    const onFinish = (values: any) => {
        console.log('Received values:', values);
    };

    const handleLogin = async () => {
        try {
            saveIsAuthAzureStorage();
            setGoLogin(true);
            // await msalInstance.initialize();
            // await msalInstance.loginRedirect(loginRequest);
        } catch (error) {
            console.error(error)
        }
    };

    return (
        <div>
            {
                isLoading ? (
                    <div className="h-screen flex justify-center items-center">
                        <Spin spinning={isLoading} size="large"></Spin>
                    </div>
                ) : (
                    <div className="login-area" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
                        <Form
                            name="basic"
                            initialValues={{ remember: true }}
                            onFinish={onFinish}
                        >
                            <Row justify="center">
                                <Image src="assets/images/fatca-logo.png" width={700} alt="Logo" preview={false} />
                            </Row>
                            <Row justify="center">
                                <span style={{ fontWeight: 600, fontSize: 20, color: '#4F3793', marginBottom: 10 }}>Foreign Account Tax Compliance Act</span>
                            </Row>
                            <Row justify="center">
                                <Button type="primary" onClick={handleLogin} style={{ width: 120, height: 40, fontWeight: "bold", fontSize: 18 }}>Login</Button>
                            </Row>
                        </Form>
                    </div>
                )
            }
        </div>
    );
}

export default LoginPage;