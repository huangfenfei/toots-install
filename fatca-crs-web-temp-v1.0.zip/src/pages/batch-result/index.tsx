import React from "react";
import AppLayout from "../../components/layouts/appLayout";

const GenerateXMLPage = () => {
    return (
        <div>
            Batch Result
        </div>
    );
}

export default GenerateXMLPage;
GenerateXMLPage.getLayout = function getLayout(page: React.ReactElement<any, string | React.JSXElementConstructor<any>>) {
    return <AppLayout>{page}</AppLayout>;
};