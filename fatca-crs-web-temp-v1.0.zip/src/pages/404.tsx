import { Button, Result } from "antd";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
const ROUTE_RETRY_ATTEMPT = "routeRetryAttempt";

function Error404() {
    const [loading, setLoading] = useState(true);
    const router = useRouter();

    useEffect(() => {
        const processRoute = async () => {
            const { asPath } = router;
            if (asPath.indexOf("/404") >= 0) {
                clearRouteRetryAttempt();
                setLoading(false);
                return;
            }

            const routeRetryAttempt = getRouteRetryAttempt();
            if (routeRetryAttempt < 100) {
                increaseRouteRetryAttempt();
                let pathname = asPath;
                const pathSplit = asPath.split("/");
                const lastPathNum = pathSplit.length - 1;

                if (
                    pathSplit.length > 3 &&
                    pathSplit[lastPathNum - 1] &&
                    pathSplit[lastPathNum - 1] !== ""
                ) {
                    // route path with id ex. '/campaigns/4/'
                    let pathsp = asPath.split("/");
                    pathsp = pathsp.splice(0, pathsp.length - 2);
                    let pathname = pathsp.join("/");
                    if (asPath.indexOf("/admin-audits") >= 0) {
                        pathname = `${pathname}/[logRefId]/`;
                    } else {
                        pathname = `${pathname}/[id]/`;
                    }
                    try {
                        await router.push(asPath);
                        return;
                    } catch (err) {
                        console.error(err);
                        clearRouteRetryAttempt();
                        setLoading(false);
                    }
                } else {
                    router.push(asPath);
                }
            } else {
                clearRouteRetryAttempt();
                setLoading(false);
            }
        };
        processRoute();
    }, []);

    const getRouteRetryAttempt = (): number => {
        const retry = sessionStorage.getItem(ROUTE_RETRY_ATTEMPT);
        return retry ? Number(retry) : 0;
    };

    const increaseRouteRetryAttempt = () => {
        let retry = getRouteRetryAttempt();
        ++retry;
        sessionStorage.setItem(ROUTE_RETRY_ATTEMPT, `${retry}`);
    };

    const clearRouteRetryAttempt = () => {
        sessionStorage.setItem(ROUTE_RETRY_ATTEMPT, "0");
    };

    const handleGoHome = () => {
        router.push("/");
    };

    if (loading) {
        return <p></p>;
    }

    return (
        <Result
            status="warning"
            title="404"
            subTitle="This page could not be found."
            extra={
                <Button type="primary" key="console" onClick={handleGoHome}>
                    Go Home
                </Button>
            }
        />
    );
}

export default Error404;